// DSP test-suite for the SPHS phaser library (no VST3 needed).
// Every number printed here is measured on the code in this repository.
// Nothing in this file is a measurement of a real AX300B.
#include "sphs/Engine.h"
#include "sphs/ModelIO.h"
#include "sphs/PedalLogic.h"
#include "sphs/Phaser.h"
#include "sphs/PluginCore.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstring>
#include <random>
#include <string>
#include <vector>

using namespace sphs;

static int g_checks = 0, g_failed = 0;
static void check (bool ok, const char* what, const std::string& detail = "")
{
	++g_checks;
	if (!ok)
	{
		++g_failed;
		std::printf ("    FAIL: %s %s\n", what, detail.c_str ());
	}
}
static void section (const char* name) { std::printf ("\n[%s]\n", name); }
static std::string fmt (const char* f, double a = 0, double b = 0, double c = 0, double d = 0)
{
	char buf[256];
	std::snprintf (buf, sizeof (buf), f, a, b, c, d);
	return buf;
}

static const double kPi = 3.14159265358979323846;
static const double kRates[] = {39062.5, 44100., 48000., 88200., 96000.};

static ModelConfig staticModel ()
{
	ModelConfig m;
	m.stereoPhaseDeg = 0.;
	return m;
}

// complex gain at f (must be k*fs/len) measured on the left / right output
static void measureGain (StereoPhaser& p, double f, std::complex<double>& gl, std::complex<double>& gr)
{
	const double fs = p.sampleRate ();
	const int len = 8192;
	const int settle = static_cast<int> (fs * 1.5);
	const int k = std::max (1, static_cast<int> (std::lround (f * len / fs)));
	const double w = 2. * kPi * k / len;
	std::vector<float> in (static_cast<size_t> (settle + len)), l (in.size ()), r (in.size ());
	for (size_t n = 0; n < in.size (); ++n)
		in[n] = static_cast<float> (0.5 * std::sin (w * static_cast<double> (n)));
	p.reset ();
	p.process (in.data (), l.data (), r.data (), static_cast<int> (in.size ()));
	std::complex<double> al = 0., ar = 0., ai = 0.;
	for (int n = 0; n < len; ++n)
	{
		const size_t i = static_cast<size_t> (settle + n);
		const std::complex<double> e = std::exp (std::complex<double> (0., -w * static_cast<double> (i)));
		al += static_cast<double> (l[i]) * e;
		ar += static_cast<double> (r[i]) * e;
		ai += static_cast<double> (in[i]) * e;
	}
	gl = al / ai;
	gr = ar / ai;
}
static double probeFreq (double f, double fs) { return std::max (1., std::round (f * 8192. / fs)) * fs / 8192.; }

//------------------------------------------------------------------------
static void testAllpassStages ()
{
	section ("all-pass stages: unit gain and phase at the break frequency");
	for (double fs : kRates)
	{
		for (double f0 : {60., 440., 2500.})
		{
			ModelConfig m = staticModel ();
			m.numStages = 1;
			m.dryGain = 0.;
			m.wetGainL = m.wetGainR = 1.;
			m.fCenterMin = m.fCenterMax = probeFreq (f0, fs);
			for (int kind = 0; kind < 2; ++kind)
			{
				m.stageKind = static_cast<StageKind> (kind);
				StereoPhaser p;
				p.setModel (m);
				p.prepare (fs);
				p.setDepth (0.);
				p.setResonance (0.);
				std::complex<double> gl, gr;
				measureGain (p, m.fCenterMin, gl, gr);
				const double expect = kind == 0 ? -90. : -180.;
				double ph = std::arg (gl) * 180. / kPi;
				if (kind == 1 && ph > 0.)
					ph -= 360.;
				check (std::fabs (std::abs (gl) - 1.) < 1e-4, "magnitude == 1", fmt ("fs=%.1f f=%.1f |H|=%.6f", fs, f0, std::abs (gl)));
				check (std::fabs (ph - expect) < 0.05, "phase at break frequency", fmt ("fs=%.1f f=%.1f phase=%.3f expect=%.0f", fs, f0, ph, expect));
			}
		}
	}
	std::printf ("    ok: first order = -90 deg, second order = -180 deg at the set frequency, |H| = 1\n");
}

//------------------------------------------------------------------------
static void testAudioMatchesAnalytic ()
{
	section ("audio path == analytic model (magnitude and phase)");
	std::mt19937 rng (7);
	std::uniform_real_distribution<double> u (0., 1.);
	double worst = 0.;
	int cases = 0;
	for (double fs : kRates)
	{
		for (int trial = 0; trial < 14; ++trial)
		{
			ModelConfig m = staticModel ();
			m.stageKind = trial % 3 == 2 ? StageKind::SecondOrder : StageKind::FirstOrder;
			const int counts[] = {2, 4, 6, 8, 10, 12};
			m.numStages = counts[trial % 6];
			if (m.stageKind == StageKind::SecondOrder)
				m.numStages = std::max (1, m.numStages / 2);
			for (int k = 0; k < kMaxStages; ++k)
				m.stageRatio[k] = trial % 4 == 1 ? std::pow (1.25, k) : 1.;
			m.negMode = static_cast<NegResonanceMode> (trial % 3);
			m.fbTapStage = trial % 5 == 3 ? std::max (1, m.numStages / 2) : 0;
			m.fbNormalize = trial % 2 ? 0.5 : 0.;
			m.fbMax = 0.8;
			m.wetGainR = -0.5;
			StereoPhaser p;
			p.setModel (m);
			p.prepare (fs);
			const double manual = 50. * u (rng);
			const double res = -45. + 90. * u (rng);
			p.setDepth (0.);
			p.setManual (manual);
			p.setResonance (res);
			const double sweep = laws::centerHz (p.model (), manual);
			for (double f0 : {70., 300., 1100., 4200., 9000.})
			{
				const double f = probeFreq (f0, fs);
				std::complex<double> gl, gr;
				measureGain (p, f, gl, gr);
				const auto hl = laws::channelResponse (p.model (), fs, sweep, res, p.model ().wetGainL, f);
				const auto hr = laws::channelResponse (p.model (), fs, sweep, res, p.model ().wetGainR, f);
				worst = std::max (worst, std::max (std::abs (gl - hl), std::abs (gr - hr)));
				++cases;
			}
		}
	}
	check (worst < 2e-3, "complex response error", fmt ("worst |H_audio - H_model| = %.2e", worst));
	std::printf ("    %d probe points, worst complex error %.2e\n", cases, worst);
}

//------------------------------------------------------------------------
static void testNotches ()
{
	section ("notch positions (equal first-order stages, no feedback)");
	for (double fs : kRates)
	{
		for (int stages : {2, 4, 6, 8, 12})
		{
			ModelConfig m = staticModel ();
			m.numStages = stages;
			const double fc = 700.;
			m.fCenterMin = m.fCenterMax = fc;
			double worstDb = -400.;
			for (int k = 0; k < stages / 2; ++k)
			{
				// N * (-2 atan(tan(pi f/fs)/tan(pi fc/fs))) = -(2k+1) pi
				const double x = std::tan (kPi * (2 * k + 1) / (2. * stages));
				const double fn = fs / kPi * std::atan (std::tan (kPi * fc / fs) * x);
				const auto h = laws::channelResponse (m, fs, fc, 0., m.wetGainL, fn);
				worstDb = std::max (worstDb, 20. * std::log10 (std::abs (h) + 1e-30));
			}
			check (worstDb < -200., "analytic notch depth", fmt ("fs=%.1f stages=%.0f depth=%.1f dB", fs, stages, worstDb));
		}
	}
	// and through the audio path
	ModelConfig m = staticModel ();
	m.numStages = 4;
	const double fs = 48000.;
	const double fn = probeFreq (1000., fs);
	// choose fc so that the first notch sits exactly on the probe frequency
	const double fc = fs / kPi * std::atan (std::tan (kPi * fn / fs) / std::tan (kPi / 8.));
	m.fCenterMin = m.fCenterMax = fc;
	StereoPhaser p;
	p.setModel (m);
	p.prepare (fs);
	p.setDepth (0.);
	std::complex<double> gl, gr;
	measureGain (p, fn, gl, gr);
	const double db = 20. * std::log10 (std::abs (gl) + 1e-30);
	check (db < -80., "audio notch depth", fmt ("%.1f dB at %.1f Hz", db, fn));
	std::printf ("    audio-path notch at %.1f Hz: %.1f dB\n", fn, db);
}

//------------------------------------------------------------------------
static double measureLfoHz (double fs, double shown, const ModelConfig& m, double seconds)
{
	StereoPhaser p;
	p.setModel (m);
	p.prepare (fs);
	p.setSpeed (shown);
	p.setDepth (50.);
	p.setManual (25.);
	p.reset ();
	const double center = laws::centerHz (p.model (), 25.);
	const int block = StereoPhaser::kControlInterval;
	std::vector<float> z (static_cast<size_t> (block), 0.f), l (z.size ()), r (z.size ());
	const long total = static_cast<long> (seconds * fs / block);
	double prev = p.sweepHzLeft ();
	double first = -1., last = -1.;
	int crossings = 0;
	for (long i = 0; i < total; ++i)
	{
		p.process (z.data (), l.data (), r.data (), block);
		const double cur = p.sweepHzLeft ();
		if (prev < center && cur >= center)
		{
			const double frac = (center - prev) / (cur - prev);
			const double t = (static_cast<double> (i) + frac) * block / fs;
			if (first < 0.)
				first = t;
			last = t;
			++crossings;
		}
		prev = cur;
	}
	return crossings > 1 ? (crossings - 1) / (last - first) : 0.;
}

static void testLfo ()
{
	section ("LFO rate accuracy (full periods, including 0.02 Hz)");
	double worst = 0.;
	for (double fs : kRates)
	{
		for (double hz : {0.02, 0.1, 0.5, 2.0, 9.5})
		{
			const double seconds = std::max (4., 3.2 / hz);
			const double got = measureLfoHz (fs, hz, defaultModel (), seconds);
			const double err = std::fabs (got - hz) / hz;
			worst = std::max (worst, err);
			check (err < 1e-3, "LFO rate", fmt ("fs=%.1f set=%.3f got=%.6f err=%.4f%%", fs, hz, got, err * 100.));
		}
	}
	std::printf ("    worst LFO rate error over 5 sample rates x 5 speeds: %.5f %%\n", worst * 100.);

	section ("LFO shapes");
	for (int s = 0; s < 4; ++s)
	{
		ModelConfig m;
		m.lfoShape = static_cast<LfoShape> (s);
		m.lfoSkew = 0.25;
		m.lfoWarp = 0.6;
		double lo = 9., hi = -9.;
		for (int i = 0; i < 100000; ++i)
		{
			const double v = laws::lfoValue (m, i / 100000.);
			lo = std::min (lo, v);
			hi = std::max (hi, v);
		}
		check (std::fabs (lo + 1.) < 1e-3 && std::fabs (hi - 1.) < 1e-3, "LFO range is -1..+1", fmt ("shape=%.0f lo=%.4f hi=%.4f", s, lo, hi));
	}
	{
		ModelConfig m;
		m.lfoShape = LfoShape::Triangle;
		check (std::fabs (laws::lfoValue (m, 0.125) - 0.5) < 1e-12, "triangle is linear");
		m.lfoShape = LfoShape::AsymTriangle;
		m.lfoSkew = 0.25;
		check (std::fabs (laws::lfoValue (m, 0.25) - 1.) < 1e-12, "asymmetric triangle peak at skew");
		check (std::fabs (laws::lfoValue (m, 0.625)) < 1e-12, "asymmetric triangle falling half");
	}
	std::printf ("    ok: sine, triangle, asymmetric triangle, warped sine\n");

	section ("sweep range follows Manual / Depth");
	{
		ModelConfig m;
		StereoPhaser p;
		p.setModel (m);
		p.prepare (48000.);
		p.setSpeed (2.);
		p.setDepth (50.);
		p.setManual (25.);
		p.reset ();
		std::vector<float> z (16, 0.f), l (16), r (16);
		double lo = 1e9, hi = 0.;
		for (int i = 0; i < 48000 * 2 / 16; ++i)
		{
			p.process (z.data (), l.data (), r.data (), 16);
			lo = std::min (lo, p.sweepHzLeft ());
			hi = std::max (hi, p.sweepHzLeft ());
		}
		const double c = laws::centerHz (m, 25.);
		const double w = laws::widthOct (m, 50.);
		check (std::fabs (lo / (c * std::exp2 (-w)) - 1.) < 2e-3, "sweep minimum", fmt ("lo=%.2f", lo));
		check (std::fabs (hi / (c * std::exp2 (w)) - 1.) < 2e-3, "sweep maximum", fmt ("hi=%.2f", hi));
		p.setDepth (0.);
		p.reset ();
		lo = 1e9;
		hi = 0.;
		for (int i = 0; i < 48000 / 16; ++i)
		{
			p.process (z.data (), l.data (), r.data (), 16);
			lo = std::min (lo, p.sweepHzLeft ());
			hi = std::max (hi, p.sweepHzLeft ());
		}
		check (hi - lo < 1e-9, "Depth 0 = no movement in the model", fmt ("spread=%.3e", hi - lo));
		std::printf ("    ok (H0 model: Depth 0 gives a static phaser - to be confirmed on hardware)\n");
	}
}

//------------------------------------------------------------------------
static void testStability ()
{
	section ("stability: extreme settings, all rates, all topologies");
	std::mt19937 rng (11);
	std::uniform_real_distribution<float> noise (-0.5f, 0.5f);
	std::uniform_real_distribution<double> u (0., 1.);
	double worstPeak = 0., worstRatio = 0.;
	int runs = 0;
	for (double fs : kRates)
	{
		for (int trial = 0; trial < 24; ++trial)
		{
			ModelConfig m;
			m.stageKind = trial % 4 == 3 ? StageKind::SecondOrder : StageKind::FirstOrder;
			m.numStages = 1 + trial % kMaxStages;
			m.fbMax = 0.98;
			m.negMode = static_cast<NegResonanceMode> (trial % 3);
			m.fbTapStage = trial % 2 ? 0 : std::max (1, m.numStages / 2);
			m.lfoShape = static_cast<LfoShape> (trial % 4);
			m.sweepLaw = static_cast<SweepLaw> (trial % 3);
			m.depthMaxOct = 6.;
			m.fCenterMin = 20.;
			m.fCenterMax = 18000.;
			for (int k = 0; k < kMaxStages; ++k)
				m.stageRatio[k] = 0.5 + 1.5 * u (rng);
			StereoPhaser p;
			p.setModel (m);
			p.prepare (fs);
			p.setSpeed (trial % 2 ? 9.5 : 0.02 + 9. * u (rng));
			p.setDepth (50.);
			p.setManual (50. * u (rng));
			p.setResonance (trial % 2 ? 50. : -50.);
			p.reset ();
			const int n = static_cast<int> (fs * 3.);
			std::vector<float> in (static_cast<size_t> (n), 0.f), l (in.size ()), r (in.size ());
			for (int i = 0; i < n / 3; ++i)
				in[static_cast<size_t> (i)] = noise (rng);
			in[0] = 1.f;
			p.process (in.data (), l.data (), r.data (), n);
			double peak = 0., eA = 0., eB = 0., eIn = 0., eOut = 0.;
			bool finite = true;
			for (int i = 0; i < n; ++i)
				eIn += static_cast<double> (in[static_cast<size_t> (i)]) * in[static_cast<size_t> (i)];
			for (int i = 0; i < n; ++i)
			{
				const double a = l[static_cast<size_t> (i)], b = r[static_cast<size_t> (i)];
				finite = finite && std::isfinite (a) && std::isfinite (b);
				peak = std::max (peak, std::max (std::fabs (a), std::fabs (b)));
				eOut += a * a;
				if (i >= n / 3 && i < n / 3 + n / 6)
					eA += a * a + b * b;
				if (i >= n - n / 6)
					eB += a * a + b * b;
			}
			worstPeak = std::max (worstPeak, peak);
			++runs;
			check (finite, "output is finite");
			// passive all-pass network inside a loop with |fb| < 1: the energy gain
			// can never exceed (|dry| + |wet| / (1 - |fb|))^2, whatever the modulation
			const double gmax = 0.5 + 0.5 / (1. - 0.98);
			worstRatio = std::max (worstRatio, std::sqrt (eOut / eIn) / gmax);
			check (eOut <= gmax * gmax * eIn * 1.0001, "energy gain within the passivity bound", fmt ("fs=%.1f trial=%.0f ratio=%.3f", fs, trial, std::sqrt (eOut / eIn) / gmax));
			check (peak < 60., "output is bounded", fmt ("fs=%.1f trial=%.0f peak=%.2f", fs, trial, peak));
			check (eB <= eA + 1e-12, "energy decays after the input stops", fmt ("fs=%.1f trial=%.0f", fs, trial));
		}
	}
	std::printf ("    %d runs with |feedback| = 0.98, fastest LFO, widest sweep: worst peak %.2f (input peak 1.0),\n"
	             "    worst energy gain = %.3f of the theoretical passivity limit\n", runs, worstPeak, worstRatio);
}

//------------------------------------------------------------------------
static void renderScript (Engine& e, const std::vector<float>& in, std::vector<float>& l, std::vector<float>& r,
                          const std::vector<int>& blocks)
{
	// parameter changes at fixed sample positions, independent of the block layout
	struct Ev { size_t at; double sp, de, ma, re; };
	const Ev evs[] = {{0, 0.7, 30., 20., 20.}, {7001, 9.5, 50., 45., -50.}, {20011, 0.02, 0., 5., 50.}, {33333, 3.3, 41., 33., -17.}};
	e.setParams (evs[0].sp, evs[0].de, evs[0].ma, evs[0].re);
	e.reset ();
	size_t pos = 0, bi = 0, ei = 1;
	while (pos < in.size ())
	{
		while (ei < 4 && evs[ei].at <= pos)
		{
			e.setParams (evs[ei].sp, evs[ei].de, evs[ei].ma, evs[ei].re);
			++ei;
		}
		size_t n = static_cast<size_t> (blocks[bi++ % blocks.size ()]);
		n = std::min (n, in.size () - pos);
		if (ei < 4)
			n = std::min (n, evs[ei].at - pos);
		e.process (in.data () + pos, l.data () + pos, r.data () + pos, static_cast<int> (n));
		pos += n;
	}
}

static void testBufferIndependence ()
{
	section ("buffer-size independence (bit-exact)");
	std::mt19937 rng (3);
	std::uniform_real_distribution<float> noise (-0.5f, 0.5f);
	for (int mode = 0; mode < 2; ++mode)
	{
		for (double fs : {44100., 96000.})
		{
			Engine e;
			e.prepare (fs);
			e.setMode (static_cast<EngineMode> (mode));
			std::vector<float> in (48000);
			for (float& v : in)
				v = noise (rng);
			std::vector<float> l0 (in.size ()), r0 (in.size ()), l (in.size ()), r (in.size ());
			renderScript (e, in, l0, r0, {512});
			const std::vector<std::vector<int>> layouts = {{1}, {3}, {16}, {17}, {64}, {480}, {4096}, {1, 255, 7, 1024, 33, 2}};
			for (const auto& lay : layouts)
			{
				renderScript (e, in, l, r, lay);
				const bool same = std::memcmp (l.data (), l0.data (), l.size () * sizeof (float)) == 0 &&
				                  std::memcmp (r.data (), r0.data (), r.size () * sizeof (float)) == 0;
				check (same, "identical output for a different block layout", fmt ("mode=%.0f fs=%.0f first block=%.0f", mode, fs, lay[0]));
			}
			check (e.underruns () == 0, "no FIFO under-run");
		}
	}
	std::printf ("    Native and Reference mode: 8 block layouts (1 .. 4096 samples, mixed) give bit-identical output\n");
}

//------------------------------------------------------------------------
static void testNoClicks ()
{
	section ("parameter jumps do not click");
	const double fs = 48000.;
	double worst = 0., reference = 0.;
	for (int pass = 0; pass < 2; ++pass)
	{
		Engine e;
		ModelConfig m;
		m.negMode = NegResonanceMode::InvertBoth; // hardest case: wet polarity flips
		e.setModel (m);
		e.prepare (fs);
		e.setParams (0.5, 0., 0., -50.);
		e.reset ();
		const int n = static_cast<int> (fs);
		std::vector<float> in (static_cast<size_t> (n)), l (in.size ()), r (in.size ());
		for (int i = 0; i < n; ++i)
			in[static_cast<size_t> (i)] = static_cast<float> (0.5 * std::sin (2. * kPi * 110. * i / fs));
		const int half = n / 2 + 5;
		e.process (in.data (), l.data (), r.data (), half);
		if (pass == 1)
			e.setParams (9.5, 50., 50., 50.); // everything jumps at once
		e.process (in.data () + half, l.data () + half, r.data () + half, n - half);
		double jump = 0.;
		for (int i = half - 2000; i < half + 6000; ++i)
		{
			jump = std::max (jump, static_cast<double> (std::fabs (l[static_cast<size_t> (i)] - l[static_cast<size_t> (i - 1)])));
			jump = std::max (jump, static_cast<double> (std::fabs (r[static_cast<size_t> (i)] - r[static_cast<size_t> (i - 1)])));
		}
		(pass == 0 ? reference : worst) = jump;
	}
	std::printf ("    largest sample-to-sample step: steady %.4f, during a full-range jump of all four controls %.4f (input peak 0.5)\n", reference, worst);
	check (worst < 0.12, "no discontinuity on parameter jump", fmt ("step=%.4f", worst));
}

//------------------------------------------------------------------------
static void testStereo ()
{
	section ("stereo behaviour (mono in -> stereo out)");
	std::mt19937 rng (5);
	std::uniform_real_distribution<float> noise (-0.5f, 0.5f);
	const double fs = 48000.;
	std::vector<float> in (static_cast<size_t> (fs * 4));
	for (float& v : in)
		v = noise (rng);
	auto run = [&] (double phaseDeg, double& corr, double& midDb, double& sideDb) {
		ModelConfig m;
		m.stereoPhaseDeg = phaseDeg;
		StereoPhaser p;
		p.setModel (m);
		p.prepare (fs);
		p.setSpeed (1.);
		p.setDepth (40.);
		p.setManual (25.);
		p.setResonance (25.);
		p.reset ();
		std::vector<float> l (in.size ()), r (in.size ());
		p.process (in.data (), l.data (), r.data (), static_cast<int> (in.size ()));
		double ll = 0., rr = 0., lr = 0., mm = 0., ss = 0.;
		for (size_t i = 0; i < in.size (); ++i)
		{
			const double a = l[i], b = r[i];
			ll += a * a;
			rr += b * b;
			lr += a * b;
			mm += 0.25 * (a + b) * (a + b);
			ss += 0.25 * (a - b) * (a - b);
		}
		corr = lr / std::sqrt (ll * rr);
		midDb = 10. * std::log10 (mm / in.size () + 1e-30);
		sideDb = 10. * std::log10 (ss / in.size () + 1e-30);
	};
	double c0, m0, s0, c90, m90, s90, c180, m180, s180;
	run (0., c0, m0, s0);
	run (90., c90, m90, s90);
	run (180., c180, m180, s180);
	check (std::fabs (c0 - 1.) < 1e-9 && s0 < -200., "0 deg LFO offset gives L == R");
	check (c90 < 0.999 && c90 > -1., "90 deg offset decorrelates L/R", fmt ("corr=%.4f", c90));
	check (s180 > s90, "larger LFO offset gives more side energy");
	std::printf ("    LFO offset   correlation   mid dB   side dB\n");
	std::printf ("    0 deg        %+.4f       %6.1f   %6.1f\n", c0, m0, s0);
	std::printf ("    90 deg       %+.4f       %6.1f   %6.1f\n", c90, m90, s90);
	std::printf ("    180 deg      %+.4f       %6.1f   %6.1f\n", c180, m180, s180);
	std::printf ("    (the stereo image comes from the two all-pass networks only: no widener, no Haas delay)\n");
}

//------------------------------------------------------------------------
static double toneLevelDb (const std::vector<float>& x, size_t from, size_t len, double f, double fs)
{
	std::complex<double> acc = 0.;
	double wsum = 0.;
	for (size_t n = 0; n < len; ++n)
	{
		const double w = 0.5 - 0.5 * std::cos (2. * kPi * static_cast<double> (n) / static_cast<double> (len));
		acc += w * static_cast<double> (x[from + n]) * std::exp (std::complex<double> (0., -2. * kPi * f * static_cast<double> (n) / fs));
		wsum += w;
	}
	return 20. * std::log10 (2. * std::abs (acc) / wsum + 1e-30);
}

static void testReferenceMode ()
{
	section ("Reference mode: 39.0625 kHz internal rate");
	ModelConfig through; // dry only: isolates the sample-rate conversion
	through.dryGain = 1.;
	through.wetGainL = through.wetGainR = 0.;
	std::printf ("    host rate   latency   gain 1k   gain 15k   gain 18k   gain 19k   alias of 20.5k tone\n");
	for (double fs : {44100., 48000., 88200., 96000.})
	{
		Engine e;
		e.setModel (through);
		e.prepare (fs);
		e.setMode (EngineMode::Reference);
		const int lat = e.latency ();

		// latency: impulse position
		std::vector<float> in (8192, 0.f), l (in.size ()), r (in.size ());
		in[1000] = 1.f;
		e.reset ();
		e.process (in.data (), l.data (), r.data (), static_cast<int> (in.size ()));
		size_t peakAt = 0;
		for (size_t i = 0; i < l.size (); ++i)
			if (std::fabs (l[i]) > std::fabs (l[peakAt]))
				peakAt = i;
		check (static_cast<int> (peakAt) == 1000 + lat, "reported latency == measured latency", fmt ("fs=%.0f reported=%.0f measured=%.0f", fs, lat, static_cast<double> (peakAt) - 1000.));

		// pass-band and alias measurements
		const size_t len = static_cast<size_t> (fs);
		std::vector<float> x (len * 2), yl (x.size ()), yr (x.size ());
		double g[4];
		const double fr[4] = {1000., 15000., 18000., 19000.};
		for (int k = 0; k < 4; ++k)
		{
			for (size_t n = 0; n < x.size (); ++n)
				x[n] = static_cast<float> (0.5 * std::sin (2. * kPi * fr[k] * static_cast<double> (n) / fs));
			e.reset ();
			e.process (x.data (), yl.data (), yr.data (), static_cast<int> (x.size ()));
			g[k] = toneLevelDb (yl, len / 2, len, fr[k], fs) - 20. * std::log10 (0.5);
		}
		for (size_t n = 0; n < x.size (); ++n)
			x[n] = static_cast<float> (0.5 * std::sin (2. * kPi * 20500. * static_cast<double> (n) / fs));
		e.reset ();
		e.process (x.data (), yl.data (), yr.data (), static_cast<int> (x.size ()));
		const double alias = toneLevelDb (yl, len / 2, len, kReferenceSampleRate - 20500., fs) - 20. * std::log10 (0.5);
		check (std::fabs (g[0]) < 0.01 && std::fabs (g[1]) < 0.1, "flat pass-band to 15 kHz", fmt ("fs=%.0f g1k=%.3f g15k=%.3f", fs, g[0], g[1]));
		check (e.underruns () == 0, "no FIFO under-run");
		std::printf ("    %7.0f     %4d      %+.3f    %+.3f     %+.3f     %+.3f     %.1f dB\n", fs, lat, g[0], g[1], g[2], g[3], alias);
	}

	// random block sizes for a long run: FIFO must never under-run or drift
	{
		Engine e;
		e.prepare (44100.);
		e.setMode (EngineMode::Reference);
		std::mt19937 rng (9);
		std::uniform_int_distribution<int> bs (1, 3000);
		std::vector<float> in (3000, 0.1f), l (3000), r (3000);
		long total = 0;
		while (total < 44100L * 120)
		{
			const int n = bs (rng);
			e.process (in.data (), l.data (), r.data (), n);
			total += n;
		}
		check (e.underruns () == 0, "120 s with random block sizes: no under-run");
	}

	section ("Native vs Reference: where the two modes differ");
	std::printf ("    4 equal first-order stages; second notch frequency for the same control setting\n");
	std::printf ("    sweep Hz    @39062.5     @44100      @48000      @96000   (Hz)\n");
	for (double fc : {300., 1000., 3000., 6000.})
	{
		std::printf ("    %7.0f ", fc);
		for (double fs : {39062.5, 44100., 48000., 96000.})
		{
			const double fn = fs / kPi * std::atan (std::tan (kPi * fc / fs) * std::tan (3. * kPi / 8.));
			std::printf ("  %9.1f ", fn);
		}
		std::printf ("\n");
	}
	std::printf ("    (upper notches depend on the processing rate - this is what Reference mode reproduces)\n");
}

//------------------------------------------------------------------------
static void testPedalAndIO ()
{
	section ("PRESSURE pedal logic");
	UserParams base;
	base.speedHz = 1.;
	base.depth = 10.;
	base.manual = 20.;
	base.resonance = 5.;
	UserParams p = applyPedal (base, PedalTarget::Off, 0., 1., 0.7);
	check (p.speedHz == 1. && p.depth == 10. && p.manual == 20. && p.resonance == 5., "pedal Off changes nothing");
	p = applyPedal (base, PedalTarget::Depth, 0., 1., 0.5);
	check (std::fabs (p.depth - 25.) < 1e-12 && p.manual == 20., "Depth: half pedal = 25");
	p = applyPedal (base, PedalTarget::Manual, 0.2, 0.8, 0.);
	check (std::fabs (p.manual - 10.) < 1e-12, "MIN is the released value");
	p = applyPedal (base, PedalTarget::Manual, 0.2, 0.8, 1.);
	check (std::fabs (p.manual - 40.) < 1e-12, "MAX is the fully pressed value");
	p = applyPedal (base, PedalTarget::Resonance, 1., 0., 0.25);
	check (std::fabs (p.resonance - 25.) < 1e-12, "MIN above MAX works in reverse");
	p = applyPedal (base, PedalTarget::Speed, 0., 1., 0.);
	check (std::fabs (p.speedHz - 0.02) < 1e-12, "Speed MIN limit = 0.02 Hz");
	p = applyPedal (base, PedalTarget::Speed, 0., 1., 1.);
	check (std::fabs (p.speedHz - 9.5) < 1e-9, "Speed MAX limit = 9.5 Hz");
	for (double x : {0., 0.13, 0.5, 0.99, 1.})
		check (std::fabs (speedToNorm (speedFromNorm (x)) - x) < 1e-12, "speed scale round trip");
	std::printf ("    ok\n");

	section ("pedal really changes the audio");
	{
		Engine a, b;
		a.prepare (48000.);
		b.prepare (48000.);
		UserParams ua = applyPedal (base, PedalTarget::Manual, 0., 1., 0.);
		UserParams ub = applyPedal (base, PedalTarget::Manual, 0., 1., 1.);
		a.setParams (ua.speedHz, ua.depth, ua.manual, ua.resonance);
		b.setParams (ub.speedHz, ub.depth, ub.manual, ub.resonance);
		a.reset ();
		b.reset ();
		std::mt19937 rng (1);
		std::uniform_real_distribution<float> noise (-0.5f, 0.5f);
		std::vector<float> in (24000), la (24000), ra (24000), lb (24000), rb (24000);
		for (float& v : in)
			v = noise (rng);
		a.process (in.data (), la.data (), ra.data (), 24000);
		b.process (in.data (), lb.data (), rb.data (), 24000);
		double diff = 0.;
		for (size_t i = 0; i < la.size (); ++i)
			diff += std::fabs (la[i] - lb[i]);
		check (diff > 100., "pedal released vs pressed gives different audio", fmt ("sum|diff|=%.1f", diff));
		std::printf ("    ok\n");
	}

	section ("model JSON round trip");
	ModelConfig m;
	m.numStages = 6;
	m.stageRatio[3] = 1.37;
	m.negMode = NegResonanceMode::InvertBoth;
	m.lfoShape = LfoShape::AsymTriangle;
	m.fCenterMax = 4321.5;
	ModelConfig back;
	check (modelFromJson (modelToJson (m), back), "parse");
	check (back.numStages == 6 && std::fabs (back.stageRatio[3] - 1.37) < 1e-9 && back.negMode == m.negMode &&
	           back.lfoShape == m.lfoShape && std::fabs (back.fCenterMax - 4321.5) < 1e-6,
	       "values survive");
	check (defaultModel ().fittedToHardware == 0, "shipped model is marked as NOT fitted to hardware");
	std::printf ("    ok (shipped model: '%s', fittedToHardware=%d)\n", defaultModel ().name, defaultModel ().fittedToHardware);
}


//------------------------------------------------------------------------
static void testPluginCore ()
{
	std::mt19937 rng (21);
	std::uniform_real_distribution<float> noise (-0.5f, 0.5f);
	const int n = 8192;
	std::vector<float> in (static_cast<size_t> (n)), in2 (in.size ());
	for (float& v : in)
		v = noise (rng);
	for (float& v : in2)
		v = noise (rng);

	section ("automation is sample accurate");
	for (int mode = 0; mode < 2; ++mode)
	{
		const CoreEvent evs[] = {{100, kCoreManual, 0.9}, {100, kCoreDepth, 0.1}, {1777, kCoreResonance, 0.02},
		                         {3000, kCoreBypass, 1.}, {5001, kCoreBypass, 0.}, {6000, kCoreSpeed, 1.}};
		PluginCore a, b, c;
		for (PluginCore* p : {&a, &b, &c})
		{
			p->prepare (48000.);
			p->setParam (kCoreEngineMode, mode);
			p->reset ();
		}
		std::vector<float> la (in.size ()), ra (in.size ()), lb (in.size ()), rb (in.size ()), lc (in.size ()), rc (in.size ());
		// a: one block, events with sample offsets
		a.process (in.data (), nullptr, la.data (), ra.data (), n, evs, 6);
		// b: the same changes done by hand between separately processed pieces
		int pos = 0;
		for (int k = 0; k <= 6; ++k)
		{
			const int end = k < 6 ? evs[k].offset : n;
			if (end > pos)
				b.process (in.data () + pos, nullptr, lb.data () + pos, rb.data () + pos, end - pos, nullptr, 0);
			pos = end;
			if (k < 6)
				b.setParam (evs[k].param, evs[k].value);
		}
		// c: different host block size (333), offsets relative to each block
		pos = 0;
		while (pos < n)
		{
			const int len = std::min (333, n - pos);
			CoreEvent local[6];
			int cnt = 0;
			for (const CoreEvent& e : evs)
				if (e.offset >= pos && e.offset < pos + len)
					local[cnt++] = {e.offset - pos, e.param, e.value};
			c.process (in.data () + pos, nullptr, lc.data () + pos, rc.data () + pos, len, local, cnt);
			pos += len;
		}
		const bool ab = std::memcmp (la.data (), lb.data (), la.size () * 4) == 0 && std::memcmp (ra.data (), rb.data (), ra.size () * 4) == 0;
		const bool ac = std::memcmp (la.data (), lc.data (), la.size () * 4) == 0 && std::memcmp (ra.data (), rc.data (), ra.size () * 4) == 0;
		check (ab, "event offsets == manual split at the same samples", fmt ("mode=%.0f", mode));
		check (ac, "same automation with another host block size", fmt ("mode=%.0f", mode));
	}
	std::printf ("    ok: bit-identical in Native and Reference mode\n");

	section ("bypass is transparent and time-aligned");
	double worstJump = 0.;
	for (int mode = 0; mode < 2; ++mode)
	{
		PluginCore p;
		p.prepare (44100.);
		p.setParam (kCoreEngineMode, mode);
		p.setParam (kCoreBypass, 1.);
		p.reset ();
		std::vector<float> l (in.size ()), r (in.size ());
		p.process (in.data (), nullptr, l.data (), r.data (), n, nullptr, 0);
		const int lat = p.latencySamples ();
		double worst = 0.;
		for (int i = lat; i < n; ++i)
		{
			worst = std::max (worst, static_cast<double> (std::fabs (l[static_cast<size_t> (i)] - in[static_cast<size_t> (i - lat)])));
			worst = std::max (worst, static_cast<double> (std::fabs (r[static_cast<size_t> (i)] - in[static_cast<size_t> (i - lat)])));
		}
		check (worst == 0., "bypassed output == input (delayed by the reported latency)", fmt ("mode=%.0f latency=%.0f err=%.3e", mode, lat, worst));
		check (mode == 0 ? lat == 0 : lat > 0, "latency: 0 in Native, > 0 in Reference");
		// switching bypass while audio runs must not jump (continuous sine across both blocks)
		const CoreEvent off[] = {{0, kCoreBypass, 0.}};
		std::vector<float> sine (in.size () * 2), lo (sine.size ()), ro (sine.size ());
		for (size_t i = 0; i < sine.size (); ++i)
			sine[i] = static_cast<float> (0.5 * std::sin (2. * kPi * 110. * static_cast<double> (i) / 44100.));
		p.process (sine.data (), nullptr, lo.data (), ro.data (), n, nullptr, 0);
		p.process (sine.data () + n, nullptr, lo.data () + n, ro.data () + n, n, off, 1);
		double jump = 0.;
		for (size_t i = static_cast<size_t> (n) - 100; i < lo.size (); ++i)
		{
			jump = std::max (jump, static_cast<double> (std::fabs (lo[i] - lo[i - 1])));
			jump = std::max (jump, static_cast<double> (std::fabs (ro[i] - ro[i - 1])));
		}
		worstJump = std::max (worstJump, jump);
		check (jump < 0.03, "bypass off: cross-fade, no click", fmt ("mode=%.0f step=%.4f", mode, jump));
	}
	std::printf ("    ok: exact copy of the input; switching back in: largest step %.4f (a 110 Hz sine alone steps 0.0078)\n", worstJump);

	section ("mono in -> stereo out, stereo input, in-place buffers");
	{
		PluginCore a, b, c;
		std::vector<float> la (in.size ()), ra (in.size ()), lb (in.size ()), rb (in.size ());
		std::vector<float> mono (in.size ());
		for (size_t i = 0; i < in.size (); ++i)
			mono[i] = 0.5f * (in[i] + in2[i]);
		a.process (mono.data (), nullptr, la.data (), ra.data (), n, nullptr, 0);
		b.process (in.data (), in2.data (), lb.data (), rb.data (), n, nullptr, 0);
		check (std::memcmp (la.data (), lb.data (), la.size () * 4) == 0 && std::memcmp (ra.data (), rb.data (), ra.size () * 4) == 0,
		       "stereo input is summed to mono (L+R)/2");
		double diff = 0.;
		for (size_t i = 0; i < la.size (); ++i)
			diff += std::fabs (la[i] - ra[i]);
		check (diff > 1., "left and right outputs differ (stereo effect)");
		std::vector<float> x = in, y = in2; // in-place: outputs overwrite the inputs
		c.process (x.data (), y.data (), x.data (), y.data (), n, nullptr, 0);
		check (std::memcmp (x.data (), lb.data (), la.size () * 4) == 0 && std::memcmp (y.data (), rb.data (), ra.size () * 4) == 0,
		       "in-place processing gives the same result");
		std::printf ("    ok\n");
	}

	section ("PRESSURE pedal drives the real DSP parameter");
	{
		// pedal assigned to Manual (MIN 0, MAX 50) and moved  ==  Manual itself moved the same way
		PluginCore a, b;
		a.setParam (kCorePedalTarget, pedalTargetToNorm (PedalTarget::Manual));
		a.setParam (kCorePedalMin, 0.);
		a.setParam (kCorePedalMax, 1.);
		a.setParam (kCorePedalPos, 0.2);
		b.setParam (kCoreManual, 0.2);
		a.reset ();
		b.reset ();
		const CoreEvent ea[] = {{1000, kCorePedalPos, 0.9}, {4000, kCorePedalPos, 0.1}};
		const CoreEvent eb[] = {{1000, kCoreManual, 0.9}, {4000, kCoreManual, 0.1}};
		std::vector<float> la (in.size ()), ra (in.size ()), lb (in.size ()), rb (in.size ());
		a.process (in.data (), nullptr, la.data (), ra.data (), n, ea, 2);
		b.process (in.data (), nullptr, lb.data (), rb.data (), n, eb, 2);
		check (std::memcmp (la.data (), lb.data (), la.size () * 4) == 0, "pedal -> Manual == moving Manual");
		check (std::fabs (a.effectiveParams ().manual - 5.) < 1e-9, "effective value follows the pedal");

		// MIN / MAX limits and all four targets
		for (int t = 1; t <= 4; ++t)
		{
			PluginCore p;
			p.setParam (kCorePedalTarget, pedalTargetToNorm (static_cast<PedalTarget> (t)));
			p.setParam (kCorePedalMin, 0.25);
			p.setParam (kCorePedalMax, 0.75);
			p.setParam (kCorePedalPos, 0.);
			const UserParams lo = p.effectiveParams ();
			p.setParam (kCorePedalPos, 1.);
			const UserParams hi = p.effectiveParams ();
			const double vlo[] = {0., lo.speedHz, lo.depth, lo.manual, lo.resonance};
			const double vhi[] = {0., hi.speedHz, hi.depth, hi.manual, hi.resonance};
			const double elo = targetPlainFromNorm (static_cast<PedalTarget> (t), 0.25);
			const double ehi = targetPlainFromNorm (static_cast<PedalTarget> (t), 0.75);
			check (std::fabs (vlo[t] - elo) < 1e-9 && std::fabs (vhi[t] - ehi) < 1e-9, "MIN/MAX respected for every target", fmt ("target=%.0f", t));
		}
		std::printf ("    ok: Speed, Depth, Manual, Resonance\n");
	}

	section ("preset recall: same parameter values -> same audio");
	{
		PluginCore a, b;
		const double vals[kCoreNumParams] = {0., 0.71, 0.33, 0.62, 0.9, 0.5, 0.1, 0.8, 0.4, 1.};
		for (int i = 0; i < kCoreNumParams; ++i)
			a.setParam (i, vals[i]);
		a.reset ();
		double saved[kCoreNumParams];
		for (int i = 0; i < kCoreNumParams; ++i)
			saved[i] = a.getParam (i);
		for (int i = 0; i < kCoreNumParams; ++i)
			b.setParam (i, saved[i]);
		b.reset ();
		std::vector<float> la (in.size ()), ra (in.size ()), lb (in.size ()), rb (in.size ());
		a.process (in.data (), nullptr, la.data (), ra.data (), n, nullptr, 0);
		b.process (in.data (), nullptr, lb.data (), rb.data (), n, nullptr, 0);
		check (std::memcmp (la.data (), lb.data (), la.size () * 4) == 0 && std::memcmp (ra.data (), rb.data (), ra.size () * 4) == 0, "identical render after recall");
		std::printf ("    ok\n");
	}

	section ("sample-rate change is safe");
	{
		PluginCore p;
		std::vector<float> l (in.size ()), r (in.size ());
		bool finite = true;
		for (double fs : {44100., 96000., 48000., 22050., 192000., 44100.})
		{
			for (int mode = 0; mode < 2; ++mode)
			{
				p.prepare (fs);
				p.setParam (kCoreEngineMode, mode);
				p.process (in.data (), nullptr, l.data (), r.data (), n, nullptr, 0);
				for (float v : l)
					finite = finite && std::isfinite (v);
				check (p.engine ().underruns () == 0, "no under-run after rate change", fmt ("fs=%.0f", fs));
			}
		}
		check (finite, "finite output at every rate");
		std::printf ("    ok: 22.05 k .. 192 k, both modes\n");
	}
}

//------------------------------------------------------------------------
static void benchmark ()
{
	section ("CPU cost on THIS test machine (not an iMac 2011)");
	std::vector<float> in (512, 0.1f), l (512), r (512);
	std::printf ("    host rate   mode        stages   x real-time   CPU %% of one core\n");
	for (double fs : {44100., 96000.})
	{
		for (int mode = 0; mode < 2; ++mode)
		{
			for (int stages : {4, 12})
			{
				ModelConfig m;
				m.numStages = stages;
				Engine e;
				e.setModel (m);
				e.prepare (fs);
				e.setMode (static_cast<EngineMode> (mode));
				e.setParams (2., 50., 25., 40.);
				const long blocks = static_cast<long> (fs * 20. / 512.);
				const auto t0 = std::chrono::steady_clock::now ();
				for (long i = 0; i < blocks; ++i)
					e.process (in.data (), l.data (), r.data (), 512);
				const double sec = std::chrono::duration<double> (std::chrono::steady_clock::now () - t0).count ();
				const double xrt = 20. / sec;
				std::printf ("    %7.0f     %-9s   %3d      %8.0f      %.2f\n", fs, mode ? "Reference" : "Native", stages, xrt, 100. / xrt);
				check (xrt > 10., "faster than 10x real-time");
			}
		}
	}
}

int main ()
{
	std::printf ("SPHS DSP tests - model under test: '%s' (fittedToHardware=%d)\n", defaultModel ().name, defaultModel ().fittedToHardware);
	testAllpassStages ();
	testAudioMatchesAnalytic ();
	testNotches ();
	testLfo ();
	testStability ();
	testBufferIndependence ();
	testNoClicks ();
	testStereo ();
	testReferenceMode ();
	testPedalAndIO ();
	testPluginCore ();
	benchmark ();
	std::printf ("\n%d checks, %d failed\n", g_checks, g_failed);
	return g_failed == 0 ? 0 : 1;
}
