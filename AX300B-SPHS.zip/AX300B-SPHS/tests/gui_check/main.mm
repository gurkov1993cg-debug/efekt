// Development check only (Linux + GNUstep): opens the Cocoa editor view in a
// plain window with a real Controller behind it, so drawing and mouse handling
// can be exercised without a Mac. It is not part of the plug-in.
#import <AppKit/AppKit.h>
#include "Controller.h"
#include "Editor.h"
#include "pluginterfaces/gui/iplugview.h"

int main ()
{
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	[NSApplication sharedApplication];
	NSWindow* window = [[NSWindow alloc] initWithContentRect:NSMakeRect (40, 40, sphsvst::Editor::kWidth, sphsvst::Editor::kHeight)
	                                               styleMask:NSTitledWindowMask
	                                                 backing:NSBackingStoreBuffered
	                                                   defer:NO];
	[window setTitle:@"SPHS editor check"];
	auto* controller = new sphsvst::Controller ();
	controller->initialize (nullptr);
	Steinberg::IPlugView* view = controller->createView (Steinberg::Vst::ViewType::kEditor);
	if (!view || view->attached ((void*)[window contentView], Steinberg::kPlatformTypeNSView) != Steinberg::kResultTrue)
		return 1;
	[window makeKeyAndOrderFront:nil];
	[NSApp run];
	[pool release];
	return 0;
}
