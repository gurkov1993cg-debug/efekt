"""SPHS research suite: measure a real AX300B, analyse the recordings and fit the
grey-box model used by the plug-in. Nothing in this package contains or invents
reference data - without recordings of a real unit it produces no fitted model."""
REFERENCE_RATE = 39062.5  # documented internal sampling frequency of the original
