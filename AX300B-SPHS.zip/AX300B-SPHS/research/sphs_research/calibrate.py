"""Loop-back check of the audio interface (output cabled straight to the input).

    python -m sphs_research.calibrate session

Record stimuli/log_chirp.wav through the loop-back as takes/loopback_log_chirp.wav.
Reports round-trip delay, gain, flatness, noise and clipping, and stores them in
session/calibration.json so the levels used for the session are documented."""
import argparse
import json
import os
import numpy as np
from scipy.signal import correlate
from .analyze import read_wav


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("session")
    a = ap.parse_args()
    fs, stim = read_wav(os.path.join(a.session, "stimuli/log_chirp.wav"))
    path = os.path.join(a.session, "takes/loopback_log_chirp.wav")
    if not os.path.exists(path):
        raise SystemExit("missing %s - record the loop-back first" % path)
    fs2, cap = read_wav(path)
    if fs2 != fs:
        raise SystemExit("sample rate mismatch: %d vs %d" % (fs2, fs))
    x = stim[:, 0]
    out = dict(rate=fs, channels=[])
    for c in range(cap.shape[1]):
        y = cap[:, c]
        n = min(len(x), len(y))
        lag = int(np.argmax(np.abs(correlate(y[:n], x[:n], mode="full")))) - (n - 1)
        ya = y[max(0, lag):max(0, lag) + n]
        xa = x[:len(ya)]
        X, Y = np.fft.rfft(xa), np.fft.rfft(ya)
        f = np.fft.rfftfreq(len(xa), 1.0 / fs)
        band = (f > 30) & (f < 18000)
        h = 20 * np.log10(np.abs(Y[band]) / (np.abs(X[band]) + 1e-12) + 1e-12)
        k = max(1, len(h) // 400)
        hs = np.convolve(h, np.ones(k) / k, mode="valid")
        noise = y[:int(0.3 * fs)]
        out["channels"].append(dict(delay_samples=lag, gain_db=float(np.median(h)), flatness_db=float(np.ptp(hs)),
                                    peak=float(np.max(np.abs(y))), clipping=bool(np.max(np.abs(y)) > 0.98),
                                    noise_dbfs=float(20 * np.log10(np.sqrt(np.mean(noise ** 2)) + 1e-30))))
    with open(os.path.join(a.session, "calibration.json"), "w") as fjson:
        json.dump(out, fjson, indent=2)
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
