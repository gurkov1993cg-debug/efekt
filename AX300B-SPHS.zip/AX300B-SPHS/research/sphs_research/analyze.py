"""Step 2: analyse the recorded takes (model-free measurements).

    python -m sphs_research.analyze session

Writes session/analysis.json: time-varying transfer functions are reduced to
notch trajectories, LFO rate, L/R LFO offset, stereo correlation, Mid/Side
energy, amplitude movement, THD+N and noise. Takes that are missing are
reported as missing - nothing is estimated or filled in."""
import argparse
import json
import os
import numpy as np
from scipy.io import wavfile
from scipy.signal import correlate
from .signals import sync_burst, multisine


def read_wav(path):
    rate, data = wavfile.read(path)
    if data.dtype.kind == "i":
        data = data.astype(np.float64) / float(2 ** (8 * data.dtype.itemsize - 1))
    elif data.dtype.kind == "u":
        data = (data.astype(np.float64) - 128.0) / 128.0
    data = np.atleast_2d(data.astype(np.float64).T).T
    return rate, data


def find_offset(capture, meta, search_ms=400.0):
    """Delay (samples) of the recording against the stimulus, from the sync chirp."""
    fs = meta["rate"]
    sync = sync_burst(fs)
    span = int(search_ms * 0.001 * fs)
    a = max(0, meta["sync_start"] - span // 4)
    seg = capture[a:meta["sync_start"] + len(sync) + span].sum(axis=1)
    c = correlate(seg, sync, mode="valid")
    return int(np.argmax(np.abs(c))) + a - meta["sync_start"]


def excited_bins(meta):
    n, fs = meta["period"], meta["rate"]
    k = np.arange(n // 2 + 1)
    return np.where((k * fs / n >= 40.0) & (k * fs / n <= min(16000.0, 0.45 * fs)) & (k > 0))[0]


def bypass_reference(capture, meta, offset):
    """Average spectrum of one multisine period, per channel (the measurement chain without the effect)."""
    n = meta["period"]
    start = meta["ms_start"] + offset + n
    count = max(1, min(meta["repeats"] - 3, (len(capture) - start) // n - 1))
    acc = np.zeros((capture.shape[1], n // 2 + 1), dtype=complex)
    for i in range(count):
        acc += np.fft.rfft(capture[start + i * n:start + (i + 1) * n].T, axis=1)
    return acc / count


def tv_response(capture, meta, offset, ref, hop_div=4):
    """Time-varying transfer function from overlapping one-period frames.
    Returns times [s], frequencies [Hz], H[channel, frame, bin] (complex)."""
    n, fs = meta["period"], meta["rate"]
    bins = excited_bins(meta)
    hop = max(1, n // hop_div)
    start = meta["ms_start"] + offset + n
    stop = min(len(capture), meta["ms_start"] + offset + (meta["repeats"] - 1) * n) - n
    starts = np.arange(start, stop, hop)
    channels = min(2, capture.shape[1])
    if ref.shape[0] < channels:
        ref = np.repeat(ref, channels, axis=0)
    H = np.zeros((channels, len(starts), len(bins)), dtype=complex)
    for i, s in enumerate(starts):
        shift = (s - start) % n
        rot = np.exp(2j * np.pi * bins * shift / n)
        Y = np.fft.rfft(capture[s:s + n, :channels].T, axis=1)[:, bins]
        H[:, i, :] = Y / (ref[:channels][:, bins] * rot)
    times = (starts - (meta["ms_start"] + offset) + n / 2.0) / fs
    return times, bins * fs / n, H


def lowest_notch(freqs, mag_db, min_depth_db=6.0):
    """Frequency of the lowest clear notch in one magnitude curve (NaN if none)."""
    k = max(1, len(mag_db) // 96)
    sm = np.convolve(mag_db, np.ones(2 * k + 1) / (2 * k + 1), mode="same")
    ref = np.median(sm)
    lf = np.log2(freqs)
    for i in range(2, len(sm) - 2):
        if sm[i] < sm[i - 1] and sm[i] <= sm[i + 1] and sm[i] < ref - min_depth_db:
            a, b = max(1, i - k), min(len(mag_db) - 2, i + k)
            j = a + int(np.argmin(mag_db[a:b + 1]))  # exact minimum of the raw curve near the dip
            y0, y1, y2 = mag_db[j - 1], mag_db[j], mag_db[j + 1]
            d = y0 - 2 * y1 + y2
            frac = 0.5 * (y0 - y2) / d if d > 1e-9 else 0.0
            return float(2.0 ** (lf[j] + np.clip(frac, -1, 1) * 0.5 * (lf[j + 1] - lf[j - 1])))
    return float("nan")


def all_notches(freqs, mag_db, min_depth_db=6.0):
    """(log2 frequency, depth dB) of every clear notch in one magnitude curve."""
    k = max(1, len(mag_db) // 96)
    sm = np.convolve(mag_db, np.ones(2 * k + 1) / (2 * k + 1), mode="same")
    ref = np.median(sm)
    lf = np.log2(freqs)
    found = []
    for i in range(2, len(sm) - 2):
        if sm[i] < sm[i - 1] and sm[i] <= sm[i + 1] and sm[i] < ref - min_depth_db:
            a, b = max(1, i - k), min(len(mag_db) - 2, i + k)
            j = a + int(np.argmin(mag_db[a:b + 1]))
            y0, y1, y2 = mag_db[j - 1], mag_db[j], mag_db[j + 1]
            d = y0 - 2 * y1 + y2
            frac = 0.5 * (y0 - y2) / d if d > 1e-9 else 0.0
            found.append((lf[j] + np.clip(frac, -1, 1) * 0.5 * (lf[j + 1] - lf[j - 1]), ref - y1))
    return found


def track_notch(freqs, mags, max_jump_oct=0.35):
    """Follows ONE notch from frame to frame (nearest neighbour in log frequency),
    so that the track does not hop between different notches of the phaser."""
    per_frame = [all_notches(freqs, m) for m in mags]
    track = np.full(len(mags), np.nan)
    counts = [len(n) for n in per_frame]
    if not any(counts):
        return track
    start = int(np.argmax(counts))
    seed = max(per_frame[start], key=lambda n: n[1])[0]
    for direction in (1, -1):
        cur = seed
        i = start if direction == 1 else start - 1
        while 0 <= i < len(mags):
            if per_frame[i]:
                near = min(per_frame[i], key=lambda n: abs(n[0] - cur))
                if abs(near[0] - cur) <= max_jump_oct:
                    cur = near[0]
                    track[i] = 2.0 ** cur
            i += direction
    return track


def periodic_rate(times, values):
    """Dominant modulation rate [Hz] of a trajectory (interpolated periodogram)."""
    ok = np.isfinite(values)
    if ok.sum() < 8:
        return float("nan"), 0.0
    t, v = times[ok], values[ok]
    v = v - np.mean(v)
    if np.std(v) < 1e-6:
        return 0.0, 0.0
    dt = np.median(np.diff(times))
    grid = np.arange(times[0], times[-1], dt)
    u = np.interp(grid, t, v) * np.hanning(len(grid))
    nfft = 1 << int(np.ceil(np.log2(len(grid) * 16)))
    spec = np.abs(np.fft.rfft(u, nfft))
    spec[0] = 0
    k = int(np.argmax(spec[1:-1])) + 1
    y0, y1, y2 = spec[k - 1], spec[k], spec[k + 1]
    frac = 0.5 * (y0 - y2) / (y0 - 2 * y1 + y2) if (y0 - 2 * y1 + y2) != 0 else 0.0
    return float((k + frac) / (nfft * dt)), float(np.ptp(v))


def complex_phase_at(times, values, hz):
    ok = np.isfinite(values)
    if ok.sum() < 8 or not hz > 0:
        return float("nan")
    v = values[ok] - np.mean(values[ok])
    return float(np.angle(np.sum(v * np.exp(-2j * np.pi * hz * times[ok]))))


def stereo_metrics(capture, meta, offset):
    a = meta["ms_start"] + offset + meta["period"]
    b = a + (meta["repeats"] - 3) * meta["period"]
    seg = capture[a:b]
    if seg.shape[1] < 2 or len(seg) < 16:
        return {}
    l, r = seg[:, 0], seg[:, 1]
    mid, side = 0.5 * (l + r), 0.5 * (l - r)
    return dict(correlation=float(np.sum(l * r) / np.sqrt(np.sum(l * l) * np.sum(r * r) + 1e-30)),
                mid_db=float(10 * np.log10(np.mean(mid ** 2) + 1e-30)),
                side_db=float(10 * np.log10(np.mean(side ** 2) + 1e-30)),
                peak=float(np.max(np.abs(seg))))


def analyse_take(capture, meta, offset, ref):
    times, freqs, H = tv_response(capture, meta, offset, ref)
    out = dict(frames=int(len(times)), frame_seconds=meta["period"] / meta["rate"])
    out.update(stereo_metrics(capture, meta, offset))
    tracks = []
    for ch in range(H.shape[0]):
        mag = 20 * np.log10(np.abs(H[ch]) + 1e-12)
        track = track_notch(freqs, mag)
        tracks.append(track)
        hz, swing = periodic_rate(times, np.log2(track))
        if np.mean(np.isfinite(track)) < 0.9:
            # the notch left the measured band or was lost: do not report a guess
            # (the model-based trajectory in fit.py does not depend on this track)
            hz, swing = None, None
        level = 10 * np.log10(np.mean(np.abs(H[ch]) ** 2, axis=1) + 1e-30)
        out["LR"[ch]] = dict(notch_hz_median=float(np.nanmedian(track)) if np.isfinite(track).any() else None,
                             notch_hz_min=float(np.nanmin(track)) if np.isfinite(track).any() else None,
                             notch_hz_max=float(np.nanmax(track)) if np.isfinite(track).any() else None,
                             notch_found_fraction=float(np.mean(np.isfinite(track))),
                             lfo_hz=hz, notch_swing_octaves=swing,
                             level_movement_db=float(np.ptp(level)), mean_gain_db=float(np.mean(level)))
    if len(tracks) == 2:
        hz = out["L"]["lfo_hz"]
        if hz and out["R"]["lfo_hz"] and (out["L"]["notch_swing_octaves"] or 0) > 0.05:
            pl, pr = complex_phase_at(times, np.log2(tracks[0]), hz), complex_phase_at(times, np.log2(tracks[1]), hz)
            if np.isfinite(pl) and np.isfinite(pr):
                # right minus left, same sign convention as stereoPhaseDeg in the model
                out["lr_lfo_offset_deg"] = float(np.degrees(np.angle(np.exp(1j * (pr - pl)))))
    return out


def thd_noise(capture, fs, info, offset):
    """THD+N per tone and the noise floor from the silent lead-in."""
    res = dict(tones=[])
    sil = capture[offset + int(0.5 * fs):offset + int((info["silence_seconds"] - 0.5) * fs)]
    if len(sil) > 16:
        res["noise_floor_dbfs"] = [float(20 * np.log10(np.sqrt(np.mean(sil[:, c] ** 2)) + 1e-30)) for c in range(sil.shape[1])]
    pos = offset + int(info["silence_seconds"] * fs)
    seg_len = int(info["tone_seconds"] * fs)
    for f0, lvl in info["tones"]:
        seg = capture[pos + seg_len // 4:pos + 3 * seg_len // 4]
        pos += seg_len + int(info["gap_seconds"] * fs)
        if len(seg) < 1024:
            continue
        row = dict(freq=f0, level_dbfs=lvl, thd_n_percent=[])
        w = np.hanning(len(seg))
        for c in range(seg.shape[1]):
            spec = np.abs(np.fft.rfft(seg[:, c] * w)) ** 2
            k = int(round(f0 * len(seg) / fs))
            fund = spec[max(0, k - 4):k + 5].sum()
            rest = spec[8:].sum() - fund
            row["thd_n_percent"].append(float(100 * np.sqrt(max(rest, 0) / (fund + 1e-30))))
        res["tones"].append(row)
    return res


def load_session(session):
    with open(os.path.join(session, "plan.json")) as f:
        return json.load(f)


def session_references(session, plan):
    """offset + bypass spectrum for every stimulus that has a bypass take."""
    refs = {}
    for b in plan["bypass_takes"]:
        path = os.path.join(session, b["file"])
        if not os.path.exists(path):
            continue
        rate, cap = read_wav(path)
        meta = plan["stimuli"][b["stimulus"]]
        if rate != meta["rate"]:
            raise SystemExit("%s: sample rate %d, expected %d" % (path, rate, meta["rate"]))
        off = find_offset(cap, meta)
        refs[b["stimulus"]] = dict(offset=off, ref=bypass_reference(cap, meta, off), peak=float(np.max(np.abs(cap))))
    return refs


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("session")
    a = ap.parse_args()
    plan = load_session(a.session)
    refs = session_references(a.session, plan)
    report = dict(rate=plan["rate"], takes={}, missing=[], warnings=[])
    for key in plan["stimuli"]:
        if key not in refs:
            report["warnings"].append("no bypass take for stimulus %s - takes using it cannot be analysed" % key)
        elif refs[key]["peak"] > 0.98:
            report["warnings"].append("bypass take for %s is clipping (peak %.3f)" % (key, refs[key]["peak"]))
    for t in plan["takes"]:
        path = os.path.join(a.session, t["file"])
        if not os.path.exists(path) or t["stimulus"] not in refs:
            report["missing"].append(t["id"])
            continue
        rate, cap = read_wav(path)
        meta = plan["stimuli"][t["stimulus"]]
        r = analyse_take(cap, meta, refs[t["stimulus"]]["offset"], refs[t["stimulus"]]["ref"])
        r.update(speed=t["speed"], depth=t["depth"], manual=t["manual"], resonance=t["resonance"], role=t["role"])
        if r.get("peak", 0) > 0.98:
            report["warnings"].append("take %s is clipping" % t["id"])
        report["takes"][t["id"]] = r
    info = plan["extra"]["sines_thd_noise"]
    for name, key in (("effect", "take"), ("bypass", "bypass_take")):
        path = os.path.join(a.session, info[key])
        if os.path.exists(path):
            rate, cap = read_wav(path)
            report["thd_noise_" + name] = thd_noise(cap, rate, info, 0)
    with open(os.path.join(a.session, "analysis.json"), "w") as f:
        json.dump(report, f, indent=2)
    print("analysed %d takes, %d missing, %d warnings -> %s/analysis.json"
          % (len(report["takes"]), len(report["missing"]), len(report["warnings"]), a.session))
    for w in report["warnings"]:
        print("  warning:", w)


if __name__ == "__main__":
    main()
