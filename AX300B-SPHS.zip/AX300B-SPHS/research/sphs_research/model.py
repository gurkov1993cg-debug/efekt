"""NumPy mirror of the C++ parameter laws (dsp/src/Phaser.cpp, namespace laws).
Keep both files in sync: selftest.py compares this model against the C++ audio code."""
import json
import numpy as np

DEFAULT = dict(
    name="H0-unfitted", fittedToHardware=0, stageKind=0, numStages=4, stageRatio=[1.0] * 12,
    stageQ=0.7071, dryGain=0.5, wetGainL=0.5, wetGainR=0.5, outputGain=1.0, fbMax=0.70,
    fbCurve=1.0, negMode=0, fbTapStage=0, fbNormalize=0.0, lfoShape=0, lfoSkew=0.5, lfoWarp=0.0,
    stereoPhaseDeg=90.0, speedScale=1.0, speedExp=1.0, sweepLaw=0, sweepPower=1.0,
    fCenterMin=150.0, fCenterMax=3000.0, manualCurve=1.0, depthMaxOct=2.0, depthCurve=1.0,
    fClampLo=20.0, fClampHiFrac=0.45, ampModDepth=0.0, ampModPhaseDeg=0.0, paramSmoothMs=15.0,
    speedSmoothMs=40.0)

LFO_SHAPES = ["sine", "triangle", "asymmetric triangle", "warped sine"]
SWEEP_LAWS = ["logarithmic", "linear", "power-log"]
NEG_MODES = ["invert feedback", "invert wet", "invert both"]
STAGE_KINDS = ["first-order", "second-order"]


def new_model(**kw):
    m = json.loads(json.dumps(DEFAULT))
    m.update(kw)
    return m


def save_model(path, m):
    with open(path, "w") as f:
        json.dump(m, f, indent=2)


def load_model(path):
    m = new_model()
    with open(path) as f:
        m.update(json.load(f))
    return m


def lfo_value(m, phase):
    p = np.mod(np.asarray(phase, dtype=float), 1.0)
    shape = m["lfoShape"]
    if shape == 1:
        q = np.mod(p + 0.25, 1.0)
        return 1.0 - 4.0 * np.abs(q - 0.5)
    if shape == 2:
        s = min(0.98, max(0.02, m["lfoSkew"]))
        return np.where(p < s, -1.0 + 2.0 * p / s, 1.0 - 2.0 * (p - s) / (1.0 - s))
    u = np.sin(2.0 * np.pi * p)
    if shape == 3:
        w = min(1.0, max(-1.0, m["lfoWarp"]))
        g = np.tanh(3.0 * u) / np.tanh(3.0) if w >= 0 else u ** 3
        return (1.0 - abs(w)) * u + abs(w) * g
    return u


def speed_hz(m, shown):
    s = np.clip(shown, 0.02, 9.5)
    return np.clip(m["speedScale"] * s ** m["speedExp"], 0.001, 40.0)


def center_hz(m, manual):
    x = np.clip(np.asarray(manual, dtype=float) / 50.0, 0.0, 1.0) ** m["manualCurve"]
    return m["fCenterMin"] * (m["fCenterMax"] / m["fCenterMin"]) ** x


def width_oct(m, depth):
    return np.clip(np.asarray(depth, dtype=float) / 50.0, 0.0, 1.0) ** m["depthCurve"] * m["depthMaxOct"]


def sweep_hz(m, center, width, lfo):
    u = np.clip(lfo, -1.0, 1.0)
    if m["sweepLaw"] == 1:
        lo, hi = center * 2.0 ** (-width), center * 2.0 ** width
        return lo + 0.5 * (u + 1.0) * (hi - lo)
    if m["sweepLaw"] == 2:
        t = (0.5 * (u + 1.0)) ** m["sweepPower"]
        return center * 2.0 ** (width * (2.0 * t - 1.0))
    return center * 2.0 ** (width * u)


def feedback(m, resonance):
    r = max(-1.0, min(1.0, resonance / 50.0))
    g = min(0.98, m["fbMax"]) * abs(r) ** m["fbCurve"]
    if m["negMode"] == 1:
        return g
    return -g if r < 0 else g


def wet_sign(m, resonance):
    if m["negMode"] == 0:
        return 1.0
    return -1.0 if resonance < 0 else 1.0


def _stage(m, fs, f, z1):
    if m["stageKind"] == 1:
        bw = np.clip(f / m["stageQ"], 1.0, 0.49 * fs)
        t = np.tan(np.pi * bw / fs)
        c = (t - 1.0) / (t + 1.0)
        e = -np.cos(2.0 * np.pi * f / fs) * (1.0 - c)
        return (-c + e * z1 + z1 * z1) / (1.0 + e * z1 - c * z1 * z1)
    t = np.tan(np.pi * f / fs)
    a = (t - 1.0) / (t + 1.0)
    return (a + z1) / (1.0 + a * z1)


def response(m, fs, sweep, resonance, wet_gain, freqs):
    """Frozen-LFO complex response. Returns an array [len(sweep), len(freqs)]."""
    sweep = np.atleast_1d(np.asarray(sweep, dtype=float))[:, None]
    z1 = np.exp(-2j * np.pi * np.asarray(freqs, dtype=float) / fs)[None, :]
    n = int(m["numStages"])
    tap = n if int(m["fbTapStage"]) == 0 else int(m["fbTapStage"])
    full = np.ones((sweep.shape[0], z1.shape[1]), dtype=complex)
    tapped = full
    for k in range(n):
        f = np.clip(sweep * m["stageRatio"][k], m["fClampLo"], m["fClampHiFrac"] * fs)
        full = full * _stage(m, fs, f, z1)
        if k + 1 == tap:
            tapped = full
    fb = feedback(m, resonance)
    in_scale = (1.0 - abs(fb)) ** m["fbNormalize"]
    wet = full * in_scale / (1.0 - fb * z1 * tapped)
    return m["outputGain"] * (m["dryGain"] + wet_gain * wet_sign(m, resonance) * wet)


def channel_sweeps(m, speed, depth, manual, phase):
    """Sweep frequency of the left and right network for LFO phase(s) 0..1."""
    c, w = center_hz(m, manual), width_oct(m, depth)
    left = sweep_hz(m, c, w, lfo_value(m, phase))
    right = sweep_hz(m, c, w, lfo_value(m, np.asarray(phase) + m["stereoPhaseDeg"] / 360.0))
    return left, right
