"""Step 1: create the test signals and the measurement plan.

    python -m sphs_research.signals --out session --rate 48000 --plan core

Play each stimulus through the real unit (only SPHS switched on, every other
block off), record the stereo output sample-aligned with playback and save the
take under the file name listed in session/plan.json."""
import argparse
import json
import os
import numpy as np
from scipy.io import wavfile

SYNC_SECONDS = 0.05
LEAD_SECONDS = 0.5
GAP_SECONDS = 0.25


def multisine(n, fs, f_lo=40.0, f_hi=16000.0, seed=1):
    """One period of a flat multisine with random phases, peak = 1."""
    rng = np.random.default_rng(seed)
    spec = np.zeros(n // 2 + 1, dtype=complex)
    k = np.arange(n // 2 + 1)
    used = (k * fs / n >= f_lo) & (k * fs / n <= min(f_hi, 0.45 * fs)) & (k > 0)
    best = None
    for _ in range(40):  # keep the phase set with the lowest crest factor
        spec[:] = 0
        spec[used] = np.exp(2j * np.pi * rng.random(used.sum()))
        x = np.fft.irfft(spec, n)
        x /= np.max(np.abs(x))
        if best is None or np.std(x) > np.std(best):
            best = x.copy()
    return best


def sync_burst(fs):
    n = int(SYNC_SECONDS * fs)
    t = np.arange(n) / fs
    return np.sin(2 * np.pi * (1000.0 * t + 0.5 * (8000.0 - 1000.0) / SYNC_SECONDS * t * t)) * np.hanning(n)


def period_for_speed(speed_hz, fs):
    """Short frames for a fast LFO, long frames (fine frequency grid) for a slow one."""
    target = 4096 if speed_hz <= 0.75 else (1024 if speed_hz <= 3.0 else 256)
    return int(target * (2 if fs > 60000 else 1))


def build_stimulus(fs, period, seconds, level_db=-12.0, seed=1):
    lead, gap = int(LEAD_SECONDS * fs), int(GAP_SECONDS * fs)
    ms = multisine(period, fs, seed=seed)
    reps = int(np.ceil(seconds * fs / period)) + 2
    sync = sync_burst(fs)
    g = 10.0 ** (level_db / 20.0)
    x = np.concatenate([np.zeros(lead), sync * g, np.zeros(gap), np.tile(ms, reps) * g, np.zeros(lead)])
    meta = dict(rate=fs, period=period, sync_start=lead, ms_start=lead + len(sync) + gap, repeats=reps,
                level_db=level_db, seed=seed)
    return x.astype(np.float32), meta


def take_seconds(speed):
    return float(min(120.0, max(6.0, 2.3 / speed)))  # at least two full LFO periods


def make_plan(kind):
    takes = []

    def add(speed, depth, manual, res, role):
        tid = "sp%s_de%02d_ma%02d_re%+03d" % (("%.2f" % speed).replace(".", "p"), depth, manual, res)
        if all(t["id"] != tid for t in takes):
            takes.append(dict(id=tid, file="takes/%s.wav" % tid, speed=speed, depth=depth, manual=manual,
                              resonance=res, role=role))

    if kind == "full":  # the complete representative grid of the master prompt
        for speed in (0.02, 0.1, 0.5, 2.0, 9.5):
            for depth in (0, 25, 50):
                for manual in (0, 25, 50):
                    for res in (-50, 0, 50):
                        add(speed, depth, manual, res, "train")
    else:
        for manual in (0, 25, 50):  # static: topology, Manual law, Resonance
            for res in (-50, 0, 50):
                add(0.5, 0, manual, res, "train")
        for res in (-25, 25):
            add(0.5, 0, 25, res, "train")
        for speed in (0.02, 0.1, 0.5, 2.0, 9.5):  # moving: Speed law, LFO shape, Depth law, stereo
            for depth in (25, 50):
                add(speed, depth, 25, 0, "train")
    # settings that are never used for fitting - only for validation
    for speed, depth, manual, res in ((1.0, 40, 10, 30), (0.3, 15, 40, -30), (4.0, 35, 30, 15), (0.5, 0, 12, -40),
                                      (0.5, 0, 38, 40), (6.0, 50, 20, -20)):
        add(speed, depth, manual, res, "validation")
    return takes


def write_session(out, fs, plan_kind, level_db):
    os.makedirs(os.path.join(out, "stimuli"), exist_ok=True)
    os.makedirs(os.path.join(out, "takes"), exist_ok=True)
    takes = make_plan(plan_kind)
    stimuli = {}
    for t in takes:
        period = period_for_speed(t["speed"], fs)
        seconds = take_seconds(t["speed"]) if t["depth"] > 0 else 6.0
        key = "ms_N%d_%ds" % (period, int(np.ceil(seconds)))
        if key not in stimuli:
            x, meta = build_stimulus(fs, period, seconds, level_db)
            meta["file"] = "stimuli/%s.wav" % key
            wavfile.write(os.path.join(out, meta["file"]), int(fs), x)
            stimuli[key] = meta
        t["stimulus"] = key
    # every stimulus is also recorded once with the unit in BYPASS (reference path)
    bypass = [dict(id="bypass_" + k, file="takes/bypass_%s.wav" % k, stimulus=k) for k in sorted(stimuli)]
    extra = write_extra_signals(out, fs, level_db)
    plan = dict(rate=fs, plan=plan_kind, model_rate=39062.5, stimuli=stimuli, bypass_takes=bypass, takes=takes,
                extra=extra,
                notes="Record STEREO (L/R outputs of the unit), same sample rate, start of the recording aligned "
                      "with the start of playback. Keep input/output gains unchanged for the whole session.")
    with open(os.path.join(out, "plan.json"), "w") as f:
        json.dump(plan, f, indent=2)
    return plan


def write_extra_signals(out, fs, level_db):
    """Signals for noise, distortion, level dependence and envelope behaviour."""
    extra = {}
    t = np.arange(int(fs * 2.0)) / fs
    parts = [np.zeros(int(fs * 3.0))]  # 3 s silence: noise floor
    for f0 in (100.0, 1000.0):
        for lvl in (-30.0, -18.0, -6.0):  # THD+N at three levels
            parts += [np.sin(2 * np.pi * f0 * t) * 10 ** (lvl / 20.0) * np.minimum(1, np.minimum(t, t[::-1]) * 200),
                      np.zeros(int(fs * 0.3))]
    wavfile.write(os.path.join(out, "stimuli/sines_thd_noise.wav"), int(fs), np.concatenate(parts).astype(np.float32))
    extra["sines_thd_noise"] = dict(file="stimuli/sines_thd_noise.wav", take="takes/sines_thd_noise.wav",
                                    bypass_take="takes/bypass_sines_thd_noise.wav", silence_seconds=3.0,
                                    tones=[[f0, lvl] for f0 in (100.0, 1000.0) for lvl in (-30.0, -18.0, -6.0)],
                                    tone_seconds=2.0, gap_seconds=0.3)
    n = int(fs * 8.0)  # logarithmic chirp 20 Hz .. 19 kHz
    tt = np.arange(n) / fs
    k = np.log(19000.0 / 20.0)
    chirp = np.sin(2 * np.pi * 20.0 * 8.0 / k * (np.exp(tt / 8.0 * k) - 1.0)) * 10 ** (level_db / 20.0)
    wavfile.write(os.path.join(out, "stimuli/log_chirp.wav"), int(fs),
                  np.concatenate([np.zeros(int(fs * 0.5)), chirp, np.zeros(int(fs * 0.5))]).astype(np.float32))
    extra["log_chirp"] = dict(file="stimuli/log_chirp.wav", take="takes/log_chirp.wav",
                              bypass_take="takes/bypass_log_chirp.wav")
    burst = []  # tone bursts: attack / decay of the input
    for f0 in (82.4, 220.0, 880.0):
        tb = np.arange(int(fs * 0.4)) / fs
        burst += [np.sin(2 * np.pi * f0 * tb) * 10 ** (level_db / 20.0), np.zeros(int(fs * 0.6))]
    wavfile.write(os.path.join(out, "stimuli/tone_bursts.wav"), int(fs), np.concatenate(burst).astype(np.float32))
    extra["tone_bursts"] = dict(file="stimuli/tone_bursts.wav", take="takes/tone_bursts.wav")
    extra["di_recordings"] = dict(note="Put your own DI bass / guitar files in stimuli/di_*.wav, record them through "
                                       "the unit as takes/di_*.wav and write the unit settings into takes/di_settings.json")
    return extra


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", default="session")
    ap.add_argument("--rate", type=int, default=48000)
    ap.add_argument("--plan", choices=["core", "full"], default="core")
    ap.add_argument("--level", type=float, default=-12.0, help="peak level of the stimuli in dBFS")
    a = ap.parse_args()
    plan = write_session(a.out, a.rate, a.plan, a.level)
    total = sum(len(wavfile.read(os.path.join(a.out, plan["stimuli"][t["stimulus"]]["file"]))[1]) for t in plan["takes"]) / a.rate
    print("session written to %s: %d takes + %d bypass takes, %.0f minutes of recording"
          % (a.out, len(plan["takes"]), len(plan["bypass_takes"]), total / 60.0))


if __name__ == "__main__":
    main()
