"""Self-test of the measurement + fitting tools. NOT a measurement of an AX300B.

    python -m sphs_research.selftest --render <path to sphs_render> [--work DIR]

A "device" with hidden, deliberately different parameters is simulated with the
plug-in's own C++ DSP (Reference mode, 39.0625 kHz). Its "recordings" then go
through exactly the same analysis and fitting as real recordings would. The
test passes when the hidden parameters are recovered. This proves that the
tools work; it says nothing about how the real unit sounds."""
import argparse
import os
import shutil
import subprocess
import sys
import tempfile
import numpy as np
from scipy.io import wavfile
from . import model as M
from .signals import write_session
from .analyze import read_wav
from . import fit

CHAIN_DELAY, CHAIN_GAIN = 37, 0.8  # stands in for converter delay and level of a real set-up

HIDDEN = M.new_model(name="hidden-device", numStages=6, stageKind=0, fbMax=0.55, fbCurve=1.3, negMode=0,
                     dryGain=0.5, wetGainL=0.5, wetGainR=0.5, lfoShape=1, sweepLaw=0, stereoPhaseDeg=140.0,
                     speedScale=1.05, speedExp=0.97, fCenterMin=220.0, fCenterMax=2400.0, manualCurve=1.4,
                     depthMaxOct=1.3, depthCurve=0.8)


def through_chain(x):
    y = np.zeros_like(x)
    y[CHAIN_DELAY:] = x[:len(x) - CHAIN_DELAY] * CHAIN_GAIN
    return y


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--render", required=True, help="path to the sphs_render executable")
    ap.add_argument("--work", default=None)
    ap.add_argument("--rate", type=int, default=48000)
    a = ap.parse_args()
    work = a.work or tempfile.mkdtemp(prefix="sphs_selftest_")
    os.makedirs(work, exist_ok=True)
    plan = write_session(work, a.rate, "core", -12.0)
    hidden = os.path.join(work, "hidden_device.json")
    M.save_model(hidden, HIDDEN)

    for b in plan["bypass_takes"]:  # bypass: only the measurement chain
        rate, x = read_wav(os.path.join(work, plan["stimuli"][b["stimulus"]]["file"]))
        y = through_chain(np.repeat(x, 2, axis=1))
        wavfile.write(os.path.join(work, b["file"]), rate, y.astype(np.float32))
    for t in plan["takes"]:
        stim = os.path.join(work, plan["stimuli"][t["stimulus"]]["file"])
        out = os.path.join(work, t["file"])
        subprocess.run([a.render, "--in", stim, "--out", out, "--model", hidden, "--mode", "reference",
                        "--speed", str(t["speed"]), "--depth", str(t["depth"]), "--manual", str(t["manual"]),
                        "--res", str(t["resonance"])], check=True, stdout=subprocess.DEVNULL)
        rate, y = read_wav(out)
        wavfile.write(out, rate, through_chain(y).astype(np.float32))
    print("simulated %d takes in %s" % (len(plan["takes"]), work))

    report = fit.run(work, source="synthetic", quick=True)
    m = report["model"]
    ok = True

    def check(name, cond, detail):
        nonlocal ok
        ok = ok and bool(cond)
        print("  %-34s %s   %s" % (name, "ok  " if cond else "FAIL", detail))

    def close(key, tol):
        rel = abs(m[key] - HIDDEN[key]) / abs(HIDDEN[key])
        check(key, rel <= tol, "found %.4g, hidden %.4g (%.2f %%)" % (m[key], HIDDEN[key], 100 * rel))

    print("recovered model vs hidden device:")
    check("number of stages", m["numStages"] == HIDDEN["numStages"] and m["stageKind"] == HIDDEN["stageKind"],
          "found %d %s" % (m["numStages"], M.STAGE_KINDS[m["stageKind"]]))
    check("LFO shape", m["lfoShape"] == HIDDEN["lfoShape"], "found " + M.LFO_SHAPES[m["lfoShape"]])
    check("sweep law", m["sweepLaw"] == HIDDEN["sweepLaw"], "found " + M.SWEEP_LAWS[m["sweepLaw"]])
    for key, tol in (("fCenterMin", 0.03), ("fCenterMax", 0.03), ("manualCurve", 0.08), ("depthMaxOct", 0.05),
                     ("depthCurve", 0.10), ("fbMax", 0.08), ("speedScale", 0.01), ("speedExp", 0.01)):
        close(key, tol)
    d = abs((m["stereoPhaseDeg"] - HIDDEN["stereoPhaseDeg"] + 180.0) % 360.0 - 180.0)
    check("L/R LFO offset", d < 6.0, "found %.1f deg, hidden %.1f deg" % (m["stereoPhaseDeg"], HIDDEN["stereoPhaseDeg"]))
    v = report["validation"]
    check("validation: LFO rate <= 1 %", v["lfo_error_percent_max"] <= 1.0, "max %.3f %%" % v["lfo_error_percent_max"])
    check("validation: notch track <= 5 %", v["notch_error_percent_median"] <= 5.0, "median %.2f %%" % v["notch_error_percent_median"])
    check("never labelled as hardware", m["fittedToHardware"] == 0, "fittedToHardware=%d" % m["fittedToHardware"])
    print("SELFTEST %s (synthetic device - not an AX300B measurement)" % ("PASSED" if ok else "FAILED"))
    if a.work is None:
        shutil.rmtree(work, ignore_errors=True)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
