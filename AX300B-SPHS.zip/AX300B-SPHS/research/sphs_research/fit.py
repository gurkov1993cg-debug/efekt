"""Step 3: estimate the grey-box model from the recorded takes.

    python -m sphs_research.fit session --source hardware

Staged identification (training takes only):
  A  static takes (Depth 0): all-pass topology, Manual law, feedback / Resonance law, dry/wet
  B  per-frame sweep frequency of every moving take, using the model from A
  C  LFO shape, sweep law, Speed law, Depth law, L/R LFO offset
  D  validation on takes that were never used for fitting

Writes session/fitted_model.json and session/fit_report.md. The model is only
marked "fittedToHardware" when --source hardware is given AND validation
passes the thresholds (LFO rate <= 1 %, median notch trajectory <= 5 %)."""
import argparse
import itertools
import json
import os
import numpy as np
from scipy.optimize import least_squares
from . import model as M
from .analyze import (read_wav, load_session, session_references, tv_response, lowest_notch, periodic_rate,
                      complex_phase_at)

FLOOR_DB = -40.0


def db(h):
    return np.maximum(20 * np.log10(np.abs(h) + 1e-12), FLOOR_DB)


def load_observations(session, plan, refs, max_bins=96, max_frames=4000):
    obs = []
    for t in plan["takes"]:
        path = os.path.join(session, t["file"])
        if not os.path.exists(path) or t["stimulus"] not in refs:
            continue
        _, cap = read_wav(path)
        meta = plan["stimuli"][t["stimulus"]]
        times, freqs, H = tv_response(cap, meta, refs[t["stimulus"]]["offset"], refs[t["stimulus"]]["ref"])
        if H.shape[0] < 2:
            raise SystemExit("%s is not a stereo recording" % t["file"])
        if len(freqs) > max_bins:  # log-spaced subset of the frequency grid
            idx = np.unique(np.round(np.geomspace(1, len(freqs), max_bins)).astype(int) - 1)
            freqs, H = freqs[idx], H[:, :, idx]
        step = max(1, len(times) // max_frames)
        obs.append(dict(t, times=times[::step], freqs=freqs, mag=db(H[:, ::step, :])))
    return obs


# ---------------------------------------------------------------- stage A
def spread_ratios(n, log2_spread):
    return [float(2.0 ** (log2_spread * (k - (n - 1) / 2.0))) if k < n else 1.0 for k in range(12)]


def static_model(base, x, manuals):
    m = dict(base)
    nm = len(manuals)
    m["fbMax"], m["fbCurve"], m["dryGain"], m["wetGainL"], m["wetGainR"] = [float(v) for v in x[nm:nm + 5]]
    m["stageRatio"] = spread_ratios(m["numStages"], x[nm + 5])
    if m["stageKind"] == 1:
        m["stageQ"] = float(x[nm + 6])
    return m, {mv: float(2.0 ** x[i]) for i, mv in enumerate(manuals)}


def static_residual(x, base, manuals, takes, fs):
    m, centers = static_model(base, x, manuals)
    res = []
    for t in takes:
        sweep = centers[t["manual"]]
        for ch, wet in ((0, m["wetGainL"]), (1, m["wetGainR"])):
            res.append(db(M.response(m, fs, sweep, t["resonance"], wet, t["freqs"])[0]) - t["target"][ch])
    return np.concatenate(res)


def fit_static(takes, fs, quick, rng):
    manuals = sorted({t["manual"] for t in takes})
    for t in takes:
        t["target"] = np.maximum(np.mean(t["mag"], axis=1), FLOOR_DB)
    counts = (2, 4, 6, 8) if quick else (2, 4, 6, 8, 10, 12)
    results = []
    for kind, n, neg in itertools.product((0, 1), counts, (0, 1, 2)):
        if kind == 1 and n % 2:
            continue
        base = M.new_model(stageKind=kind, numStages=n // 2 if kind == 1 else n, negMode=neg, fbTapStage=0)
        lo = [np.log2(20.0)] * len(manuals) + [0.0, 0.3, 0.0, -1.5, -1.5, -0.5] + ([0.3] if kind else [])
        hi = [np.log2(12000.0)] * len(manuals) + [0.97, 4.0, 1.5, 1.5, 1.5, 0.5] + ([4.0] if kind else [])
        best = None
        for start in range(4 if quick else 8):
            c0 = np.sort(rng.uniform(np.log2(60.0), np.log2(5000.0), len(manuals)))
            x0 = list(c0) + [rng.uniform(0.2, 0.9), 1.0, 0.5, 0.5 * rng.choice([-1, 1]), 0.5 * rng.choice([-1, 1]), 0.0]
            x0 += [0.8] if kind else []
            try:
                r = least_squares(static_residual, x0, bounds=(lo, hi), args=(base, manuals, takes, fs), max_nfev=250)
            except ValueError:
                continue
            if best is None or r.cost < best.cost:
                best = r
        nres, k = len(best.fun), len(best.x)
        rss = float(np.sum(best.fun ** 2))
        results.append(dict(kind=kind, stages=n, negMode=neg, rms_db=float(np.sqrt(rss / nres)),
                            bic=float(nres * np.log(rss / nres + 1e-12) + k * np.log(nres)), x=best.x, base=base))
    results.sort(key=lambda r: r["bic"])
    m, centers = static_model(results[0]["base"], results[0]["x"], manuals)
    return m, centers, results


# ---------------------------------------------------------------- stage B
def sweep_trajectory(m, fs, take, grid):
    """Per-frame sweep frequency of both channels (model coordinate), by table search."""
    out = []
    for ch, wet in ((0, m["wetGainL"]), (1, m["wetGainR"])):
        table = db(M.response(m, fs, grid, take["resonance"], wet, take["freqs"]))	 # [grid, bins]
        d = take["mag"][ch]
        sse = (d ** 2).sum(1)[:, None] - 2.0 * d @ table.T + (table ** 2).sum(1)[None, :]
        k = np.clip(np.argmin(sse, axis=1), 1, len(grid) - 2)
        rows = np.arange(len(k))
        y0, y1, y2 = sse[rows, k - 1], sse[rows, k], sse[rows, k + 1]
        den = y0 - 2 * y1 + y2
        frac = np.where(den > 1e-12, 0.5 * (y0 - y2) / np.where(den > 1e-12, den, 1.0), 0.0)
        step = np.log2(grid[1] / grid[0])
        out.append(np.log2(grid[k]) + np.clip(frac, -1, 1) * step)
    return out  # log2 Hz, [L, R]


# ---------------------------------------------------------------- stage C
def traj_curve(p, t, shape, law):
    mm = dict(lfoShape=shape, lfoSkew=p[4] if shape == 2 else 0.5, lfoWarp=p[4] if shape == 3 else 0.0,
              sweepLaw=law, sweepPower=p[5] if law == 2 else 1.0)
    return np.log2(M.sweep_hz(mm, 2.0 ** p[0], p[1], M.lfo_value(mm, p[3] + p[2] * t)))


def fit_trajectory(t, y, shape, law, hz0):
    lo = [np.log2(15.0), 0.0, hz0 * 0.9, -2.0, 0.05 if shape == 2 else -1.0, 0.2]
    hi = [np.log2(15000.0), 6.0, hz0 * 1.1, 3.0, 0.95 if shape == 2 else 1.0, 5.0]
    c0 = 0.5 * (np.percentile(y, 2) + np.percentile(y, 98))
    w0 = max(0.05, 0.5 * (np.percentile(y, 98) - np.percentile(y, 2)))
    best = None
    for ph in np.arange(0.0, 1.0, 0.125):
        for extra in ((0.3, 0.7) if shape == 2 else ((0.4, -0.4) if shape == 3 else (0.5,))):
            x0 = [c0, w0, hz0, ph, extra, 1.0]
            r = least_squares(lambda p: traj_curve(p, t, shape, law) - y, x0, bounds=(lo, hi), max_nfev=120)
            if best is None or r.cost < best.cost:
                best = r
    return best.x, float(np.sqrt(2 * best.cost / len(y)))


def best_phase(t, y, p, shape, law):
    """Phase of a second trajectory that shares everything else with `p`."""
    grid = np.arange(0.0, 1.0, 1.0 / 72)
    err = [np.sum((traj_curve([p[0], p[1], p[2], g, p[4], p[5]], t, shape, law) - y) ** 2) for g in grid]
    g0 = grid[int(np.argmin(err))]
    r = least_squares(lambda q: traj_curve([p[0], p[1], p[2], q[0], p[4], p[5]], t, shape, law) - y, [g0],
                      bounds=([g0 - 0.02], [g0 + 0.02]))
    return float(r.x[0])


def fit_motion(m, fs, moving, grid):
    for t in moving:
        t["traj"] = sweep_trajectory(m, fs, t, grid)
        t["hz0"], _ = periodic_rate(t["times"], t["traj"][0])
    cands = []
    for shape, law in itertools.product(range(4), range(3)):
        fits, rss, n = [], 0.0, 0
        for t in moving:
            p, rms = fit_trajectory(t["times"], t["traj"][0], shape, law, max(t["hz0"], 1e-3))
            fits.append(p)
            rss += rms ** 2 * len(t["times"])
            n += len(t["times"])
        k = 4 * len(moving) + (1 if shape >= 2 else 0) + (1 if law == 2 else 0)
        cands.append(dict(shape=shape, law=law, rms_oct=float(np.sqrt(rss / n)),
                          bic=float(n * np.log(rss / n + 1e-15) + k * np.log(n)), fits=fits))
    cands.sort(key=lambda c: c["bic"])
    # Parsimony: with thousands of frames BIC rewards even meaningless gains, so
    # among candidates that fit practically equally well take the simplest one.
    limit = min(c["rms_oct"] for c in cands) * 1.03 + 1e-4
    for c in cands:
        c["extra_params"] = (1 if c["shape"] >= 2 else 0) + (1 if c["law"] == 2 else 0)
    best = min((c for c in cands if c["rms_oct"] <= limit), key=lambda c: (c["extra_params"], c["rms_oct"]))
    cands.remove(best)
    cands.insert(0, best)
    shape, law = best["shape"], best["law"]
    m = dict(m, lfoShape=shape, sweepLaw=law)
    P = np.array(best["fits"])
    if shape == 2:
        m["lfoSkew"] = float(np.median(P[:, 4]))
    if shape == 3:
        m["lfoWarp"] = float(np.median(P[:, 4]))
    if law == 2:
        m["sweepPower"] = float(np.median(P[:, 5]))
    # Speed law:  Hz = scale * shown^exp
    shown = np.array([t["speed"] for t in moving])
    A = np.vstack([np.ones(len(shown)), np.log(shown)]).T
    sol = np.linalg.lstsq(A, np.log(P[:, 2]), rcond=None)[0]
    m["speedScale"], m["speedExp"] = float(np.exp(sol[0])), float(sol[1])
    # Depth law:  width = depthMaxOct * (depth/50)^curve
    depth = np.array([t["depth"] for t in moving], dtype=float)
    w50 = np.median(P[depth == 50, 1]) if np.any(depth == 50) else np.max(P[:, 1])
    m["depthMaxOct"] = float(w50)
    part = depth < 50
    if np.any(part):
        m["depthCurve"] = float(np.clip(np.median(np.log(P[part, 1] / w50) / np.log(depth[part] / 50.0)), 0.1, 8.0))
    # L/R LFO offset
    offs = [best_phase(t["times"], t["traj"][1], p, shape, law) - p[3] for t, p in zip(moving, best["fits"])]
    m["stereoPhaseDeg"] = float(np.degrees(np.angle(np.mean(np.exp(2j * np.pi * np.array(offs))))) % 360.0)
    return m, cands


def manual_law(m, centers):
    mv = sorted(centers)
    if 0 in centers and 50 in centers:
        m["fCenterMin"], m["fCenterMax"] = centers[0], centers[50]
        mids = [v for v in mv if 0 < v < 50]
        if mids:
            g = [np.log(np.log(centers[v] / centers[0]) / np.log(centers[50] / centers[0])) / np.log(v / 50.0) for v in mids]
            m["manualCurve"] = float(np.clip(np.median(g), 0.1, 8.0))
    return m


# ---------------------------------------------------------------- stage D
def validate(m, fs, takes, grid):
    rows = []
    for t in takes:
        traj = sweep_trajectory(m, fs, t, grid)
        row = dict(id=t["id"], role=t["role"])
        c, w = float(M.center_hz(m, t["manual"])), float(M.width_oct(m, t["depth"]))
        hz_pred = float(M.speed_hz(m, t["speed"]))
        pred = []
        if t["depth"] > 0:
            hz_meas, _ = periodic_rate(t["times"], traj[0])
            row["lfo_hz_measured"], row["lfo_hz_model"] = hz_meas, hz_pred
            row["lfo_error_percent"] = 100.0 * abs(hz_meas - hz_pred) / hz_pred
            p = [np.log2(c), w, hz_meas, 0.0, m["lfoSkew"] if m["lfoShape"] == 2 else m["lfoWarp"], m["sweepPower"]]
            ph = best_phase(t["times"], traj[0], p, m["lfoShape"], m["sweepLaw"])
            for off in (0.0, m["stereoPhaseDeg"] / 360.0):
                pred.append(traj_curve([p[0], p[1], p[2], ph + off, p[4], p[5]], t["times"], m["lfoShape"], m["sweepLaw"]))
        else:
            pred = [np.full(len(t["times"]), np.log2(c))] * 2
        errs, mags = [], []
        sel = np.linspace(0, len(t["times"]) - 1, min(80, len(t["times"]))).astype(int)
        for ch, wet in ((0, m["wetGainL"]), (1, m["wetGainR"])):
            model_db = db(M.response(m, fs, 2.0 ** pred[ch][sel], t["resonance"], wet, t["freqs"]))
            mags.append(np.sqrt(np.mean((model_db - t["mag"][ch][sel]) ** 2)))
            for i, f in enumerate(sel):
                a, b = lowest_notch(t["freqs"], t["mag"][ch][f]), lowest_notch(t["freqs"], model_db[i])
                if np.isfinite(a) and np.isfinite(b):
                    errs.append(abs(a / b - 1.0))
        row["notch_error_percent_median"] = float(100 * np.median(errs)) if errs else None
        row["notch_frames_compared"] = len(errs)
        row["sweep_error_percent_median"] = float(100 * np.median(np.abs(2.0 ** (np.concatenate(traj) - np.concatenate(pred)) - 1.0)))
        row["magnitude_rms_db"] = float(np.mean(mags))
        rows.append(row)
    return rows


def summarize(rows):
    lfo = [r["lfo_error_percent"] for r in rows if "lfo_error_percent" in r]
    notch = [r["notch_error_percent_median"] for r in rows if r["notch_error_percent_median"] is not None]
    return dict(takes=len(rows), lfo_error_percent_max=float(max(lfo)) if lfo else None,
                notch_error_percent_median=float(np.median(notch)) if notch else None,
                magnitude_rms_db_mean=float(np.mean([r["magnitude_rms_db"] for r in rows])) if rows else None)


def run(session, source="synthetic", quick=False, seed=0, model_rate=None):
    plan = load_session(session)
    fs = float(model_rate or plan.get("model_rate", 39062.5))
    refs = session_references(session, plan)
    obs = load_observations(session, plan, refs)
    train = [o for o in obs if o["role"] == "train"]
    val = [o for o in obs if o["role"] == "validation"]
    static = [o for o in train if o["depth"] == 0]
    moving = [o for o in train if o["depth"] > 0]
    if len(static) < 5 or len(moving) < 4 or len(val) < 3:
        raise SystemExit("not enough takes: %d static, %d moving, %d validation recordings found. "
                         "Record the takes listed in plan.json first - no model is produced without them."
                         % (len(static), len(moving), len(val)))
    rng = np.random.default_rng(seed)
    grid = np.geomspace(20.0, 0.44 * fs, 360)
    m, centers, static_cands = fit_static(static, fs, quick, rng)
    m = manual_law(m, centers)
    m, motion_cands = fit_motion(m, fs, moving, grid)
    rows_val = validate(m, fs, val, grid)
    rows_train = validate(m, fs, train, grid)
    sv, st = summarize(rows_val), summarize(rows_train)
    passed = bool(sv["lfo_error_percent_max"] is not None and sv["lfo_error_percent_max"] <= 1.0 and
                  sv["notch_error_percent_median"] is not None and sv["notch_error_percent_median"] <= 5.0)
    m["fittedToHardware"] = 1 if (source == "hardware" and passed) else 0
    m["name"] = ("AX300B-fit" if source == "hardware" else "synthetic-selftest") + ("" if passed else "-FAILED")
    M.save_model(os.path.join(session, "fitted_model.json"), m)
    report = dict(source=source, model_rate=fs, passed=passed, validation=sv, training=st, validation_takes=rows_val,
                  static_candidates=[{k: v for k, v in c.items() if k not in ("x", "base")} for c in static_cands],
                  motion_candidates=[{k: v for k, v in c.items() if k != "fits"} for c in motion_cands], model=m)
    with open(os.path.join(session, "fit_report.json"), "w") as f:
        json.dump(report, f, indent=2)
    write_markdown(os.path.join(session, "fit_report.md"), report)
    return report


def write_markdown(path, r):
    m = r["model"]
    L = ["# SPHS model fit report", "",
         "- source of the recordings: **%s**" % r["source"],
         "- model evaluated at %.1f Hz (internal rate of the original)" % r["model_rate"],
         "- validation thresholds (LFO rate <= 1 %%, median notch trajectory <= 5 %%): **%s**" % ("PASSED" if r["passed"] else "FAILED"),
         "- fittedToHardware flag written to the model: **%d**" % m["fittedToHardware"], "",
         "## Validation (takes never used for fitting)", "",
         "| take | LFO error % | notch error % (median) | sweep error % | magnitude RMS dB |", "|---|---|---|---|---|"]
    for v in r["validation_takes"]:
        L.append("| %s | %s | %s | %.2f | %.2f |" % (
            v["id"], "%.3f" % v["lfo_error_percent"] if "lfo_error_percent" in v else "static",
            "%.2f" % v["notch_error_percent_median"] if v["notch_error_percent_median"] is not None else "no notch",
            v["sweep_error_percent_median"], v["magnitude_rms_db"]))
    L += ["", "Summary: %s" % json.dumps(r["validation"]), "", "Training set: %s" % json.dumps(r["training"]), "",
          "## Candidate all-pass structures (static takes), best first", "",
          "| stages | type | negative Resonance | RMS dB | BIC |", "|---|---|---|---|---|"]
    for c in r["static_candidates"][:12]:
        L.append("| %d | %s | %s | %.3f | %.1f |" % (c["stages"], M.STAGE_KINDS[c["kind"]], M.NEG_MODES[c["negMode"]], c["rms_db"], c["bic"]))
    L += ["", "## Candidate LFO shapes / sweep laws (moving takes), best first", "",
          "| LFO shape | sweep law | RMS octaves | BIC |", "|---|---|---|---|"]
    for c in r["motion_candidates"]:
        L.append("| %s | %s | %.4f | %.1f |" % (M.LFO_SHAPES[c["shape"]], M.SWEEP_LAWS[c["law"]], c["rms_oct"], c["bic"]))
    L += ["", "## Estimated model", "", "```json", json.dumps(m, indent=2), "```", ""]
    with open(path, "w") as f:
        f.write("\n".join(L))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("session")
    ap.add_argument("--source", choices=["hardware", "synthetic"], default="synthetic",
                    help="'hardware' only for recordings of a real AX300B")
    ap.add_argument("--quick", action="store_true", help="fewer candidate structures / starts")
    ap.add_argument("--model-rate", type=float, default=None)
    a = ap.parse_args()
    r = run(a.session, a.source, a.quick, model_rate=a.model_rate)
    print("validation %s: %s" % ("PASSED" if r["passed"] else "FAILED", json.dumps(r["validation"])))
    print("model: %s  (fittedToHardware=%d) -> %s/fitted_model.json" % (r["model"]["name"], r["model"]["fittedToHardware"], a.session))


if __name__ == "__main__":
    main()
