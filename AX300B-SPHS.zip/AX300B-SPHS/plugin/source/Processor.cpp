#include "Processor.h"
#include "base/source/fstreamer.h"
#include "pluginterfaces/base/ibstream.h"
#include "pluginterfaces/vst/ivstmessage.h"
#include "pluginterfaces/vst/ivstparameterchanges.h"
#include <algorithm>
#include <cstring>

#if defined(__SSE__) || defined(_M_X64)
#include <xmmintrin.h>
namespace {
// flush-to-zero + denormals-are-zero for the duration of one process call
struct ScopedNoDenormals
{
	unsigned int old;
	ScopedNoDenormals () : old (_mm_getcsr ()) { _mm_setcsr (old | 0x8040); }
	~ScopedNoDenormals () { _mm_setcsr (old); }
};
} // namespace
#else
namespace {
struct ScopedNoDenormals {};
} // namespace
#endif

using namespace Steinberg;
using namespace Steinberg::Vst;

namespace sphsvst {

//------------------------------------------------------------------------
Processor::Processor ()
{
	setControllerClass (kControllerUID);
	for (int i = 0; i < sphs::kCoreNumParams; ++i)
		shadow_[i].store (sphs::coreParamDefault (i));
	std::memset (scratch_, 0, sizeof (scratch_));
}

tresult PLUGIN_API Processor::initialize (FUnknown* context)
{
	const tresult result = AudioEffect::initialize (context);
	if (result != kResultOk)
		return result;
	addAudioInput (STR16 ("Input"), SpeakerArr::kMono);
	addAudioOutput (STR16 ("Stereo Out"), SpeakerArr::kStereo);
	// lets a MIDI track send controller data (expression pedal) to the plug-in
	addEventInput (STR16 ("MIDI In"), 1);
	return kResultOk;
}

tresult PLUGIN_API Processor::setBusArrangements (SpeakerArrangement* inputs, int32 numIns,
                                                  SpeakerArrangement* outputs, int32 numOuts)
{
	// The effect is mono in -> stereo out. A stereo input is accepted too
	// (needed on stereo tracks) and is summed to mono before the effect.
	if (numIns == 1 && numOuts == 1 && outputs[0] == SpeakerArr::kStereo &&
	    (inputs[0] == SpeakerArr::kMono || inputs[0] == SpeakerArr::kStereo))
	{
		if (auto* bus = FCast<AudioBus> (audioInputs.at (0)))
			bus->setArrangement (inputs[0]);
		return kResultTrue;
	}
	return kResultFalse;
}

tresult PLUGIN_API Processor::canProcessSampleSize (int32 symbolicSampleSize)
{
	return symbolicSampleSize == kSample32 ? kResultTrue : kResultFalse;
}

tresult PLUGIN_API Processor::setupProcessing (ProcessSetup& setup)
{
	// not running here: allocation is allowed
	core_.prepare (setup.sampleRate);
	referenceLatency_.store (core_.latencySamples (sphs::EngineMode::Reference));
	stateDirty_.store (true); // re-apply the saved values on the first block
	return AudioEffect::setupProcessing (setup);
}

tresult PLUGIN_API Processor::setActive (TBool state)
{
	if (state)
	{
		for (int i = 0; i < sphs::kCoreNumParams; ++i)
			core_.setParam (i, shadow_[i].load ());
		stateDirty_.store (false);
		core_.reset ();
	}
	return AudioEffect::setActive (state);
}

uint32 PLUGIN_API Processor::getLatencySamples ()
{
	return latencyMode_.load () ? static_cast<uint32> (referenceLatency_.load ()) : 0;
}

uint32 PLUGIN_API Processor::getTailSamples ()
{
	return static_cast<uint32> (processSetup.sampleRate * 2.); // resonance ring-out
}

tresult PLUGIN_API Processor::notify (IMessage* message)
{
	if (message && std::strcmp (message->getMessageID (), SPHS_MSG_MODE) == 0)
	{
		int64 mode = 0;
		if (message->getAttributes () && message->getAttributes ()->getInt ("mode", mode) == kResultOk)
			latencyMode_.store (mode ? 1 : 0);
		return kResultOk;
	}
	return AudioEffect::notify (message);
}

//------------------------------------------------------------------------
tresult PLUGIN_API Processor::process (ProcessData& data)
{
	ScopedNoDenormals noDenormals;

	if (stateDirty_.exchange (false))
		for (int i = 0; i < sphs::kCoreNumParams; ++i)
			core_.setParam (i, shadow_[i].load ());

	// ---- automation: every point keeps its sample offset ----------------
	int numEvents = 0;
	if (IParameterChanges* changes = data.inputParameterChanges)
	{
		const int32 queues = changes->getParameterCount ();
		for (int32 q = 0; q < queues; ++q)
		{
			IParamValueQueue* queue = changes->getParameterData (q);
			if (!queue)
				continue;
			const int idx = coreIndexOfParam (queue->getParameterId ());
			if (idx < 0)
				continue;
			const int32 points = queue->getPointCount ();
			for (int32 p = 0; p < points; ++p)
			{
				int32 offset = 0;
				ParamValue value = 0.;
				if (queue->getPoint (p, offset, value) != kResultTrue)
					continue;
				offset = std::max<int32> (0, std::min<int32> (offset, std::max<int32> (0, data.numSamples)));
				if (numEvents < kMaxEvents)
					events_[numEvents++] = {offset, idx, value};
				else
				{
					// table full (never seen in practice): keep at least the newest value
					for (int k = numEvents - 1; k >= 0; --k)
						if (events_[k].param == idx)
						{
							events_[k].value = value;
							break;
						}
				}
				shadow_[idx].store (value);
				if (idx == sphs::kCoreEngineMode)
					latencyMode_.store (value > 0.5 ? 1 : 0);
			}
		}
		std::sort (events_, events_ + numEvents, [] (const sphs::CoreEvent& a, const sphs::CoreEvent& b) {
			return a.offset != b.offset ? a.offset < b.offset : a.param < b.param;
		});
	}

	const bool haveOutput = data.numSamples > 0 && data.numOutputs > 0 && data.outputs &&
	                        data.outputs[0].numChannels > 0 && data.outputs[0].channelBuffers32;
	if (!haveOutput)
	{
		// parameter flush without audio
		core_.process (nullptr, nullptr, nullptr, nullptr, 0, events_, numEvents);
		return kResultOk;
	}

	const float* inL = nullptr;
	const float* inR = nullptr;
	if (data.numInputs > 0 && data.inputs && data.inputs[0].numChannels > 0 && data.inputs[0].channelBuffers32)
	{
		inL = data.inputs[0].channelBuffers32[0];
		if (data.inputs[0].numChannels > 1)
			inR = data.inputs[0].channelBuffers32[1];
	}

	AudioBusBuffers& out = data.outputs[0];
	float* outL = out.channelBuffers32[0];
	float* outR = out.numChannels > 1 ? out.channelBuffers32[1] : nullptr;

	if (outL && outR)
	{
		core_.process (inL, inR, outL, outR, data.numSamples, events_, numEvents);
	}
	else if (outL)
	{
		// a host insisted on one output channel: deliver the left signal
		core_.process (nullptr, nullptr, nullptr, nullptr, 0, events_, numEvents);
		int32 pos = 0;
		while (pos < data.numSamples)
		{
			const int32 n = std::min<int32> (1024, data.numSamples - pos);
			core_.process (inL ? inL + pos : nullptr, inR ? inR + pos : nullptr, outL + pos, scratch_, n, nullptr, 0);
			pos += n;
		}
	}
	out.silenceFlags = 0;
	return kResultOk;
}

//------------------------------------------------------------------------
tresult PLUGIN_API Processor::setState (IBStream* state)
{
	if (!state)
		return kResultFalse;
	IBStreamer s (state, kLittleEndian);
	int32 magic = 0, version = 0, count = 0;
	if (!s.readInt32 (magic) || magic != kProcessorStateMagic)
		return kResultFalse;
	if (!s.readInt32 (version) || !s.readInt32 (count))
		return kResultFalse;
	if (version < 1 || count < 0 || count > 64)
		return kResultFalse;
	for (int32 i = 0; i < count; ++i)
	{
		double v = 0.;
		if (!s.readDouble (v))
			return kResultFalse;
		if (i < sphs::kCoreNumParams)
			shadow_[i].store (sphs::clamp01 (v));
	}
	latencyMode_.store (shadow_[sphs::kCoreEngineMode].load () > 0.5 ? 1 : 0);
	stateDirty_.store (true);
	return kResultOk;
}

tresult PLUGIN_API Processor::getState (IBStream* state)
{
	if (!state)
		return kResultFalse;
	IBStreamer s (state, kLittleEndian);
	s.writeInt32 (kProcessorStateMagic);
	s.writeInt32 (kStateVersion);
	s.writeInt32 (sphs::kCoreNumParams);
	for (int i = 0; i < sphs::kCoreNumParams; ++i)
		s.writeDouble (shadow_[i].load ());
	return kResultOk;
}

} // namespace sphsvst
