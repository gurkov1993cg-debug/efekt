#pragma once
#include "Ids.h"
#include "pluginterfaces/vst/ivstmidicontrollers.h"
#include "public.sdk/source/vst/vsteditcontroller.h"

namespace sphsvst {

class Editor;

class Controller : public Steinberg::Vst::EditController, public Steinberg::Vst::IMidiMapping
{
public:
	// Program memory as in the owner's manual: 32 user programs,
	// A11..A44 and B11..B44 (USER A/B x bank 1-4 x program 1-4).
	// Internal bank index 0..3 = USER A bank 1..4, 4..7 = USER B bank 1..4.
	static constexpr int kBanks = 8;
	static constexpr int kPerBank = 4;
	static constexpr int kNumPrograms = kBanks * kPerBank;
	static constexpr int kProgramParams = 7; ///< Speed, Depth, Manual, Resonance, pedal PARAM / MIN / MAX

	static Steinberg::FUnknown* createInstance (void*)
	{
		return static_cast<Steinberg::Vst::IEditController*> (new Controller ());
	}

	// EditController
	Steinberg::tresult PLUGIN_API initialize (Steinberg::FUnknown* context) SMTG_OVERRIDE;
	Steinberg::tresult PLUGIN_API setComponentState (Steinberg::IBStream* state) SMTG_OVERRIDE;
	Steinberg::tresult PLUGIN_API setState (Steinberg::IBStream* state) SMTG_OVERRIDE;
	Steinberg::tresult PLUGIN_API getState (Steinberg::IBStream* state) SMTG_OVERRIDE;
	Steinberg::IPlugView* PLUGIN_API createView (Steinberg::FIDString name) SMTG_OVERRIDE;
	Steinberg::tresult PLUGIN_API setParamNormalized (Steinberg::Vst::ParamID tag,
	                                                  Steinberg::Vst::ParamValue value) SMTG_OVERRIDE;
	void editorDestroyed (Steinberg::Vst::EditorView* editor) SMTG_OVERRIDE;

	// IMidiMapping: expression (CC 11) and foot controller (CC 4) move the pedal
	Steinberg::tresult PLUGIN_API getMidiControllerAssignment (Steinberg::int32 busIndex,
	                                                           Steinberg::int16 channel,
	                                                           Steinberg::Vst::CtrlNumber midiControllerNumber,
	                                                           Steinberg::Vst::ParamID& id) SMTG_OVERRIDE;

	// ---- used by the editor ------------------------------------------------
	double norm (Steinberg::Vst::ParamID id) { return getParamNormalized (id); }
	/** A complete user edit (begin / perform / end) of one parameter. */
	void editParam (Steinberg::Vst::ParamID id, double value);
	/** Value change during a drag: the control itself sends begin / end. */
	void dragParam (Steinberg::Vst::ParamID id, double value);

	int bank () const { return bank_; }
	int program () const { return program_; }
	bool programEdited ();
	void selectProgram (int bank, int program);
	void writeProgram ();
	// selection with the USER A/B key, the single BANK switch and program switches 1-4
	bool userB () const { return bank_ >= 4; }
	int bankNumber () const { return bank_ % 4 + 1; }
	bool bankPending () const { return bankPending_; }
	int pendingBank () const { return pendingBank_; } ///< -1 while waiting for the bank number
	void pressBank ();
	void pressProgram (int index);
	void toggleUserAB ();
	bool hold () const { return hold_; }
	void setHold (bool on) { hold_ = on; }
	int selectedParam () const { return selected_; }
	void setSelectedParam (int id) { selected_ = id; }
	sphs::PedalTarget pedalTarget ();
	/** Values the DSP really uses (pedal applied). */
	sphs::UserParams effective ();

	OBJ_METHODS (Controller, EditController)
	DEFINE_INTERFACES
		DEF_INTERFACE (IMidiMapping)
	END_DEFINE_INTERFACES (EditController)
	REFCOUNT_METHODS (EditController)

private:
	void announceMode (bool restart);
	void fillNorm (double* norm);

	Editor* editor_ = nullptr;
	double programs_[kNumPrograms][kProgramParams];
	int bank_ = 0;
	int program_ = 0;
	bool hold_ = false;
	int selected_ = kParamSpeed;
	int lastMode_ = 0;
	bool bankPending_ = false;
	int pendingBank_ = -1;
};

/** VST3 parameter IDs stored in a program, in storage order. */
static const Steinberg::Vst::ParamID kProgramParamIds[Controller::kProgramParams] = {
    kParamSpeed, kParamDepth, kParamManual, kParamResonance, kParamPedalTarget, kParamPedalMin, kParamPedalMax};

} // namespace sphsvst
