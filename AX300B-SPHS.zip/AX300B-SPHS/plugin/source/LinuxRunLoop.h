// Linux only (used for the development/test build, not for the macOS target):
// connects VSTGUI's X11 event handling to the host run loop.
#pragma once
#include "pluginterfaces/base/fplatform.h"
#if SMTG_OS_LINUX
#include "base/source/fobject.h"
#include "pluginterfaces/gui/iplugview.h"
#include "vstgui/lib/platform/linux/x11frame.h"
#include <vector>

namespace sphsvst {

class LinuxRunLoop : public VSTGUI::X11::IRunLoop, public VSTGUI::AtomicReferenceCounted
{
public:
	explicit LinuxRunLoop (Steinberg::FUnknown* hostFrame) : runLoop_ (hostFrame) {}

	bool registerEventHandler (int fd, VSTGUI::X11::IEventHandler* handler) final
	{
		if (!runLoop_)
			return false;
		auto h = Steinberg::owned (new Event ());
		h->target = handler;
		if (runLoop_->registerEventHandler (h, fd) != Steinberg::kResultTrue)
			return false;
		events_.push_back (h);
		return true;
	}
	bool unregisterEventHandler (VSTGUI::X11::IEventHandler* handler) final
	{
		for (auto it = events_.begin (); runLoop_ && it != events_.end (); ++it)
			if ((*it)->target == handler)
			{
				runLoop_->unregisterEventHandler (*it);
				events_.erase (it);
				return true;
			}
		return false;
	}
	bool registerTimer (uint64_t interval, VSTGUI::X11::ITimerHandler* handler) final
	{
		if (!runLoop_)
			return false;
		auto h = Steinberg::owned (new Timer ());
		h->target = handler;
		if (runLoop_->registerTimer (h, interval) != Steinberg::kResultTrue)
			return false;
		timers_.push_back (h);
		return true;
	}
	bool unregisterTimer (VSTGUI::X11::ITimerHandler* handler) final
	{
		for (auto it = timers_.begin (); runLoop_ && it != timers_.end (); ++it)
			if ((*it)->target == handler)
			{
				runLoop_->unregisterTimer (*it);
				timers_.erase (it);
				return true;
			}
		return false;
	}

private:
	struct Event : Steinberg::Linux::IEventHandler, Steinberg::FObject
	{
		VSTGUI::X11::IEventHandler* target = nullptr;
		void PLUGIN_API onFDIsSet (Steinberg::Linux::FileDescriptor) override
		{
			if (target)
				target->onEvent ();
		}
		DELEGATE_REFCOUNT (Steinberg::FObject)
		DEFINE_INTERFACES
			DEF_INTERFACE (Steinberg::Linux::IEventHandler)
		END_DEFINE_INTERFACES (Steinberg::FObject)
	};
	struct Timer : Steinberg::Linux::ITimerHandler, Steinberg::FObject
	{
		VSTGUI::X11::ITimerHandler* target = nullptr;
		void PLUGIN_API onTimer () override
		{
			if (target)
				target->onTimer ();
		}
		DELEGATE_REFCOUNT (Steinberg::FObject)
		DEFINE_INTERFACES
			DEF_INTERFACE (Steinberg::Linux::ITimerHandler)
		END_DEFINE_INTERFACES (Steinberg::FObject)
	};
	std::vector<Steinberg::IPtr<Event>> events_;
	std::vector<Steinberg::IPtr<Timer>> timers_;
	Steinberg::FUnknownPtr<Steinberg::Linux::IRunLoop> runLoop_;
};

} // namespace sphsvst
#endif // SMTG_OS_LINUX
