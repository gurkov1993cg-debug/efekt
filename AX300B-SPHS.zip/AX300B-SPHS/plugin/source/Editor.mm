// Native Cocoa/AppKit editor (Objective-C++). One light NSView draws the whole
// panel with vector drawing and turns mouse actions into real VST3 parameter
// edits through the controller. No DSP runs here; no timers, no animation.
#import <AppKit/AppKit.h>

#include "Editor.h"
#include "Controller.h"
#include "sphs/ModelConfig.h"
#include <cmath>
#include <cstdio>
#include <cstring>

#if defined(__has_feature) && __has_feature(objc_arc)
#define SPHS_RELEASE(x)
#define SPHS_SUPER_DEALLOC()
#else
#define SPHS_RELEASE(x) [(x) release]
#define SPHS_SUPER_DEALLOC() [super dealloc]
#endif

#if defined(GNUSTEP)
#define SPHS_SHIFT_FLAG NSShiftKeyMask // development check with GNUstep only
#else
#define SPHS_SHIFT_FLAG NSEventModifierFlagShift
#endif

using namespace sphsvst;

namespace {

enum WidgetKind { kKnob, kKey, kFoot, kPedal };

enum CommandTags
{
	kTagBypass = 1000,
	kTagMode,
	kTagWrite,
	kTagPedalParam,
	kTagHold,
	kTagBank,
	kTagUserAB,
	kTagProg1,
	kTagProg2,
	kTagProg3,
	kTagProg4
};

struct Widget
{
	WidgetKind kind;
	NSRect rect;
	int tag;	  // parameter ID (knob, pedal) or command tag (key, foot switch)
	double def;	  // default normalized value (knobs)
	bool green;	  // LED colour
};

const int kMaxWidgets = 24;

NSColor* rgb (int r, int g, int b, CGFloat a = 1.0)
{
	return [NSColor colorWithCalibratedRed:r / 255.0 green:g / 255.0 blue:b / 255.0 alpha:a];
}

NSColor* accent () { return rgb (0, 168, 150); }
NSColor* textColor () { return rgb (214, 220, 226); }
NSColor* dimColor () { return rgb (140, 148, 158); }

NSFont* font (NSString* name, CGFloat size, bool bold)
{
	NSFont* f = [NSFont fontWithName:name size:size];
	if (!f)
		f = bold ? [NSFont boldSystemFontOfSize:size] : [NSFont systemFontOfSize:size];
	return f;
}
NSFont* labelFont (CGFloat size) { return font (@"Helvetica-Bold", size, true); }
NSFont* monoBold (CGFloat size) { return font (@"Menlo-Bold", size, true); }
NSFont* monoPlain (CGFloat size) { return font (@"Menlo-Regular", size, false); }

NSRect rectLTRB (CGFloat l, CGFloat t, CGFloat r, CGFloat b) { return NSMakeRect (l, t, r - l, b - t); }

// vertical gradient from the top edge to the bottom edge of `r` (view is flipped)
void fillPath (NSBezierPath* path, NSRect r, NSColor* top, NSColor* bottom)
{
	NSGradient* g = [[NSGradient alloc] initWithStartingColor:top endingColor:bottom];
	[NSGraphicsContext saveGraphicsState];
	[path addClip];
	[g drawFromPoint:NSMakePoint (NSMidX (r), NSMinY (r))
	         toPoint:NSMakePoint (NSMidX (r), NSMaxY (r))
	         options:(NSGradientDrawsBeforeStartingLocation | NSGradientDrawsAfterEndingLocation)];
	[NSGraphicsContext restoreGraphicsState];
	SPHS_RELEASE (g);
}

void fillRound (NSRect r, CGFloat radius, NSColor* top, NSColor* bottom)
{
	fillPath ([NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius], r, top, bottom);
}

void strokeRound (NSRect r, CGFloat radius, NSColor* color, CGFloat width)
{
	NSBezierPath* p = [NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius];
	[p setLineWidth:width];
	[color setStroke];
	[p stroke];
}

void fillOval (NSRect r, NSColor* top, NSColor* bottom)
{
	fillPath ([NSBezierPath bezierPathWithOvalInRect:r], r, top, bottom);
}

void strokeOval (NSRect r, NSColor* color, CGFloat width)
{
	NSBezierPath* p = [NSBezierPath bezierPathWithOvalInRect:r];
	[p setLineWidth:width];
	[color setStroke];
	[p stroke];
}

void drawLine (NSPoint a, NSPoint b, NSColor* color, CGFloat width)
{
	NSBezierPath* p = [NSBezierPath bezierPath];
	[p moveToPoint:a];
	[p lineToPoint:b];
	[p setLineWidth:width];
	[color setStroke];
	[p stroke];
}

void fillRect (NSRect r, NSColor* color)
{
	[color setFill];
	NSRectFill (r);
}

// align: 0 left, 1 centre, 2 right; text is centred vertically in `r`
void drawText (const char* utf8, NSRect r, NSFont* f, NSColor* color, int align)
{
	NSString* s = [NSString stringWithUTF8String:utf8];
	if (!s)
		return;
	NSMutableParagraphStyle* style = [[NSMutableParagraphStyle alloc] init];
	[style setAlignment:(align == 1 ? NSTextAlignmentCenter : (align == 2 ? NSTextAlignmentRight : NSTextAlignmentLeft))];
	[style setLineBreakMode:NSLineBreakByClipping];
	NSDictionary* attrs = [NSDictionary dictionaryWithObjectsAndKeys:f, NSFontAttributeName, color,
	                                                                 NSForegroundColorAttributeName, style,
	                                                                 NSParagraphStyleAttributeName, nil];
	const NSSize size = [s sizeWithAttributes:attrs];
	const NSRect tr = NSMakeRect (r.origin.x, r.origin.y + (r.size.height - size.height) * 0.5, r.size.width, size.height);
	[s drawInRect:tr withAttributes:attrs];
	SPHS_RELEASE (style);
}

void drawLed (NSPoint c, CGFloat radius, NSColor* color)
{
	const NSRect r = NSMakeRect (c.x - radius, c.y - radius, 2 * radius, 2 * radius);
	fillOval (r, color, color);
	strokeOval (r, rgb (0, 0, 0, 0.63), 1.0);
}

NSColor* ledColor (bool green, bool on)
{
	if (green)
		return on ? rgb (90, 235, 130) : rgb (26, 62, 38);
	return on ? rgb (255, 72, 48) : rgb (74, 30, 26);
}

const char* const kTargetNames[sphs::kNumPedalTargets] = {"OFF", "SPEED", "DEPTH", "MANUAL", "RESONANCE"};

} // namespace

//------------------------------------------------------------------------
@interface SPHSPhaserView : NSView
{
	Controller* _ctrl; // not owned; cleared by -detach before the controller goes away
	Widget _widgets[kMaxWidgets];
	int _count;
	int _active;
	BOOL _pressed;
	CGFloat _startY;
	double _startValue;
}
- (id)initWithFrame:(NSRect)frame controller:(Controller*)controller;
- (void)detach;
- (void)markDirty;
@end

@implementation SPHSPhaserView

- (void)addWidget:(WidgetKind)kind rect:(NSRect)rect tag:(int)tag def:(double)def green:(bool)green
{
	if (_count < kMaxWidgets)
	{
		Widget w;
		w.kind = kind;
		w.rect = rect;
		w.tag = tag;
		w.def = def;
		w.green = green;
		_widgets[_count++] = w;
	}
}

- (id)initWithFrame:(NSRect)frame controller:(Controller*)controller
{
	self = [super initWithFrame:frame];
	if (self)
	{
		_ctrl = controller;
		_count = 0;
		_active = -1;
		_pressed = NO;
		_startY = 0;
		_startValue = 0;

		// the four original SPHS parameters
		const int mainIds[4] = {kParamSpeed, kParamDepth, kParamManual, kParamResonance};
		for (int i = 0; i < 4; ++i)
		{
			const CGFloat x = 412.0 + 88.0 * i;
			[self addWidget:kKnob rect:rectLTRB (x, 54, x + 86, 148) tag:mainIds[i]
			            def:sphs::coreParamDefault (coreIndexOfParam (static_cast<Steinberg::Vst::ParamID> (mainIds[i])))
			          green:false];
		}
		// pedal MIN / MAX
		[self addWidget:kKnob rect:rectLTRB (542, 176, 610, 246) tag:kParamPedalMin def:0.0 green:false];
		[self addWidget:kKnob rect:rectLTRB (614, 176, 682, 246) tag:kParamPedalMax def:1.0 green:false];
		// keys
		[self addWidget:kKey rect:rectLTRB (34, 190, 144, 226) tag:kTagBypass def:0 green:false];
		[self addWidget:kKey rect:rectLTRB (154, 190, 274, 226) tag:kTagMode def:0 green:true];
		[self addWidget:kKey rect:rectLTRB (284, 190, 384, 226) tag:kTagWrite def:0 green:false];
		[self addWidget:kKey rect:rectLTRB (412, 196, 540, 232) tag:kTagPedalParam def:0 green:true];
		[self addWidget:kKey rect:rectLTRB (690, 196, 762, 232) tag:kTagHold def:0 green:true];
		// foot switches
		[self addWidget:kFoot rect:rectLTRB (44, 276, 134, 402) tag:kTagBank def:0 green:true];
		[self addWidget:kKey rect:rectLTRB (154, 320, 274, 356) tag:kTagUserAB def:0 green:true];
		for (int i = 0; i < 4; ++i)
		{
			const CGFloat x = 304.0 + 116.0 * i;
			[self addWidget:kFoot rect:rectLTRB (x, 276, x + 90, 402) tag:kTagProg1 + i def:0 green:false];
		}
		// pressure pedal
		[self addWidget:kPedal rect:rectLTRB (790, 20, 900, 410) tag:kParamPedalPos def:0 green:false];
	}
	return self;
}

- (void)dealloc
{
	_ctrl = nullptr;
	SPHS_SUPER_DEALLOC ();
}

- (void)detach { _ctrl = nullptr; }
- (void)markDirty { [self setNeedsDisplay:YES]; }

- (BOOL)isFlipped { return YES; } // top-left origin, same layout coordinates everywhere
- (BOOL)isOpaque { return YES; }
- (BOOL)acceptsFirstMouse:(NSEvent*)event { return YES; }
- (BOOL)mouseDownCanMoveWindow { return NO; }

//------------------------------------------------------------------------
// state of a key / foot switch: lit LED and caption, all from real controller values
- (bool)stateOfTag:(int)tag caption:(char*)caption size:(size_t)size
{
	const sphs::PedalTarget target = _ctrl->pedalTarget ();
	const int targetIndex = static_cast<int> (target);
	switch (tag)
	{
		case kTagBypass: std::snprintf (caption, size, "BYPASS"); return _ctrl->norm (kParamBypass) > 0.5;
		case kTagMode:
		{
			const bool reference = _ctrl->norm (kParamEngineMode) > 0.5;
			std::snprintf (caption, size, "%s", reference ? "REF 39 kHz" : "NATIVE");
			return reference;
		}
		case kTagWrite: std::snprintf (caption, size, "WRITE"); return _ctrl->programEdited ();
		case kTagPedalParam:
			std::snprintf (caption, size, "PARAM: %s", targetIndex == 4 ? "RESO" : kTargetNames[targetIndex]);
			return target != sphs::PedalTarget::Off;
		case kTagHold: std::snprintf (caption, size, "HOLD"); return _ctrl->hold ();
		case kTagBank: std::snprintf (caption, size, "BANK"); return _ctrl->bankPending ();
		case kTagUserAB:
			std::snprintf (caption, size, "%s", _ctrl->userB () ? "USER B" : "USER A");
			return _ctrl->userB (); // lit = user programs B, as on the original
		default:
			std::snprintf (caption, size, "%d", tag - kTagProg1 + 1);
			if (_ctrl->bankPending ())
				return _ctrl->pendingBank () == tag - kTagProg1; // shows the chosen bank number
			return _ctrl->program () == tag - kTagProg1;
	}
}

- (void)drawPanel
{
	const NSRect b = [self bounds];
	fillRect (b, rgb (12, 13, 15));
	const NSRect body = NSInsetRect (b, 4, 4);
	fillRound (body, 14, rgb (52, 56, 64), rgb (22, 24, 29));
	strokeRound (body, 14, rgb (96, 102, 112), 1.5);

	fillRect (rectLTRB (24, 36, 770, 38), accent ());
	drawText ("SPHS  STEREO PHASER", rectLTRB (24, 12, 400, 34), labelFont (15), textColor (), 0);
	char model[96];
	std::snprintf (model, sizeof (model), "MODEL: %s  (%s)", sphs::defaultModel ().name,
	               sphs::defaultModel ().fittedToHardware ? "fitted to hardware" : "NOT fitted to hardware");
	drawText (model, rectLTRB (400, 14, 770, 34), labelFont (10), dimColor (), 2);

	strokeRound (rectLTRB (404, 46, 770, 158), 8, rgb (72, 78, 88), 1.0);
	strokeRound (rectLTRB (404, 168, 770, 252), 8, rgb (72, 78, 88), 1.0);
	strokeRound (rectLTRB (24, 168, 394, 252), 8, rgb (72, 78, 88), 1.0);
	drawText ("PEDAL ASSIGN", rectLTRB (414, 170, 600, 184), labelFont (10), dimColor (), 0);
	drawText ("PROGRAM", rectLTRB (34, 170, 200, 184), labelFont (10), dimColor (), 0);

	const NSRect deck = rectLTRB (24, 264, 770, 410);
	fillRound (deck, 10, rgb (30, 32, 38), rgb (18, 19, 23));
	strokeRound (deck, 10, rgb (72, 78, 88), 1.0);
}

- (void)drawLcd
{
	const sphs::PedalTarget target = _ctrl->pedalTarget ();
	const int targetIndex = static_cast<int> (target);
	const sphs::UserParams eff = _ctrl->effective ();
	const bool bypassed = _ctrl->norm (kParamBypass) > 0.5;
	const bool reference = _ctrl->norm (kParamEngineMode) > 0.5;
	char l1[96], l2[96], l3[96];

	const char group = _ctrl->userB () ? 'B' : 'A';
	if (_ctrl->bankPending () && _ctrl->pendingBank () < 0)
		std::snprintf (l1, sizeof (l1), "%c--   SELECT BANK 1-4", group);
	else if (_ctrl->bankPending ())
		std::snprintf (l1, sizeof (l1), "%c%d-   SELECT PROGRAM 1-4", group, _ctrl->pendingBank () + 1);
	else
		std::snprintf (l1, sizeof (l1), "%c%d%d%s   %s", group, _ctrl->bankNumber (), _ctrl->program () + 1,
		               _ctrl->programEdited () ? " *" : "", bypassed ? "BYPASS" : (reference ? "REF 39.0625k" : "NATIVE"));
	const int sel = _ctrl->selectedParam ();
	switch (sel)
	{
		case kParamDepth: std::snprintf (l2, sizeof (l2), "DEPTH   %5.1f", eff.depth); break;
		case kParamManual: std::snprintf (l2, sizeof (l2), "MANUAL  %5.1f", eff.manual); break;
		case kParamResonance: std::snprintf (l2, sizeof (l2), "RESO   %+6.1f", eff.resonance); break;
		case kParamPedalMin:
		case kParamPedalMax:
		{
			const double n = _ctrl->norm (static_cast<Steinberg::Vst::ParamID> (sel));
			const char* name = sel == kParamPedalMin ? "MIN" : "MAX";
			if (target == sphs::PedalTarget::Off)
				std::snprintf (l2, sizeof (l2), "PEDAL %s %3.0f%%", name, n * 100.);
			else
				std::snprintf (l2, sizeof (l2), "PEDAL %s %.2f", name, sphs::targetPlainFromNorm (target, n));
			break;
		}
		default: std::snprintf (l2, sizeof (l2), "SPEED %5.2f Hz", eff.speedHz); break;
	}
	if (target == sphs::PedalTarget::Off)
		std::snprintf (l3, sizeof (l3), "PEDAL > OFF");
	else
		std::snprintf (l3, sizeof (l3), "PEDAL > %s  %.2f..%.2f  %3.0f%%", kTargetNames[targetIndex],
		               sphs::targetPlainFromNorm (target, _ctrl->norm (kParamPedalMin)),
		               sphs::targetPlainFromNorm (target, _ctrl->norm (kParamPedalMax)),
		               _ctrl->norm (kParamPedalPos) * 100.);

	const NSRect outer = rectLTRB (24, 46, 394, 158);
	fillRound (outer, 6, rgb (10, 11, 13), rgb (10, 11, 13));
	const NSRect r = NSInsetRect (outer, 6, 6);
	fillRound (r, 3, rgb (196, 220, 128), rgb (164, 192, 100));
	NSColor* ink = rgb (26, 38, 18);
	const CGFloat left = NSMinX (r) + 10, right = NSMaxX (r) - 10;
	drawText (l1, rectLTRB (left, NSMinY (r) + 6, right, NSMinY (r) + 24), monoBold (12), ink, 0);
	drawText (l2, rectLTRB (left, NSMinY (r) + 28, right, NSMinY (r) + 56), monoBold (19), ink, 0);
	drawText (l3, rectLTRB (left, NSMaxY (r) - 26, right, NSMaxY (r) - 8), monoBold (12), ink, 0);
}

- (void)drawKnob:(const Widget&)w
{
	const sphs::PedalTarget target = _ctrl->pedalTarget ();
	const sphs::UserParams eff = _ctrl->effective ();
	const double value = _ctrl->norm (static_cast<Steinberg::Vst::ParamID> (w.tag));
	const NSRect vs = w.rect;
	const CGFloat d = fmin (vs.size.width, vs.size.height - 30.0);
	const NSPoint c = NSMakePoint (NSMinX (vs) + vs.size.width * 0.5, NSMinY (vs) + d * 0.5);
	const CGFloat rad = d * 0.5 - 4.0;

	for (int i = 0; i <= 10; ++i)
	{
		const double a = (-135.0 + 27.0 * i) * M_PI / 180.0;
		const bool reached = value * 10.0 + 0.001 >= i;
		drawLine (NSMakePoint (c.x + std::sin (a) * (rad + 1.0), c.y - std::cos (a) * (rad + 1.0)),
		          NSMakePoint (c.x + std::sin (a) * (rad + 4.0), c.y - std::cos (a) * (rad + 4.0)),
		          reached ? accent () : rgb (84, 90, 100), 1.5);
	}
	const NSRect cap = NSMakeRect (c.x - rad + 3.0, c.y - rad + 3.0, 2 * (rad - 3.0), 2 * (rad - 3.0));
	fillOval (cap, rgb (86, 92, 102), rgb (40, 43, 50));
	strokeOval (cap, rgb (10, 10, 12), 1.5);
	const double a = (-135.0 + 270.0 * value) * M_PI / 180.0;
	drawLine (NSMakePoint (c.x + std::sin (a) * (rad * 0.30), c.y - std::cos (a) * (rad * 0.30)),
	          NSMakePoint (c.x + std::sin (a) * (rad - 6.0), c.y - std::cos (a) * (rad - 6.0)), rgb (245, 245, 245), 2.5);

	// caption + the value the DSP really uses (pedal applied)
	const char* caption = "";
	char text[48];
	bool pedalDriven = false;
	switch (w.tag)
	{
		case kParamSpeed:
			caption = "SPEED";
			std::snprintf (text, sizeof (text), "%.2f Hz", eff.speedHz);
			pedalDriven = target == sphs::PedalTarget::Speed;
			break;
		case kParamDepth:
			caption = "DEPTH";
			std::snprintf (text, sizeof (text), "%.1f", eff.depth);
			pedalDriven = target == sphs::PedalTarget::Depth;
			break;
		case kParamManual:
			caption = "MANUAL";
			std::snprintf (text, sizeof (text), "%.1f", eff.manual);
			pedalDriven = target == sphs::PedalTarget::Manual;
			break;
		case kParamResonance:
			caption = "RESONANCE";
			std::snprintf (text, sizeof (text), "%+.1f", eff.resonance);
			pedalDriven = target == sphs::PedalTarget::Resonance;
			break;
		default:
			caption = w.tag == kParamPedalMin ? "MIN" : "MAX";
			if (target == sphs::PedalTarget::Off)
				std::snprintf (text, sizeof (text), "%.0f %%", value * 100.);
			else if (target == sphs::PedalTarget::Speed)
				std::snprintf (text, sizeof (text), "%.2f Hz", sphs::targetPlainFromNorm (target, value));
			else
				std::snprintf (text, sizeof (text), "%.1f", sphs::targetPlainFromNorm (target, value));
			break;
	}
	drawText (caption, rectLTRB (NSMinX (vs), NSMinY (vs) + d, NSMaxX (vs), NSMinY (vs) + d + 14), labelFont (11), textColor (), 1);
	drawText (text, rectLTRB (NSMinX (vs), NSMinY (vs) + d + 14, NSMaxX (vs), NSMinY (vs) + d + 28), monoPlain (11),
	          pedalDriven ? accent () : dimColor (), 1);
}

- (void)drawKey:(const Widget&)w pressed:(bool)pressed
{
	char caption[48];
	const bool lit = [self stateOfTag:w.tag caption:caption size:sizeof (caption)];
	const NSRect r = NSInsetRect (w.rect, 1, 1);
	if (pressed)
		fillRound (r, 6, rgb (30, 33, 38), rgb (58, 62, 70));
	else
		fillRound (r, 6, rgb (88, 94, 104), rgb (44, 47, 54));
	strokeRound (r, 6, rgb (8, 8, 10), 1.5);
	drawLed (NSMakePoint (NSMinX (r) + 12, NSMidY (r)), 4, ledColor (w.green, lit));
	drawText (caption, rectLTRB (NSMinX (r) + 22, NSMinY (r), NSMaxX (r) - 4, NSMaxY (r)), labelFont (11), textColor (), 1);
}

- (void)drawFoot:(const Widget&)w pressed:(bool)pressed
{
	char caption[48];
	const bool lit = [self stateOfTag:w.tag caption:caption size:sizeof (caption)];
	const NSRect vs = w.rect;
	const CGFloat d = fmin (vs.size.width, vs.size.height - 40.0);
	const NSPoint c = NSMakePoint (NSMidX (vs), NSMinY (vs) + 20.0 + d * 0.5);
	drawLed (NSMakePoint (c.x, NSMinY (vs) + 8), 5, ledColor (w.green, lit));
	const NSRect outer = NSMakeRect (c.x - d * 0.5, c.y - d * 0.5, d, d);
	fillOval (outer, rgb (150, 156, 166), rgb (58, 62, 70));
	const CGFloat inset = pressed ? 9.0 : 7.0;
	const NSRect inner = NSInsetRect (outer, inset, inset);
	if (pressed)
		fillOval (inner, rgb (70, 74, 82), rgb (120, 126, 134));
	else
		fillOval (inner, rgb (200, 205, 212), rgb (96, 102, 112));
	strokeOval (outer, rgb (8, 8, 10), 1.5);
	drawText (caption, rectLTRB (NSMinX (vs), NSMaxY (vs) - 18, NSMaxX (vs), NSMaxY (vs) - 2), labelFont (11), textColor (), 1);
}

- (void)drawPedal:(const Widget&)w
{
	const bool active = _ctrl->pedalTarget () != sphs::PedalTarget::Off;
	const double v = _ctrl->norm (kParamPedalPos);
	const NSRect r = NSInsetRect (w.rect, 2, 2);
	fillRound (r, 10, rgb (70, 75, 84), rgb (30, 32, 38));
	strokeRound (r, 10, rgb (8, 8, 10), 2.0);
	const NSRect pad = NSInsetRect (r, 10, 26);
	for (int i = 0; i < 14; ++i)
	{
		const CGFloat y = NSMinY (pad) + pad.size.height * (i + 0.5) / 14.0;
		const bool on = (1.0 - (i + 0.5) / 14.0) <= v;
		drawLine (NSMakePoint (NSMinX (pad), y), NSMakePoint (NSMaxX (pad), y),
		          on ? (active ? accent () : rgb (150, 156, 166)) : rgb (14, 15, 18), 3.0);
	}
	char text[32];
	std::snprintf (text, sizeof (text), "%d %%", static_cast<int> (v * 100.0 + 0.5));
	drawText ("PRESSURE", rectLTRB (NSMinX (r), NSMinY (r) + 5, NSMaxX (r), NSMinY (r) + 21), labelFont (11), textColor (), 1);
	drawText (text, rectLTRB (NSMinX (r), NSMaxY (r) - 21, NSMaxX (r), NSMaxY (r) - 5), labelFont (11),
	          active ? accent () : dimColor (), 1);
}

- (void)drawRect:(NSRect)dirtyRect
{
	if (!_ctrl)
	{
		fillRect ([self bounds], rgb (12, 13, 15));
		return;
	}
	[self drawPanel];
	[self drawLcd];
	for (int i = 0; i < _count; ++i)
	{
		const Widget& w = _widgets[i];
		const bool pressed = _pressed && _active == i;
		switch (w.kind)
		{
			case kKnob: [self drawKnob:w]; break;
			case kKey: [self drawKey:w pressed:pressed]; break;
			case kFoot: [self drawFoot:w pressed:pressed]; break;
			case kPedal: [self drawPedal:w]; break;
		}
	}
}

//------------------------------------------------------------------------
- (int)widgetAt:(NSPoint)p
{
	for (int i = 0; i < _count; ++i)
		if (NSPointInRect (p, _widgets[i].rect))
			return i;
	return -1;
}

- (void)pedalFollow:(NSPoint)p
{
	const NSRect pad = NSInsetRect (_widgets[_active].rect, 12, 28);
	const double v = 1.0 - (p.y - NSMinY (pad)) / fmax (1.0, pad.size.height);
	_ctrl->dragParam (kParamPedalPos, v);
}

- (void)runCommand:(int)tag
{
	switch (tag)
	{
		case kTagBypass: _ctrl->editParam (kParamBypass, _ctrl->norm (kParamBypass) > 0.5 ? 0. : 1.); break;
		case kTagMode: _ctrl->editParam (kParamEngineMode, _ctrl->norm (kParamEngineMode) > 0.5 ? 0. : 1.); break;
		case kTagWrite: _ctrl->writeProgram (); break;
		case kTagPedalParam:
		{
			const int next = (static_cast<int> (_ctrl->pedalTarget ()) + 1) % sphs::kNumPedalTargets;
			_ctrl->editParam (kParamPedalTarget, sphs::pedalTargetToNorm (static_cast<sphs::PedalTarget> (next)));
			break;
		}
		case kTagHold:
			_ctrl->setHold (!_ctrl->hold ());
			if (!_ctrl->hold ())
				_ctrl->editParam (kParamPedalPos, 0.); // pedal springs back
			break;
		case kTagBank: _ctrl->pressBank (); break;
		case kTagUserAB: _ctrl->toggleUserAB (); break;
		case kTagProg1:
		case kTagProg2:
		case kTagProg3:
		case kTagProg4: _ctrl->pressProgram (tag - kTagProg1); break;
		default: break;
	}
}

- (void)mouseDown:(NSEvent*)event
{
	if (!_ctrl)
		return;
	const NSPoint p = [self convertPoint:[event locationInWindow] fromView:nil];
	const int i = [self widgetAt:p];
	if (i < 0)
		return;
	const Widget& w = _widgets[i];
	_active = i;
	switch (w.kind)
	{
		case kKnob:
		{
			const Steinberg::Vst::ParamID pid = static_cast<Steinberg::Vst::ParamID> (w.tag);
			_ctrl->setSelectedParam (w.tag);
			if ([event clickCount] >= 2)
			{
				_ctrl->editParam (pid, w.def); // double click: default value
				_active = -1;
			}
			else
			{
				_ctrl->beginEdit (pid);
				_startY = p.y;
				_startValue = _ctrl->norm (pid);
			}
			break;
		}
		case kPedal:
			_ctrl->beginEdit (kParamPedalPos);
			[self pedalFollow:p];
			break;
		default: _pressed = YES; break;
	}
	[self setNeedsDisplay:YES];
}

- (void)mouseDragged:(NSEvent*)event
{
	if (!_ctrl || _active < 0)
		return;
	const NSPoint p = [self convertPoint:[event locationInWindow] fromView:nil];
	const Widget& w = _widgets[_active];
	if (w.kind == kKnob)
	{
		const double range = ([event modifierFlags] & SPHS_SHIFT_FLAG) ? 1200.0 : 170.0;
		_ctrl->dragParam (static_cast<Steinberg::Vst::ParamID> (w.tag), _startValue + (_startY - p.y) / range);
	}
	else if (w.kind == kPedal)
		[self pedalFollow:p];
	[self setNeedsDisplay:YES];
}

- (void)mouseUp:(NSEvent*)event
{
	if (!_ctrl || _active < 0)
		return;
	const NSPoint p = [self convertPoint:[event locationInWindow] fromView:nil];
	const Widget w = _widgets[_active];
	const BOOL wasPressed = _pressed;
	_active = -1;
	_pressed = NO;
	if (w.kind == kKnob)
		_ctrl->endEdit (static_cast<Steinberg::Vst::ParamID> (w.tag));
	else if (w.kind == kPedal)
	{
		if (!_ctrl->hold ())
			_ctrl->dragParam (kParamPedalPos, 0.); // pressure released
		_ctrl->endEdit (kParamPedalPos);
	}
	else if (wasPressed && NSPointInRect (p, w.rect))
		[self runCommand:w.tag];
	[self setNeedsDisplay:YES];
}

@end

//------------------------------------------------------------------------
namespace sphsvst {

struct Editor::Impl
{
	SPHSPhaserView* view;
};

Editor::Editor (Controller* controller) : EditorView (controller), impl_ (new Impl ()), ctrl_ (controller)
{
	impl_->view = nil;
	Steinberg::ViewRect size (0, 0, kWidth, kHeight);
	setRect (size);
}

Editor::~Editor ()
{
	if (impl_->view)
	{
		[impl_->view detach];
		[impl_->view removeFromSuperview];
		SPHS_RELEASE (impl_->view);
		impl_->view = nil;
	}
	delete impl_;
}

Steinberg::tresult PLUGIN_API Editor::isPlatformTypeSupported (Steinberg::FIDString type)
{
	return (type && std::strcmp (type, Steinberg::kPlatformTypeNSView) == 0) ? Steinberg::kResultTrue : Steinberg::kResultFalse;
}

Steinberg::tresult PLUGIN_API Editor::attached (void* parent, Steinberg::FIDString type)
{
	if (!parent || isPlatformTypeSupported (type) != Steinberg::kResultTrue || impl_->view)
		return Steinberg::kResultFalse;
#if defined(__has_feature) && __has_feature(objc_arc)
	NSView* parentView = (__bridge NSView*)parent;
#else
	NSView* parentView = (NSView*)parent;
#endif
	impl_->view = [[SPHSPhaserView alloc] initWithFrame:NSMakeRect (0, 0, kWidth, kHeight) controller:ctrl_];
	if (!impl_->view)
		return Steinberg::kResultFalse;
	[parentView addSubview:impl_->view];
	return EditorView::attached (parent, type);
}

Steinberg::tresult PLUGIN_API Editor::removed ()
{
	if (impl_->view)
	{
		[impl_->view detach];
		[impl_->view removeFromSuperview];
		SPHS_RELEASE (impl_->view);
		impl_->view = nil;
	}
	return EditorView::removed ();
}

void Editor::refresh ()
{
	if (!impl_->view)
		return;
	if ([NSThread isMainThread])
		[impl_->view setNeedsDisplay:YES];
	else
		[impl_->view performSelectorOnMainThread:@selector (markDirty) withObject:nil waitUntilDone:NO];
}

} // namespace sphsvst
