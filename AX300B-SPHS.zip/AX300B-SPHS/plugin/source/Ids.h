// Class IDs and parameter IDs. NEVER change these numbers: hosts store them
// in projects and automation tracks.
#pragma once
#include "pluginterfaces/base/funknown.h"
#include "pluginterfaces/vst/vsttypes.h"
#include "sphs/PluginCore.h"

namespace sphsvst {

static DECLARE_UID (kProcessorUID, 0x4C848E61, 0xD6CC4357, 0x88851648, 0x0E0BB8A7);
static DECLARE_UID (kControllerUID, 0x3897355E, 0xEB27416D, 0x9606057D, 0x51CD04DE);

enum ParamIds : Steinberg::Vst::ParamID
{
	kParamBypass = 1,
	kParamSpeed = 10,
	kParamDepth = 11,
	kParamManual = 12,
	kParamResonance = 13,
	kParamPedalTarget = 20,
	kParamPedalMin = 21,
	kParamPedalMax = 22,
	kParamPedalPos = 23,
	kParamEngineMode = 30
};

/** VST3 parameter ID of every core parameter, in core order. */
static const Steinberg::Vst::ParamID kParamIdOfCore[sphs::kCoreNumParams] = {
    kParamBypass,	   kParamSpeed,	   kParamDepth,	   kParamManual,   kParamResonance,
    kParamPedalTarget, kParamPedalMin, kParamPedalMax, kParamPedalPos, kParamEngineMode};

inline int coreIndexOfParam (Steinberg::Vst::ParamID id)
{
	for (int i = 0; i < sphs::kCoreNumParams; ++i)
		if (kParamIdOfCore[i] == id)
			return i;
	return -1;
}

// state chunk identifiers
constexpr Steinberg::int32 kProcessorStateMagic = 0x53504853; // 'SPHS'
constexpr Steinberg::int32 kControllerStateMagic = 0x53504843; // 'SPHC'
constexpr Steinberg::int32 kStateVersion = 1;

// message from controller to processor: selected engine mode (for latency reporting)
#define SPHS_MSG_MODE "SphsEngineMode"

} // namespace sphsvst
