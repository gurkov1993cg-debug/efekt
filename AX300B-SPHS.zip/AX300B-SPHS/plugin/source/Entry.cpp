// VST3 factory: one audio effect (processor) + its edit controller.
#include "Controller.h"
#include "Processor.h"
#include "version.h"
#include "public.sdk/source/main/pluginfactory.h"

using namespace Steinberg;
using namespace Steinberg::Vst;

BEGIN_FACTORY_DEF (stringCompanyName, stringCompanyWeb, stringCompanyEmail)

	DEF_CLASS2 (INLINE_UID_FROM_FUID (sphsvst::kProcessorUID),
	            PClassInfo::kManyInstances,
	            kVstAudioEffectClass,
	            stringPluginName,
	            Vst::kDistributable,
	            Vst::PlugType::kFxModulation,
	            FULL_VERSION_STR,
	            kVstVersionString,
	            sphsvst::Processor::createInstance)

	DEF_CLASS2 (INLINE_UID_FROM_FUID (sphsvst::kControllerUID),
	            PClassInfo::kManyInstances,
	            kVstComponentControllerClass,
	            stringPluginName "Controller",
	            0,
	            "",
	            FULL_VERSION_STR,
	            kVstVersionString,
	            sphsvst::Controller::createInstance)

END_FACTORY
