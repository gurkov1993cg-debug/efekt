// VST3 factory: one audio effect (Processor) + its edit controller (Controller).
#include "Controller.h"
#include "Processor.h"
#include "version.h"
#include "public.sdk/source/main/pluginfactory_constexpr.h"

BEGIN_FACTORY_DEF (stringCompanyName, stringCompanyWeb, stringCompanyEmail, 2)

DEF_CLASS (sphsvst::kProcessorUID,
           Steinberg::PClassInfo::kManyInstances,
           kVstAudioEffectClass,
           stringPluginName,
           Steinberg::Vst::kDistributable,
           "Fx|Modulation",
           FULL_VERSION_STR,
           kVstVersionString,
           sphsvst::Processor::createInstance,
           nullptr)

DEF_CLASS (sphsvst::kControllerUID,
           Steinberg::PClassInfo::kManyInstances,
           kVstComponentControllerClass,
           stringPluginName "Controller",
           0,
           "",
           FULL_VERSION_STR,
           kVstVersionString,
           sphsvst::Controller::createInstance,
           nullptr)

END_FACTORY
