// Editor - native Cocoa/AppKit view (Objective-C++ in Editor.mm), attached
// directly through the Steinberg VST3 SDK view interface. No GUI framework.
// Everything visible is drawn by code: no bitmaps, no third-party artwork.
#pragma once
#include "public.sdk/source/vst/vsteditcontroller.h"

namespace sphsvst {

class Controller;

class Editor : public Steinberg::Vst::EditorView
{
public:
	static constexpr int kWidth = 920;
	static constexpr int kHeight = 430;

	explicit Editor (Controller* controller);
	~Editor () override;

	Steinberg::tresult PLUGIN_API isPlatformTypeSupported (Steinberg::FIDString type) SMTG_OVERRIDE;
	Steinberg::tresult PLUGIN_API attached (void* parent, Steinberg::FIDString type) SMTG_OVERRIDE;
	Steinberg::tresult PLUGIN_API removed () SMTG_OVERRIDE;
	Steinberg::tresult PLUGIN_API canResize () SMTG_OVERRIDE { return Steinberg::kResultFalse; }

	/** Redraws with the current controller values. Any thread. */
	void refresh ();

private:
	struct Impl;
	Impl* impl_;
	Controller* ctrl_;
};

} // namespace sphsvst
