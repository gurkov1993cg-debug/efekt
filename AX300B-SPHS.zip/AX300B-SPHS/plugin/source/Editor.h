// Editor - vector-drawn GUI (VSTGUI). No bitmaps, no copied artwork, no
// third-party logos: every element is drawn by the code in Editor.cpp.
#pragma once
#include "public.sdk/source/vst/vstguieditor.h"
#include "vstgui/lib/controls/icontrollistener.h"

namespace sphsvst {

class Controller;
class Knob;
class PushButton;
class Pedal;
class Lcd;

class Editor : public Steinberg::Vst::VSTGUIEditor, public VSTGUI::IControlListener
{
public:
	static constexpr int kWidth = 920;
	static constexpr int kHeight = 430;

	explicit Editor (Controller* controller);

	bool PLUGIN_API open (void* parent, const VSTGUI::PlatformType& platformType) SMTG_OVERRIDE;
	void PLUGIN_API close () SMTG_OVERRIDE;

	// IControlListener
	void valueChanged (VSTGUI::CControl* control) SMTG_OVERRIDE;

	/** Pulls every displayed value from the controller. UI thread only. */
	void refresh ();

private:
	Controller* ctrl_;
	Knob* knobs_[6] = {nullptr, nullptr, nullptr, nullptr, nullptr, nullptr};
	PushButton* bypass_ = nullptr;
	PushButton* mode_ = nullptr;
	PushButton* write_ = nullptr;
	PushButton* pedalParam_ = nullptr;
	PushButton* hold_ = nullptr;
	PushButton* bankDown_ = nullptr;
	PushButton* bankUp_ = nullptr;
	PushButton* progs_[4] = {nullptr, nullptr, nullptr, nullptr};
	Pedal* pedal_ = nullptr;
	Lcd* lcd_ = nullptr;
};

} // namespace sphsvst
