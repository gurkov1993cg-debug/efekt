#pragma once
#include "pluginterfaces/base/fplatform.h"

#define MAJOR_VERSION_STR "0"
#define MAJOR_VERSION_INT 0
#define SUB_VERSION_STR "1"
#define SUB_VERSION_INT 1
#define RELEASE_NUMBER_STR "0"
#define RELEASE_NUMBER_INT 0
#define BUILD_NUMBER_STR "1"
#define BUILD_NUMBER_INT 1

#define FULL_VERSION_STR MAJOR_VERSION_STR "." SUB_VERSION_STR "." RELEASE_NUMBER_STR "." BUILD_NUMBER_STR
#define VERSION_STR MAJOR_VERSION_STR "." SUB_VERSION_STR "." RELEASE_NUMBER_STR

// Plain project strings - change freely, they are not IDs.
#define stringPluginName "SPHS Stereo Phaser"
#define stringOriginalFilename "SPHS-Phaser.vst3"
#define stringFileDescription "SPHS Stereo Phaser (AX300B SPHS model, research build)"
#define stringCompanyName "efekt"
#define stringCompanyWeb "https://github.com/gurkov1993cg-debug/efekt"
#define stringCompanyEmail ""
#define stringLegalCopyright ""
#define stringLegalTrademarks ""
