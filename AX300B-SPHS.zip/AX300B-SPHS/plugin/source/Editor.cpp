#include "Editor.h"
#include "Controller.h"
#include "LinuxRunLoop.h"
#include "sphs/ModelConfig.h"
#include "vstgui/lib/cdrawcontext.h"
#include "vstgui/lib/cfont.h"
#include "vstgui/lib/cframe.h"
#include "vstgui/lib/cgradient.h"
#include "vstgui/lib/cgraphicspath.h"
#include "vstgui/lib/controls/ccontrol.h"
#include "vstgui/lib/cviewcontainer.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <string>

using namespace VSTGUI;
using namespace Steinberg;

namespace sphsvst {

namespace {

enum CommandTags : int32_t
{
	kTagBypass = 1000,
	kTagMode,
	kTagWrite,
	kTagPedalParam,
	kTagHold,
	kTagBankDown,
	kTagBankUp,
	kTagProg1,
	kTagProg2,
	kTagProg3,
	kTagProg4
};

const CColor kBodyTop (52, 56, 64);
const CColor kBodyBottom (22, 24, 29);
const CColor kAccent (0, 168, 150);
const CColor kText (214, 220, 226);
const CColor kTextDim (140, 148, 158);
const CColor kLcdTop (196, 220, 128);
const CColor kLcdBottom (164, 192, 100);
const CColor kLcdInk (26, 38, 18);
const CColor kCapTop (86, 92, 102);
const CColor kCapBottom (40, 43, 50);
const CColor kLedRedOn (255, 72, 48);
const CColor kLedRedOff (74, 30, 26);
const CColor kLedGreenOn (90, 235, 130);
const CColor kLedGreenOff (26, 62, 38);

SharedPointer<CFontDesc> makeFont (const char* name, CCoord size, bool bold = true)
{
	return makeOwned<CFontDesc> (name, size, bold ? kBoldFace : 0);
}

void fillRound (CDrawContext* ctx, const CRect& r, CCoord radius, const CColor& top, const CColor& bottom)
{
	if (auto path = VSTGUI::owned (ctx->createRoundRectGraphicsPath (r, radius)))
	{
		if (auto grad = VSTGUI::owned (CGradient::create (0., 1., top, bottom)))
			ctx->fillLinearGradient (path, *grad, r.getTopLeft (), r.getBottomLeft ());
	}
}

void strokeRound (CDrawContext* ctx, const CRect& r, CCoord radius, const CColor& color, CCoord width = 1.)
{
	if (auto path = VSTGUI::owned (ctx->createRoundRectGraphicsPath (r, radius)))
	{
		ctx->setFrameColor (color);
		ctx->setLineWidth (width);
		ctx->drawGraphicsPath (path, CDrawContext::kPathStroked);
	}
}

void fillEllipse (CDrawContext* ctx, const CRect& r, const CColor& top, const CColor& bottom)
{
	if (auto path = VSTGUI::owned (ctx->createGraphicsPath ()))
	{
		path->addEllipse (r);
		if (auto grad = VSTGUI::owned (CGradient::create (0., 1., top, bottom)))
			ctx->fillLinearGradient (path, *grad, r.getTopLeft (), r.getBottomLeft ());
	}
}

void strokeEllipse (CDrawContext* ctx, const CRect& r, const CColor& color, CCoord width)
{
	if (auto path = VSTGUI::owned (ctx->createGraphicsPath ()))
	{
		path->addEllipse (r);
		ctx->setFrameColor (color);
		ctx->setLineWidth (width);
		ctx->drawGraphicsPath (path, CDrawContext::kPathStroked);
	}
}

void drawLed (CDrawContext* ctx, CPoint c, CCoord radius, const CColor& color)
{
	CRect r (c.x - radius, c.y - radius, c.x + radius, c.y + radius);
	fillEllipse (ctx, r, color, color);
	strokeEllipse (ctx, r, CColor (0, 0, 0, 160), 1.);
}

} // namespace

//------------------------------------------------------------------------
/** Rotary control. Drag up/down, Shift = fine, double-click = default. */
class Knob : public CControl
{
public:
	Knob (const CRect& size, IControlListener* listener, int32_t tag, const char* label, float def)
	: CControl (size, listener, tag), label_ (label), def_ (def)
	{
		setMin (0.f);
		setMax (1.f);
		setDefaultValue (def);
		labelFont_ = makeFont ("Helvetica", 11);
		valueFont_ = makeFont ("Menlo", 11, false);
	}
	void setText (const std::string& text, bool pedalDriven)
	{
		if (text != text_ || pedalDriven != pedal_)
		{
			text_ = text;
			pedal_ = pedalDriven;
			invalid ();
		}
	}
	void draw (CDrawContext* ctx) override
	{
		ctx->setDrawMode (kAntiAliasing | kNonIntegralMode);
		const CRect vs = getViewSize ();
		const CCoord d = std::min (vs.getWidth (), vs.getHeight () - 30.);
		const CPoint c (vs.left + vs.getWidth () * 0.5, vs.top + d * 0.5);
		const CCoord rad = d * 0.5 - 4.;

		// scale ticks
		ctx->setLineWidth (1.5);
		for (int i = 0; i <= 10; ++i)
		{
			const double a = (-135. + 27. * i) * 3.14159265358979 / 180.;
			const bool reached = getValueNormalized () * 10.f + 0.001f >= static_cast<float> (i);
			ctx->setFrameColor (reached ? kAccent : CColor (84, 90, 100));
			ctx->drawLine (CPoint (c.x + std::sin (a) * (rad + 1.), c.y - std::cos (a) * (rad + 1.)),
			               CPoint (c.x + std::sin (a) * (rad + 4.), c.y - std::cos (a) * (rad + 4.)));
		}
		// cap
		const CRect cap (c.x - rad + 3., c.y - rad + 3., c.x + rad - 3., c.y + rad - 3.);
		fillEllipse (ctx, cap, kCapTop, kCapBottom);
		strokeEllipse (ctx, cap, CColor (10, 10, 12), 1.5);
		// pointer
		const double a = (-135. + 270. * getValueNormalized ()) * 3.14159265358979 / 180.;
		ctx->setFrameColor (CColor (245, 245, 245));
		ctx->setLineWidth (2.5);
		ctx->drawLine (CPoint (c.x + std::sin (a) * (rad * 0.30), c.y - std::cos (a) * (rad * 0.30)),
		               CPoint (c.x + std::sin (a) * (rad - 6.), c.y - std::cos (a) * (rad - 6.)));

		// label + value
		CRect lr (vs.left, vs.top + d, vs.right, vs.top + d + 14.);
		ctx->setFont (labelFont_);
		ctx->setFontColor (kText);
		ctx->drawString (label_.c_str (), lr, kCenterText);
		CRect vr (vs.left, vs.top + d + 14., vs.right, vs.top + d + 28.);
		ctx->setFont (valueFont_);
		ctx->setFontColor (pedal_ ? kAccent : kTextDim);
		ctx->drawString (text_.c_str (), vr, kCenterText);
		setDirty (false);
	}
	CMouseEventResult onMouseDown (CPoint& where, const CButtonState& buttons) override
	{
		if (!buttons.isLeftButton ())
			return kMouseEventNotHandled;
		if (buttons.isDoubleClick ())
		{
			beginEdit ();
			setValueNormalized (def_);
			valueChanged ();
			endEdit ();
			invalid ();
			return kMouseDownEventHandledButDontNeedMovedOrUpEvents;
		}
		beginEdit ();
		dragging_ = true;
		startY_ = where.y;
		startValue_ = getValueNormalized ();
		return kMouseEventHandled;
	}
	CMouseEventResult onMouseMoved (CPoint& where, const CButtonState& buttons) override
	{
		if (!dragging_)
			return kMouseEventNotHandled;
		const double range = buttons.isShiftSet () ? 1200. : 170.;
		const double v = startValue_ + (startY_ - where.y) / range;
		setValueNormalized (static_cast<float> (std::max (0., std::min (1., v))));
		valueChanged ();
		invalid ();
		return kMouseEventHandled;
	}
	CMouseEventResult onMouseUp (CPoint&, const CButtonState&) override { return finish (); }
	CMouseEventResult onMouseCancel () override { return finish (); }
	CLASS_METHODS_NOCOPY (Knob, CControl)
private:
	CMouseEventResult finish ()
	{
		if (dragging_)
		{
			dragging_ = false;
			endEdit ();
		}
		return kMouseEventHandled;
	}
	std::string label_, text_;
	float def_;
	bool pedal_ = false;
	bool dragging_ = false;
	CCoord startY_ = 0.;
	double startValue_ = 0.;
	SharedPointer<CFontDesc> labelFont_, valueFont_;
};

//------------------------------------------------------------------------
/** Momentary button. Style: panel key (rounded rectangle) or foot switch. */
class PushButton : public CControl
{
public:
	enum Style { kKey, kFoot };
	PushButton (const CRect& size, IControlListener* listener, int32_t tag, const char* label, Style style,
	            bool greenLed = false)
	: CControl (size, listener, tag), label_ (label), style_ (style), green_ (greenLed)
	{
		font_ = makeFont ("Helvetica", 11);
	}
	void setState (bool lit, const std::string& label)
	{
		if (lit != lit_ || label != label_)
		{
			lit_ = lit;
			label_ = label;
			invalid ();
		}
	}
	void draw (CDrawContext* ctx) override
	{
		ctx->setDrawMode (kAntiAliasing | kNonIntegralMode);
		const CRect vs = getViewSize ();
		const CColor ledOn = green_ ? kLedGreenOn : kLedRedOn;
		const CColor ledOff = green_ ? kLedGreenOff : kLedRedOff;
		if (style_ == kFoot)
		{
			const CCoord d = std::min (vs.getWidth (), vs.getHeight () - 40.);
			const CPoint c (vs.left + vs.getWidth () * 0.5, vs.top + 20. + d * 0.5);
			drawLed (ctx, CPoint (c.x, vs.top + 8.), 5., lit_ ? ledOn : ledOff);
			CRect outer (c.x - d * 0.5, c.y - d * 0.5, c.x + d * 0.5, c.y + d * 0.5);
			fillEllipse (ctx, outer, CColor (150, 156, 166), CColor (58, 62, 70));
			CRect inner = outer;
			inner.inset (pressed_ ? 9. : 7., pressed_ ? 9. : 7.);
			fillEllipse (ctx, inner, pressed_ ? CColor (70, 74, 82) : CColor (200, 205, 212),
			             pressed_ ? CColor (120, 126, 134) : CColor (96, 102, 112));
			strokeEllipse (ctx, outer, CColor (8, 8, 10), 1.5);
			CRect lr (vs.left, vs.bottom - 18., vs.right, vs.bottom - 2.);
			ctx->setFont (font_);
			ctx->setFontColor (kText);
			ctx->drawString (label_.c_str (), lr, kCenterText);
		}
		else
		{
			CRect r = vs;
			r.inset (1., 1.);
			if (pressed_)
				fillRound (ctx, r, 6., CColor (30, 33, 38), CColor (58, 62, 70));
			else
				fillRound (ctx, r, 6., CColor (88, 94, 104), CColor (44, 47, 54));
			strokeRound (ctx, r, 6., CColor (8, 8, 10), 1.5);
			drawLed (ctx, CPoint (r.left + 12., r.top + r.getHeight () * 0.5), 4., lit_ ? ledOn : ledOff);
			CRect tr (r.left + 22., r.top, r.right - 4., r.bottom);
			ctx->setFont (font_);
			ctx->setFontColor (kText);
			ctx->drawString (label_.c_str (), tr, kCenterText);
		}
		setDirty (false);
	}
	CMouseEventResult onMouseDown (CPoint&, const CButtonState& buttons) override
	{
		if (!buttons.isLeftButton ())
			return kMouseEventNotHandled;
		pressed_ = true;
		invalid ();
		return kMouseEventHandled;
	}
	CMouseEventResult onMouseUp (CPoint& where, const CButtonState&) override
	{
		if (pressed_)
		{
			pressed_ = false;
			invalid ();
			if (getViewSize ().pointInside (where) && listener)
				listener->valueChanged (this);
		}
		return kMouseEventHandled;
	}
	CMouseEventResult onMouseCancel () override
	{
		pressed_ = false;
		invalid ();
		return kMouseEventHandled;
	}
	CLASS_METHODS_NOCOPY (PushButton, CControl)
private:
	std::string label_;
	Style style_;
	bool green_;
	bool lit_ = false;
	bool pressed_ = false;
	SharedPointer<CFontDesc> font_;
};

//------------------------------------------------------------------------
/** Pressure pedal. Press and move: top = fully pressed. Releasing returns it
    to the rest position unless HOLD is on (like an external expression pedal). */
class Pedal : public CControl
{
public:
	Pedal (const CRect& size, IControlListener* listener, int32_t tag) : CControl (size, listener, tag)
	{
		setMin (0.f);
		setMax (1.f);
		font_ = makeFont ("Helvetica", 11);
	}
	void setHold (bool hold) { hold_ = hold; }
	void setActive (bool active)
	{
		if (active != active_)
		{
			active_ = active;
			invalid ();
		}
	}
	void draw (CDrawContext* ctx) override
	{
		ctx->setDrawMode (kAntiAliasing | kNonIntegralMode);
		CRect r = getViewSize ();
		r.inset (2., 2.);
		fillRound (ctx, r, 10., CColor (70, 75, 84), CColor (30, 32, 38));
		strokeRound (ctx, r, 10., CColor (8, 8, 10), 2.);
		// tread
		CRect pad = r;
		pad.inset (10., 26.);
		const float v = getValueNormalized ();
		ctx->setLineWidth (3.);
		for (int i = 0; i < 14; ++i)
		{
			const CCoord y = pad.top + (pad.getHeight () * (i + 0.5)) / 14.;
			const bool on = (1. - (i + 0.5) / 14.) <= v;
			ctx->setFrameColor (on ? (active_ ? kAccent : CColor (150, 156, 166)) : CColor (14, 15, 18));
			ctx->drawLine (CPoint (pad.left, y), CPoint (pad.right, y));
		}
		char text[32];
		std::snprintf (text, sizeof (text), "%d %%", static_cast<int> (v * 100.f + 0.5f));
		ctx->setFont (font_);
		ctx->setFontColor (kText);
		ctx->drawString ("PRESSURE", CRect (r.left, r.top + 5., r.right, r.top + 21.), kCenterText);
		ctx->setFontColor (active_ ? kAccent : kTextDim);
		ctx->drawString (text, CRect (r.left, r.bottom - 21., r.right, r.bottom - 5.), kCenterText);
		setDirty (false);
	}
	CMouseEventResult onMouseDown (CPoint& where, const CButtonState& buttons) override
	{
		if (!buttons.isLeftButton ())
			return kMouseEventNotHandled;
		beginEdit ();
		dragging_ = true;
		follow (where);
		return kMouseEventHandled;
	}
	CMouseEventResult onMouseMoved (CPoint& where, const CButtonState&) override
	{
		if (!dragging_)
			return kMouseEventNotHandled;
		follow (where);
		return kMouseEventHandled;
	}
	CMouseEventResult onMouseUp (CPoint&, const CButtonState&) override { return finish (); }
	CMouseEventResult onMouseCancel () override { return finish (); }
	CLASS_METHODS_NOCOPY (Pedal, CControl)
private:
	void follow (const CPoint& where)
	{
		CRect pad = getViewSize ();
		pad.inset (12., 28.);
		const double v = 1. - (where.y - pad.top) / std::max<CCoord> (1., pad.getHeight ());
		setValueNormalized (static_cast<float> (std::max (0., std::min (1., v))));
		valueChanged ();
		invalid ();
	}
	CMouseEventResult finish ()
	{
		if (dragging_)
		{
			dragging_ = false;
			if (!hold_)
			{
				setValueNormalized (0.f); // pressure released
				valueChanged ();
				invalid ();
			}
			endEdit ();
		}
		return kMouseEventHandled;
	}
	bool dragging_ = false;
	bool hold_ = false;
	bool active_ = false;
	SharedPointer<CFontDesc> font_;
};

//------------------------------------------------------------------------
class Lcd : public CView
{
public:
	explicit Lcd (const CRect& size) : CView (size)
	{
		big_ = makeFont ("Menlo", 19);
		small_ = makeFont ("Menlo", 12);
		setMouseEnabled (false);
	}
	void setLines (const std::string& a, const std::string& b, const std::string& c)
	{
		if (a != line_[0] || b != line_[1] || c != line_[2])
		{
			line_[0] = a;
			line_[1] = b;
			line_[2] = c;
			invalid ();
		}
	}
	void draw (CDrawContext* ctx) override
	{
		ctx->setDrawMode (kAntiAliasing | kNonIntegralMode);
		CRect r = getViewSize ();
		fillRound (ctx, r, 6., CColor (10, 11, 13), CColor (10, 11, 13));
		r.inset (6., 6.);
		fillRound (ctx, r, 3., kLcdTop, kLcdBottom);
		ctx->setFontColor (kLcdInk);
		ctx->setFont (small_);
		ctx->drawString (line_[0].c_str (), CRect (r.left + 10., r.top + 6., r.right - 10., r.top + 24.), kLeftText);
		ctx->setFont (big_);
		ctx->drawString (line_[1].c_str (), CRect (r.left + 10., r.top + 28., r.right - 10., r.top + 56.), kLeftText);
		ctx->setFont (small_);
		ctx->drawString (line_[2].c_str (), CRect (r.left + 10., r.bottom - 26., r.right - 10., r.bottom - 8.), kLeftText);
		setDirty (false);
	}
	CLASS_METHODS_NOCOPY (Lcd, CView)
private:
	std::string line_[3];
	SharedPointer<CFontDesc> big_, small_;
};

//------------------------------------------------------------------------
/** Enclosure artwork (original design, drawn in code). */
class Panel : public CViewContainer
{
public:
	explicit Panel (const CRect& size) : CViewContainer (size)
	{
		title_ = makeFont ("Helvetica", 15);
		small_ = makeFont ("Helvetica", 10);
		model_ = std::string ("MODEL: ") + sphs::defaultModel ().name +
		         (sphs::defaultModel ().fittedToHardware ? "  (fitted to hardware)" : "  (NOT fitted to hardware)");
	}
	void drawBackgroundRect (CDrawContext* ctx, const CRect&) override
	{
		ctx->setDrawMode (kAntiAliasing | kNonIntegralMode);
		CRect r (0., 0., getViewSize ().getWidth (), getViewSize ().getHeight ());
		ctx->setFillColor (CColor (12, 13, 15));
		ctx->drawRect (r, kDrawFilled);
		CRect body = r;
		body.inset (4., 4.);
		fillRound (ctx, body, 14., kBodyTop, kBodyBottom);
		strokeRound (ctx, body, 14., CColor (96, 102, 112), 1.5);

		// accent line and title
		ctx->setFillColor (kAccent);
		ctx->drawRect (CRect (24., 36., 770., 38.), kDrawFilled);
		ctx->setFont (title_);
		ctx->setFontColor (kText);
		ctx->drawString ("SPHS  STEREO PHASER", CRect (24., 12., 400., 34.), kLeftText);
		ctx->setFont (small_);
		ctx->setFontColor (kTextDim);
		ctx->drawString (model_.c_str (), CRect (400., 14., 770., 34.), kRightText);

		// section frames
		strokeRound (ctx, CRect (404., 46., 770., 158.), 8., CColor (72, 78, 88));
		strokeRound (ctx, CRect (404., 168., 770., 252.), 8., CColor (72, 78, 88));
		strokeRound (ctx, CRect (24., 168., 394., 252.), 8., CColor (72, 78, 88));
		ctx->setFontColor (kTextDim);
		ctx->drawString ("PEDAL ASSIGN", CRect (414., 170., 600., 184.), kLeftText);
		ctx->drawString ("PROGRAM", CRect (34., 170., 200., 184.), kLeftText);

		// foot-switch deck
		CRect deck (24., 264., 770., 410.);
		fillRound (ctx, deck, 10., CColor (30, 32, 38), CColor (18, 19, 23));
		strokeRound (ctx, deck, 10., CColor (72, 78, 88));
	}
	CLASS_METHODS_NOCOPY (Panel, CViewContainer)
private:
	SharedPointer<CFontDesc> title_, small_;
	std::string model_;
};

//------------------------------------------------------------------------
Editor::Editor (Controller* controller) : VSTGUIEditor (controller), ctrl_ (controller)
{
	Steinberg::ViewRect size (0, 0, kWidth, kHeight);
	setRect (size);
}

bool PLUGIN_API Editor::open (void* parent, const PlatformType& platformType)
{
	const CRect size (0., 0., kWidth, kHeight);
	frame = new CFrame (size, this);
	auto* panel = new Panel (size);
	frame->addView (panel);

	lcd_ = new Lcd (CRect (24., 46., 394., 158.));
	panel->addView (lcd_);

	// the four original SPHS parameters
	const struct { Vst::ParamID id; const char* label; } kMain[4] = {
	    {kParamSpeed, "SPEED"}, {kParamDepth, "DEPTH"}, {kParamManual, "MANUAL"}, {kParamResonance, "RESONANCE"}};
	for (int i = 0; i < 4; ++i)
	{
		const CCoord x = 412. + 88. * i;
		const float def = static_cast<float> (sphs::coreParamDefault (coreIndexOfParam (kMain[i].id)));
		knobs_[i] = new Knob (CRect (x, 54., x + 86., 54. + 94.), this, static_cast<int32_t> (kMain[i].id), kMain[i].label, def);
		panel->addView (knobs_[i]);
	}

	// program / global keys
	bypass_ = new PushButton (CRect (34., 190., 144., 226.), this, kTagBypass, "BYPASS", PushButton::kKey);
	mode_ = new PushButton (CRect (154., 190., 274., 226.), this, kTagMode, "NATIVE", PushButton::kKey, true);
	write_ = new PushButton (CRect (284., 190., 384., 226.), this, kTagWrite, "WRITE", PushButton::kKey);
	panel->addView (bypass_);
	panel->addView (mode_);
	panel->addView (write_);

	// pedal assignment: PARAM, MIN, MAX (+ HOLD for the mouse)
	pedalParam_ = new PushButton (CRect (412., 196., 540., 232.), this, kTagPedalParam, "PARAM: OFF", PushButton::kKey, true);
	panel->addView (pedalParam_);
	knobs_[4] = new Knob (CRect (542., 176., 610., 246.), this, static_cast<int32_t> (kParamPedalMin), "MIN", 0.f);
	knobs_[5] = new Knob (CRect (614., 176., 682., 246.), this, static_cast<int32_t> (kParamPedalMax), "MAX", 1.f);
	panel->addView (knobs_[4]);
	panel->addView (knobs_[5]);
	hold_ = new PushButton (CRect (690., 196., 762., 232.), this, kTagHold, "HOLD", PushButton::kKey, true);
	panel->addView (hold_);

	// foot switches
	bankDown_ = new PushButton (CRect (44., 276., 134., 402.), this, kTagBankDown, "BANK DOWN", PushButton::kFoot, true);
	bankUp_ = new PushButton (CRect (154., 276., 244., 402.), this, kTagBankUp, "BANK UP", PushButton::kFoot, true);
	panel->addView (bankDown_);
	panel->addView (bankUp_);
	const char* kProgLabels[4] = {"1", "2", "3", "4"};
	for (int i = 0; i < 4; ++i)
	{
		const CCoord x = 304. + 116. * i;
		progs_[i] = new PushButton (CRect (x, 276., x + 90., 402.), this, kTagProg1 + i, kProgLabels[i], PushButton::kFoot);
		panel->addView (progs_[i]);
	}

	pedal_ = new Pedal (CRect (790., 20., 900., 410.), this, static_cast<int32_t> (kParamPedalPos));
	panel->addView (pedal_);

	refresh ();
	IPlatformFrameConfig* config = nullptr;
#if SMTG_OS_LINUX
	X11::FrameConfig x11config;
	x11config.runLoop = VSTGUI::owned (new LinuxRunLoop (plugFrame));
	config = &x11config;
#endif
	if (!frame->open (parent, platformType, config))
	{
		close ();
		return false;
	}
	return true;
}

void PLUGIN_API Editor::close ()
{
	for (Knob*& k : knobs_)
		k = nullptr;
	for (PushButton*& p : progs_)
		p = nullptr;
	bypass_ = mode_ = write_ = pedalParam_ = hold_ = bankDown_ = bankUp_ = nullptr;
	pedal_ = nullptr;
	lcd_ = nullptr;
	if (frame)
	{
		frame->removeAll (true);
		if (frame->getNbReference () == 1)
			frame->close ();
		else
			frame->forget ();
		frame = nullptr;
	}
}

//------------------------------------------------------------------------
void Editor::valueChanged (CControl* control)
{
	if (!ctrl_ || !control)
		return;
	const int32_t tag = control->getTag ();
	if (tag < 1000)
	{
		// a parameter control (knob / pedal); begin and end come from the control
		const auto id = static_cast<Vst::ParamID> (tag);
		if (id != kParamPedalPos)
			ctrl_->setSelectedParam (static_cast<int> (id));
		ctrl_->dragParam (id, control->getValueNormalized ());
		return;
	}
	switch (tag)
	{
		case kTagBypass: ctrl_->editParam (kParamBypass, ctrl_->norm (kParamBypass) > 0.5 ? 0. : 1.); break;
		case kTagMode: ctrl_->editParam (kParamEngineMode, ctrl_->norm (kParamEngineMode) > 0.5 ? 0. : 1.); break;
		case kTagWrite: ctrl_->writeProgram (); break;
		case kTagPedalParam:
		{
			const int next = (static_cast<int> (ctrl_->pedalTarget ()) + 1) % sphs::kNumPedalTargets;
			ctrl_->editParam (kParamPedalTarget, sphs::pedalTargetToNorm (static_cast<sphs::PedalTarget> (next)));
			break;
		}
		case kTagHold:
			ctrl_->setHold (!ctrl_->hold ());
			if (!ctrl_->hold ())
				ctrl_->editParam (kParamPedalPos, 0.); // pedal springs back
			break;
		case kTagBankDown: ctrl_->selectProgram (ctrl_->bank () - 1, ctrl_->program ()); break;
		case kTagBankUp: ctrl_->selectProgram (ctrl_->bank () + 1, ctrl_->program ()); break;
		case kTagProg1:
		case kTagProg2:
		case kTagProg3:
		case kTagProg4: ctrl_->selectProgram (ctrl_->bank (), tag - kTagProg1); break;
		default: break;
	}
	refresh ();
}

//------------------------------------------------------------------------
void Editor::refresh ()
{
	if (!ctrl_ || !lcd_)
		return;
	static const char* kTargetNames[sphs::kNumPedalTargets] = {"OFF", "SPEED", "DEPTH", "MANUAL", "RESONANCE"};
	const sphs::PedalTarget target = ctrl_->pedalTarget ();
	const int targetIndex = static_cast<int> (target);
	const sphs::UserParams eff = ctrl_->effective ();
	const bool bypassed = ctrl_->norm (kParamBypass) > 0.5;
	const bool reference = ctrl_->norm (kParamEngineMode) > 0.5;
	char text[96];

	// knobs: stored value on the knob, value in use (pedal applied) as text
	const Vst::ParamID ids[6] = {kParamSpeed, kParamDepth, kParamManual, kParamResonance, kParamPedalMin, kParamPedalMax};
	const double effValue[4] = {eff.speedHz, eff.depth, eff.manual, eff.resonance};
	for (int i = 0; i < 6; ++i)
	{
		if (!knobs_[i])
			continue;
		const double n = ctrl_->norm (ids[i]);
		if (std::fabs (knobs_[i]->getValueNormalized () - static_cast<float> (n)) > 1e-6f)
		{
			knobs_[i]->setValueNormalized (static_cast<float> (n));
			knobs_[i]->invalid ();
		}
		if (i == 0)
			std::snprintf (text, sizeof (text), "%.2f Hz", effValue[0]);
		else if (i == 3)
			std::snprintf (text, sizeof (text), "%+.1f", effValue[3]);
		else if (i < 4)
			std::snprintf (text, sizeof (text), "%.1f", effValue[i]);
		else if (target == sphs::PedalTarget::Off)
			std::snprintf (text, sizeof (text), "%.0f %%", n * 100.);
		else if (target == sphs::PedalTarget::Speed)
			std::snprintf (text, sizeof (text), "%.2f Hz", sphs::targetPlainFromNorm (target, n));
		else
			std::snprintf (text, sizeof (text), "%.1f", sphs::targetPlainFromNorm (target, n));
		knobs_[i]->setText (text, i < 4 && targetIndex == i + 1);
	}

	if (pedal_)
	{
		const float pos = static_cast<float> (ctrl_->norm (kParamPedalPos));
		if (std::fabs (pedal_->getValueNormalized () - pos) > 1e-6f)
		{
			pedal_->setValueNormalized (pos);
			pedal_->invalid ();
		}
		pedal_->setHold (ctrl_->hold ());
		pedal_->setActive (target != sphs::PedalTarget::Off);
	}

	if (bypass_)
		bypass_->setState (bypassed, "BYPASS");
	if (mode_)
		mode_->setState (reference, reference ? "REF 39 kHz" : "NATIVE");
	if (write_)
		write_->setState (ctrl_->programEdited (), "WRITE");
	if (pedalParam_)
	{
		std::snprintf (text, sizeof (text), "PARAM: %s", targetIndex == 4 ? "RESO" : kTargetNames[targetIndex]);
		pedalParam_->setState (target != sphs::PedalTarget::Off, text);
	}
	if (hold_)
		hold_->setState (ctrl_->hold (), "HOLD");
	if (bankDown_)
		bankDown_->setState (false, "BANK DOWN");
	if (bankUp_)
		bankUp_->setState (false, "BANK UP");
	for (int i = 0; i < 4; ++i)
		if (progs_[i])
		{
			const char label[2] = {static_cast<char> ('1' + i), 0};
			progs_[i]->setState (ctrl_->program () == i, label);
		}

	// LCD
	std::string l1, l2, l3;
	std::snprintf (text, sizeof (text), "BANK %d  PROG %d%s   %s", ctrl_->bank () + 1, ctrl_->program () + 1,
	               ctrl_->programEdited () ? " *" : "", bypassed ? "BYPASS" : (reference ? "REF 39.0625k" : "NATIVE"));
	l1 = text;
	const int sel = ctrl_->selectedParam ();
	switch (sel)
	{
		case kParamDepth: std::snprintf (text, sizeof (text), "DEPTH   %5.1f", eff.depth); break;
		case kParamManual: std::snprintf (text, sizeof (text), "MANUAL  %5.1f", eff.manual); break;
		case kParamResonance: std::snprintf (text, sizeof (text), "RESO   %+6.1f", eff.resonance); break;
		case kParamPedalMin:
		case kParamPedalMax:
		{
			const double n = ctrl_->norm (static_cast<Vst::ParamID> (sel));
			const char* name = sel == kParamPedalMin ? "MIN" : "MAX";
			if (target == sphs::PedalTarget::Off)
				std::snprintf (text, sizeof (text), "PEDAL %s %3.0f%%", name, n * 100.);
			else
				std::snprintf (text, sizeof (text), "PEDAL %s %.2f", name, sphs::targetPlainFromNorm (target, n));
			break;
		}
		case kParamSpeed:
		default: std::snprintf (text, sizeof (text), "SPEED %5.2f Hz", eff.speedHz); break;
	}
	l2 = text;
	if (target == sphs::PedalTarget::Off)
		l3 = "PEDAL > OFF";
	else
	{
		std::snprintf (text, sizeof (text), "PEDAL > %s  %.2f..%.2f  %3.0f%%", kTargetNames[targetIndex],
		               sphs::targetPlainFromNorm (target, ctrl_->norm (kParamPedalMin)),
		               sphs::targetPlainFromNorm (target, ctrl_->norm (kParamPedalMax)),
		               ctrl_->norm (kParamPedalPos) * 100.);
		l3 = text;
	}
	lcd_->setLines (l1, l2, l3);
}

} // namespace sphsvst
