// Used only on platforms without the Cocoa editor (Linux development builds).
// The controller never creates an Editor there; these bodies satisfy the linker.
#include "Editor.h"

namespace sphsvst {

struct Editor::Impl {};

Editor::Editor (Controller* controller)
: EditorView (reinterpret_cast<Steinberg::Vst::EditController*> (controller)), impl_ (nullptr), ctrl_ (controller)
{
}
Editor::~Editor () {}
Steinberg::tresult PLUGIN_API Editor::isPlatformTypeSupported (Steinberg::FIDString) { return Steinberg::kResultFalse; }
Steinberg::tresult PLUGIN_API Editor::attached (void*, Steinberg::FIDString) { return Steinberg::kResultFalse; }
Steinberg::tresult PLUGIN_API Editor::removed () { return Steinberg::kResultFalse; }
void Editor::refresh () {}

} // namespace sphsvst
