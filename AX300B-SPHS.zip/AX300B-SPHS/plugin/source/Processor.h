#pragma once
#include "Ids.h"
#include "public.sdk/source/vst/vstaudioeffect.h"
#include <atomic>

namespace sphsvst {

class Processor : public Steinberg::Vst::AudioEffect
{
public:
	Processor ();
	static Steinberg::FUnknown* createInstance (void*)
	{
		return static_cast<Steinberg::Vst::IAudioProcessor*> (new Processor ());
	}

	Steinberg::tresult PLUGIN_API initialize (Steinberg::FUnknown* context) SMTG_OVERRIDE;
	Steinberg::tresult PLUGIN_API setBusArrangements (Steinberg::Vst::SpeakerArrangement* inputs,
	                                                  Steinberg::int32 numIns,
	                                                  Steinberg::Vst::SpeakerArrangement* outputs,
	                                                  Steinberg::int32 numOuts) SMTG_OVERRIDE;
	Steinberg::tresult PLUGIN_API canProcessSampleSize (Steinberg::int32 symbolicSampleSize) SMTG_OVERRIDE;
	Steinberg::tresult PLUGIN_API setupProcessing (Steinberg::Vst::ProcessSetup& setup) SMTG_OVERRIDE;
	Steinberg::tresult PLUGIN_API setActive (Steinberg::TBool state) SMTG_OVERRIDE;
	Steinberg::tresult PLUGIN_API process (Steinberg::Vst::ProcessData& data) SMTG_OVERRIDE;
	Steinberg::tresult PLUGIN_API setState (Steinberg::IBStream* state) SMTG_OVERRIDE;
	Steinberg::tresult PLUGIN_API getState (Steinberg::IBStream* state) SMTG_OVERRIDE;
	Steinberg::uint32 PLUGIN_API getLatencySamples () SMTG_OVERRIDE;
	Steinberg::uint32 PLUGIN_API getTailSamples () SMTG_OVERRIDE;
	Steinberg::tresult PLUGIN_API notify (Steinberg::Vst::IMessage* message) SMTG_OVERRIDE;

private:
	static constexpr int kMaxEvents = 4096;

	sphs::PluginCore core_;
	sphs::CoreEvent events_[kMaxEvents];
	float scratch_[1024];

	// Authoritative copy of the parameter values for getState/setState. The
	// audio thread publishes changes here; setState hands new values to the
	// audio thread through the dirty flag. No locks anywhere.
	std::atomic<double> shadow_[sphs::kCoreNumParams];
	std::atomic<bool> stateDirty_ {false};
	std::atomic<int> latencyMode_ {0};
	std::atomic<int> referenceLatency_ {0};
};

} // namespace sphsvst
