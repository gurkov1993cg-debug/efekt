#include "Controller.h"
#include "Editor.h"
#include "base/source/fstreamer.h"
#include "pluginterfaces/base/ibstream.h"
#include "pluginterfaces/base/ustring.h"
#include "pluginterfaces/vst/ivstmessage.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>

using namespace Steinberg;
using namespace Steinberg::Vst;

namespace sphsvst {

namespace {

void toString128 (const char* text, String128 out)
{
	UString (out, 128).fromAscii (text);
}

bool parseNumber (const TChar* string, double& value)
{
	char ascii[64];
	UString (const_cast<TChar*> (string), 128).toAscii (ascii, sizeof (ascii));
	char* end = nullptr;
	value = std::strtod (ascii, &end);
	return end != ascii;
}

//------------------------------------------------------------------------
/** Speed: 0.02 .. 9.5 Hz on a logarithmic control scale. */
class SpeedParameter : public Parameter
{
public:
	SpeedParameter ()
	{
		UString (info.title, 128).fromAscii ("Speed");
		UString (info.shortTitle, 128).fromAscii ("Speed");
		UString (info.units, 128).fromAscii ("Hz");
		info.id = kParamSpeed;
		info.stepCount = 0;
		info.defaultNormalizedValue = sphs::coreParamDefault (sphs::kCoreSpeed);
		info.flags = ParameterInfo::kCanAutomate;
		info.unitId = kRootUnitId;
		setNormalized (info.defaultNormalizedValue);
	}
	void toString (ParamValue n, String128 string) const SMTG_OVERRIDE
	{
		char text[32];
		std::snprintf (text, sizeof (text), "%.2f", sphs::speedFromNorm (n));
		toString128 (text, string);
	}
	bool fromString (const TChar* string, ParamValue& n) const SMTG_OVERRIDE
	{
		double hz;
		if (!parseNumber (string, hz))
			return false;
		n = sphs::speedToNorm (hz);
		return true;
	}
	ParamValue toPlain (ParamValue n) const SMTG_OVERRIDE { return sphs::speedFromNorm (n); }
	ParamValue toNormalized (ParamValue plain) const SMTG_OVERRIDE { return sphs::speedToNorm (plain); }
	OBJ_METHODS (SpeedParameter, Parameter)
};

//------------------------------------------------------------------------
/** Pedal MIN / MAX: shown in the units of the parameter the pedal controls. */
class PedalLimitParameter : public Parameter
{
public:
	PedalLimitParameter (Controller* owner, const char* title, ParamID id, double def) : owner_ (owner)
	{
		UString (info.title, 128).fromAscii (title);
		UString (info.shortTitle, 128).fromAscii (title);
		info.id = id;
		info.stepCount = 0;
		info.defaultNormalizedValue = def;
		info.flags = ParameterInfo::kCanAutomate;
		info.unitId = kRootUnitId;
		setNormalized (def);
	}
	void toString (ParamValue n, String128 string) const SMTG_OVERRIDE
	{
		char text[32];
		const sphs::PedalTarget t = owner_->pedalTarget ();
		if (t == sphs::PedalTarget::Off)
			std::snprintf (text, sizeof (text), "%.0f %%", n * 100.);
		else if (t == sphs::PedalTarget::Speed)
			std::snprintf (text, sizeof (text), "%.2f Hz", sphs::targetPlainFromNorm (t, n));
		else
			std::snprintf (text, sizeof (text), "%.1f", sphs::targetPlainFromNorm (t, n));
		toString128 (text, string);
	}
	OBJ_METHODS (PedalLimitParameter, Parameter)
private:
	Controller* owner_;
};

} // namespace

//------------------------------------------------------------------------
tresult PLUGIN_API Controller::initialize (FUnknown* context)
{
	const tresult result = EditController::initialize (context);
	if (result != kResultOk)
		return result;

	for (int p = 0; p < kNumPrograms; ++p)
		for (int i = 0; i < kProgramParams; ++i)
			programs_[p][i] = sphs::coreParamDefault (coreIndexOfParam (kProgramParamIds[i]));

	parameters.addParameter (STR16 ("Bypass"), nullptr, 1, 0., ParameterInfo::kCanAutomate | ParameterInfo::kIsBypass,
	                         kParamBypass);

	parameters.addParameter (new SpeedParameter ());

	auto* depth = new RangeParameter (STR16 ("Depth"), kParamDepth, nullptr, sphs::kDepthMin, sphs::kDepthMax, 25.);
	depth->setPrecision (1);
	parameters.addParameter (depth);

	auto* manual = new RangeParameter (STR16 ("Manual"), kParamManual, nullptr, sphs::kManualMin, sphs::kManualMax, 25.);
	manual->setPrecision (1);
	parameters.addParameter (manual);

	auto* reso = new RangeParameter (STR16 ("Resonance"), kParamResonance, nullptr, sphs::kResonanceMin,
	                                 sphs::kResonanceMax, 0.);
	reso->setPrecision (1);
	parameters.addParameter (reso);

	auto* target = new StringListParameter (STR16 ("Pedal Param"), kParamPedalTarget, nullptr,
	                                        ParameterInfo::kCanAutomate | ParameterInfo::kIsList);
	target->appendString (STR16 ("Off"));
	target->appendString (STR16 ("Speed"));
	target->appendString (STR16 ("Depth"));
	target->appendString (STR16 ("Manual"));
	target->appendString (STR16 ("Resonance"));
	parameters.addParameter (target);

	parameters.addParameter (new PedalLimitParameter (this, "Pedal Min", kParamPedalMin, 0.));
	parameters.addParameter (new PedalLimitParameter (this, "Pedal Max", kParamPedalMax, 1.));

	auto* pedal = new RangeParameter (STR16 ("Pedal"), kParamPedalPos, STR16 ("%"), 0., 100., 0.);
	pedal->setPrecision (0);
	parameters.addParameter (pedal);

	// not automatable: switching changes the plug-in latency
	auto* mode = new StringListParameter (STR16 ("Engine"), kParamEngineMode, nullptr, ParameterInfo::kIsList);
	mode->appendString (STR16 ("Native"));
	mode->appendString (STR16 ("Reference 39.0625 kHz"));
	parameters.addParameter (mode);

	return kResultOk;
}

//------------------------------------------------------------------------
tresult PLUGIN_API Controller::setComponentState (IBStream* state)
{
	if (!state)
		return kResultFalse;
	IBStreamer s (state, kLittleEndian);
	int32 magic = 0, version = 0, count = 0;
	if (!s.readInt32 (magic) || magic != kProcessorStateMagic)
		return kResultFalse;
	if (!s.readInt32 (version) || !s.readInt32 (count) || count < 0 || count > 64)
		return kResultFalse;
	for (int32 i = 0; i < count; ++i)
	{
		double v = 0.;
		if (!s.readDouble (v))
			return kResultFalse;
		if (i < sphs::kCoreNumParams)
			EditController::setParamNormalized (kParamIdOfCore[i], sphs::clamp01 (v));
	}
	announceMode (true);
	if (editor_)
		editor_->refresh ();
	return kResultOk;
}

tresult PLUGIN_API Controller::getState (IBStream* state)
{
	if (!state)
		return kResultFalse;
	IBStreamer s (state, kLittleEndian);
	s.writeInt32 (kControllerStateMagic);
	s.writeInt32 (kStateVersion);
	s.writeInt32 (bank_);
	s.writeInt32 (program_);
	s.writeInt32 (hold_ ? 1 : 0);
	s.writeInt32 (selected_);
	s.writeInt32 (kNumPrograms);
	s.writeInt32 (kProgramParams);
	for (int p = 0; p < kNumPrograms; ++p)
		for (int i = 0; i < kProgramParams; ++i)
			s.writeDouble (programs_[p][i]);
	return kResultOk;
}

tresult PLUGIN_API Controller::setState (IBStream* state)
{
	if (!state)
		return kResultFalse;
	IBStreamer s (state, kLittleEndian);
	int32 magic = 0, version = 0, bank = 0, program = 0, hold = 0, selected = 0, numPrograms = 0, numParams = 0;
	if (!s.readInt32 (magic) || magic != kControllerStateMagic)
		return kResultFalse;
	if (!s.readInt32 (version) || !s.readInt32 (bank) || !s.readInt32 (program) || !s.readInt32 (hold) ||
	    !s.readInt32 (selected) || !s.readInt32 (numPrograms) || !s.readInt32 (numParams))
		return kResultFalse;
	if (numPrograms < 0 || numPrograms > 4096 || numParams < 0 || numParams > 64)
		return kResultFalse;
	for (int32 p = 0; p < numPrograms; ++p)
		for (int32 i = 0; i < numParams; ++i)
		{
			double v = 0.;
			if (!s.readDouble (v))
				return kResultFalse;
			if (p < kNumPrograms && i < kProgramParams)
				programs_[p][i] = sphs::clamp01 (v);
		}
	bank_ = std::max (0, std::min (kBanks - 1, static_cast<int> (bank)));
	program_ = std::max (0, std::min (kPerBank - 1, static_cast<int> (program)));
	hold_ = hold != 0;
	if (coreIndexOfParam (static_cast<ParamID> (selected)) >= 0)
		selected_ = selected;
	if (editor_)
		editor_->refresh ();
	return kResultOk;
}

//------------------------------------------------------------------------
IPlugView* PLUGIN_API Controller::createView (FIDString name)
{
#if SPHS_HAS_COCOA_EDITOR
	if (name && FIDStringsEqual (name, ViewType::kEditor))
	{
		editor_ = new Editor (this);
		return editor_;
	}
#else
	(void)name; // no native editor on this platform (development / test builds)
#endif
	return nullptr;
}

void Controller::editorDestroyed (EditorView* editor)
{
	if (static_cast<EditorView*> (editor_) == editor)
		editor_ = nullptr;
}

tresult PLUGIN_API Controller::setParamNormalized (ParamID tag, ParamValue value)
{
	const tresult result = EditController::setParamNormalized (tag, value);
	if (tag == kParamEngineMode)
		announceMode (true);
	if (editor_)
		editor_->refresh ();
	return result;
}

/** Tells the processor which engine is selected (it reports the latency)
    and asks the host to re-read the latency when the engine changed. */
void Controller::announceMode (bool restart)
{
	const int mode = getParamNormalized (kParamEngineMode) > 0.5 ? 1 : 0;
	if (mode == lastMode_)
		return;
	lastMode_ = mode;
	if (IPtr<IMessage> msg = owned (allocateMessage ()))
	{
		msg->setMessageID (SPHS_MSG_MODE);
		msg->getAttributes ()->setInt ("mode", mode);
		sendMessage (msg);
	}
	if (restart && componentHandler)
		componentHandler->restartComponent (kLatencyChanged);
}

tresult PLUGIN_API Controller::getMidiControllerAssignment (int32 busIndex, int16 /*channel*/,
                                                            CtrlNumber midiControllerNumber, ParamID& id)
{
	if (busIndex == 0 && (midiControllerNumber == kCtrlExpression || midiControllerNumber == kCtrlFoot))
	{
		id = kParamPedalPos;
		return kResultTrue;
	}
	return kResultFalse;
}

//------------------------------------------------------------------------
void Controller::editParam (ParamID id, double value)
{
	value = sphs::clamp01 (value);
	beginEdit (id);
	setParamNormalized (id, value);
	performEdit (id, value);
	endEdit (id);
}

void Controller::dragParam (ParamID id, double value)
{
	value = sphs::clamp01 (value);
	setParamNormalized (id, value);
	performEdit (id, value);
}

bool Controller::programEdited ()
{
	const double* stored = programs_[bank_ * kPerBank + program_];
	for (int i = 0; i < kProgramParams; ++i)
		if (std::fabs (getParamNormalized (kProgramParamIds[i]) - stored[i]) > 1e-6)
			return true;
	return false;
}

void Controller::selectProgram (int bank, int program)
{
	bank_ = (bank % kBanks + kBanks) % kBanks;
	program_ = std::max (0, std::min (kPerBank - 1, program));
	const double* stored = programs_[bank_ * kPerBank + program_];
	for (int i = 0; i < kProgramParams; ++i)
		editParam (kProgramParamIds[i], stored[i]);
	if (editor_)
		editor_->refresh ();
}

// Original procedure: BANK, then a program switch = bank number, then a
// program switch = program number. The program changes only at the last step.
// Pressing BANK again cancels. Inside the same bank a program switch selects directly.
void Controller::pressBank ()
{
	bankPending_ = !bankPending_;
	pendingBank_ = -1;
	if (editor_)
		editor_->refresh ();
}

void Controller::pressProgram (int index)
{
	index = std::max (0, std::min (kPerBank - 1, index));
	if (bankPending_ && pendingBank_ < 0)
	{
		pendingBank_ = index;
		if (editor_)
			editor_->refresh ();
		return;
	}
	if (bankPending_)
	{
		const int target = (userB () ? 4 : 0) + pendingBank_;
		bankPending_ = false;
		pendingBank_ = -1;
		selectProgram (target, index);
		return;
	}
	selectProgram (bank_, index);
}

void Controller::toggleUserAB ()
{
	bankPending_ = false;
	pendingBank_ = -1;
	selectProgram ((bank_ + 4) % kBanks, program_);
}

void Controller::writeProgram ()
{
	double* stored = programs_[bank_ * kPerBank + program_];
	for (int i = 0; i < kProgramParams; ++i)
		stored[i] = getParamNormalized (kProgramParamIds[i]);
	// the program bank lives in the controller state: tell the host the project changed
	FUnknownPtr<IComponentHandler2> handler2 (componentHandler);
	if (handler2)
		handler2->setDirty (true);
	if (editor_)
		editor_->refresh ();
}

sphs::PedalTarget Controller::pedalTarget ()
{
	return sphs::pedalTargetFromNorm (getParamNormalized (kParamPedalTarget));
}

void Controller::fillNorm (double* norm)
{
	for (int i = 0; i < sphs::kCoreNumParams; ++i)
		norm[i] = getParamNormalized (kParamIdOfCore[i]);
}

sphs::UserParams Controller::effective ()
{
	double norm[sphs::kCoreNumParams];
	fillNorm (norm);
	return sphs::effectiveParamsFromNorm (norm);
}

} // namespace sphsvst
