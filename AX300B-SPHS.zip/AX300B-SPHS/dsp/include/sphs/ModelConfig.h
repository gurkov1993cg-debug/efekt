// SPHS stereo phaser - grey-box model description.
//
// Everything in ModelConfig is a HYPOTHESIS PARAMETER. None of these values
// has been measured on a real AX300B. They are the unknowns that the Python
// research suite (research/) estimates from hardware recordings. The defaults
// below are the "H0" starting hypothesis and are marked as unfitted.
#pragma once

namespace sphs {

constexpr int kMaxStages = 12;

// Documented user-parameter ranges (owner's manual, SPHS, Mod block).
constexpr double kSpeedMinHz = 0.02;
constexpr double kSpeedMaxHz = 9.5;
constexpr double kDepthMin = 0.0;
constexpr double kDepthMax = 50.0;
constexpr double kManualMin = 0.0;
constexpr double kManualMax = 50.0;
constexpr double kResonanceMin = -50.0;
constexpr double kResonanceMax = 50.0;

// Documented internal sampling frequency of the original unit.
constexpr double kReferenceSampleRate = 39062.5;

enum class StageKind : int { FirstOrder = 0, SecondOrder = 1 };
enum class LfoShape : int { Sine = 0, Triangle = 1, AsymTriangle = 2, WarpedSine = 3 };
enum class SweepLaw : int { Logarithmic = 0, Linear = 1, PowerLog = 2 };
enum class NegResonanceMode : int { InvertFeedback = 0, InvertWet = 1, InvertBoth = 2 };

struct ModelConfig
{
	// ---- identification -------------------------------------------------
	// 0 = unfitted hypothesis (H0). The fitting tool writes 1 here when the
	// values come from real AX300B measurements that passed validation.
	int fittedToHardware = 0;
	char name[32] = "H0-unfitted";

	// ---- all-pass network -----------------------------------------------
	StageKind stageKind = StageKind::FirstOrder;
	int numStages = 4;					///< 1..kMaxStages (2nd order: sections)
	double stageRatio[kMaxStages] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}; ///< per-stage frequency multiplier
	double stageQ = 0.7071;				///< only for SecondOrder

	// ---- dry / wet summing ----------------------------------------------
	double dryGain = 0.5;
	double wetGainL = 0.5;				///< sign = polarity
	double wetGainR = 0.5;
	double outputGain = 1.0;

	// ---- feedback (Resonance) -------------------------------------------
	double fbMax = 0.70;				///< |feedback| at Resonance = +/-50 (clamped < 0.98)
	double fbCurve = 1.0;				///< fb = fbMax * |r/50|^fbCurve
	NegResonanceMode negMode = NegResonanceMode::InvertFeedback;
	int fbTapStage = 0;					///< 0 = after last stage, k = after stage k
	double fbNormalize = 0.0;			///< input scaled by (1-|fb|)^fbNormalize

	// ---- LFO --------------------------------------------------------------
	LfoShape lfoShape = LfoShape::Sine;
	double lfoSkew = 0.5;				///< AsymTriangle: rising fraction (0..1)
	double lfoWarp = 0.0;				///< WarpedSine: -1..+1
	double stereoPhaseDeg = 90.0;		///< right-channel LFO offset
	double speedScale = 1.0;			///< Hz = speedScale * shown^speedExp
	double speedExp = 1.0;

	// ---- sweep (Manual / Depth) -----------------------------------------
	SweepLaw sweepLaw = SweepLaw::Logarithmic;
	double sweepPower = 1.0;			///< PowerLog only
	double fCenterMin = 150.0;			///< centre frequency at Manual = 0  [Hz]
	double fCenterMax = 3000.0;			///< centre frequency at Manual = 50 [Hz]
	double manualCurve = 1.0;
	double depthMaxOct = 2.0;			///< +/- octaves at Depth = 50
	double depthCurve = 1.0;
	double fClampLo = 20.0;				///< absolute lower limit of a stage frequency [Hz]
	double fClampHiFrac = 0.45;			///< upper limit as fraction of the processing rate

	// ---- optional amplitude movement (off unless measurements show it) ---
	double ampModDepth = 0.0;			///< 0..1
	double ampModPhaseDeg = 0.0;

	// ---- control smoothing -------------------------------------------------
	double paramSmoothMs = 15.0;
	double speedSmoothMs = 40.0;
};

/** Clamp every field to a safe range. Call after loading external data. */
void sanitize (ModelConfig& m);

/** The model compiled into the plug-in (H0 or the exported fitted model). */
const ModelConfig& defaultModel ();

} // namespace sphs
