// JSON load/save of a ModelConfig. Used by the command-line tools and the
// research suite only - the plug-in never touches files in the audio path.
#pragma once
#include "sphs/ModelConfig.h"
#include <string>

namespace sphs {

std::string modelToJson (const ModelConfig& m);
/** Unknown keys are ignored, missing keys keep their current value. */
bool modelFromJson (const std::string& json, ModelConfig& m);
bool loadModelFile (const std::string& path, ModelConfig& m);
bool saveModelFile (const std::string& path, const ModelConfig& m);

} // namespace sphs
