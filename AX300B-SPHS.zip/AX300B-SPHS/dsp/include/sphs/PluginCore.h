// PluginCore - everything the plug-in does to audio, without any VST3 type.
// The VST3 processor is a thin adapter around this class, so the same code
// is exercised by the stand-alone tests and by the host.
#pragma once
#include "sphs/Engine.h"
#include "sphs/PedalLogic.h"
#include <cstdint>
#include <vector>

namespace sphs {

enum CoreParam : int
{
	kCoreBypass = 0,
	kCoreSpeed,
	kCoreDepth,
	kCoreManual,
	kCoreResonance,
	kCorePedalTarget,
	kCorePedalMin,
	kCorePedalMax,
	kCorePedalPos,
	kCoreEngineMode,
	kCoreNumParams
};

/** Default normalized value of every parameter (neutral init, not a factory preset of the original). */
double coreParamDefault (int param);

/** One automation point: `value` (normalized 0..1) becomes active at `offset` samples into the block. */
struct CoreEvent
{
	int32_t offset;
	int32_t param;
	double value;
};

inline PedalTarget pedalTargetFromNorm (double n)
{
	int i = static_cast<int> (clamp01 (n) * (kNumPedalTargets - 1) + 0.5);
	return static_cast<PedalTarget> (i);
}
inline double pedalTargetToNorm (PedalTarget t)
{
	return static_cast<double> (static_cast<int> (t)) / (kNumPedalTargets - 1);
}

/** Base (stored) values in original units from normalized values. */
UserParams baseParamsFromNorm (const double* norm);
/** What the DSP receives: base values with the pedal applied. */
UserParams effectiveParamsFromNorm (const double* norm);

class PluginCore
{
public:
	PluginCore ();

	void setModel (const ModelConfig& m);
	/** Allocates. Call outside the audio callback. */
	void prepare (double sampleRate);
	void reset ();

	/** Immediate change (state load, tests). Normalized 0..1. */
	void setParam (int param, double normalized);
	double getParam (int param) const { return norm_[param]; }

	int latencySamples () const { return engine_.latency (); }
	int latencySamples (EngineMode mode) const { return engine_.latency (mode); }
	UserParams effectiveParams () const { return effectiveParamsFromNorm (norm_); }
	Engine& engine () { return engine_; }

	/** Mono (inR == nullptr) or stereo input (summed to mono), stereo output.
	    `events` must be sorted by offset. In-place buffers are allowed.
	    Real-time safe. */
	void process (const float* inL, const float* inR, float* outL, float* outR, int numSamples,
	              const CoreEvent* events, int numEvents);

private:
	static constexpr int kChunk = 512;
	void applyParams ();
	void render (const float* inL, const float* inR, float* outL, float* outR, int n);

	Engine engine_;
	double fs_ = 44100.;
	double norm_[kCoreNumParams];
	bool bypass_ = false;
	bool engineIdle_ = false;
	double activeGain_ = 1.; ///< 1 = effect, 0 = bypassed (cross-fade position)
	double fadeStep_ = 0.01;
	int fadeHold_ = 0;

	std::vector<float> dryDelay_;
	int dryMask_ = 0, dryWrite_ = 0;
	float mono_[kChunk];
	float dry_[kChunk];
	float wetL_[kChunk];
	float wetR_[kChunk];
};

} // namespace sphs
