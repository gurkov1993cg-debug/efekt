// AUTO-REPLACED FILE.
//
// research/sphs_research/export_model.py overwrites this file with the model
// fitted to real AX300B recordings. As shipped it contains NO fitted data:
// the plug-in then uses the H0 hypothesis from ModelConfig.h.
#pragma once
#include "sphs/ModelConfig.h"

namespace sphs {

inline void applyFittedModel (ModelConfig& /*m*/)
{
	// intentionally empty - no hardware fit available
}

} // namespace sphs
