// SPHS stereo phaser core: mono in -> stereo out.
// Self-contained C++17, no dependency on VST3 or any GUI code.
#pragma once
#include "sphs/ModelConfig.h"
#include <complex>

namespace sphs {

//------------------------------------------------------------------------
/** Parameter laws. One single definition used by the audio code, the
    plug-in display, the tests and (mirrored) the Python model. */
namespace laws {

double lfoValue (const ModelConfig& m, double phase01);				///< -1..+1
double speedHz (const ModelConfig& m, double shownHz);				///< real LFO rate
double centerHz (const ModelConfig& m, double manual);				///< Manual 0..50
double widthOct (const ModelConfig& m, double depth);				///< Depth 0..50
double sweepHz (const ModelConfig& m, double centerHz, double widthOct, double lfo);
double feedback (const ModelConfig& m, double resonance);			///< signed loop gain
double wetSign (const ModelConfig& m, double resonance);			///< +1 / -1
double stageHz (const ModelConfig& m, int stage, double sweepHz, double fs);

/** First-order all-pass coefficient  H(z) = (a + z^-1) / (1 + a z^-1). */
double firstOrderCoeff (double freqHz, double fs);
/** Second-order all-pass coefficients (c, e):
    H(z) = (-c + e z^-1 + z^-2) / (1 + e z^-1 - c z^-2). */
void secondOrderCoeff (double freqHz, double q, double fs, double& c, double& e);

/** Analytic frozen-LFO response of one channel at `freqHz`. */
std::complex<double> channelResponse (const ModelConfig& m, double fs, double sweepHz,
                                      double resonance, double wetGain, double freqHz);

} // namespace laws

//------------------------------------------------------------------------
class StereoPhaser
{
public:
	/** Coefficients are recomputed every kControlInterval samples and
	    interpolated per sample. The grid is counted in samples since reset,
	    so the result does not depend on the host buffer size. */
	static constexpr int kControlInterval = 16;

	StereoPhaser ();

	void setModel (const ModelConfig& m);
	const ModelConfig& model () const { return m_; }

	void prepare (double sampleRate);
	void reset ();

	// Original front-panel parameters, in their documented units.
	void setSpeed (double shownHz);		///< 0.02 .. 9.5
	void setDepth (double v);			///< 0 .. 50
	void setManual (double v);			///< 0 .. 50
	void setResonance (double v);		///< -50 .. +50

	/** Mono in, stereo out. May be called with any block length (>= 0).
	    Real-time safe: no allocation, no locks, no system calls. */
	void process (const float* in, float* outL, float* outR, int numSamples);

	// Introspection (tests / measurement tools).
	double sampleRate () const { return fs_; }
	double lfoPhase () const { return phase_; }
	double sweepHzLeft () const { return curSweep_[0]; }
	double sweepHzRight () const { return curSweep_[1]; }
	double feedbackNow () const { return fb_.cur; }

private:
	struct Ramp
	{
		double cur = 0., inc = 0.;
		void set (double v) { cur = v; inc = 0.; }
		void target (double v, double invLen) { inc = (v - cur) * invLen; }
	};
	struct Channel
	{
		double s1[kMaxStages];
		double s2[kMaxStages];
		Ramp c[4][kMaxStages]; ///< 1st order: (a, sqrt(1-a^2)); 2nd order: (k1, g1, k2, g2)
		Ramp wet;
		Ramp amp;
		double fbState;
	};

	void controlTick (bool snap);
	void computeTargets (double phase, bool snap);
	void processSegment (const float* in, float* outL, float* outR, int n);
	void processChannel (Channel& ch, const float* in, float* out, int n,
	                     double& fb, double fbInc, double& sc, double scInc);

	ModelConfig m_;
	double fs_ = 44100.;
	int counter_ = 0;
	double phase_ = 0.;

	// targets (user) and smoothed values
	double tgtSpeed_ = 0.5, tgtDepth_ = 25., tgtManual_ = 25., tgtRes_ = 0.;
	double smSpeed_ = 0.5, smDepth_ = 25., smManual_ = 25., smRes_ = 0.;
	double kParam_ = 1., kSpeed_ = 1.;

	Channel ch_[2];
	Ramp fb_;
	Ramp inScale_;
	double curSweep_[2] = {0., 0.};
};

} // namespace sphs
