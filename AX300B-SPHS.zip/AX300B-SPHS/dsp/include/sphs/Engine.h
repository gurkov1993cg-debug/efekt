// Engine = Native mode (phaser at the host rate) + Reference mode (phaser at
// the documented 39.0625 kHz internal rate with sample-rate conversion).
#pragma once
#include "sphs/Phaser.h"
#include <cstdint>
#include <vector>

namespace sphs {

//------------------------------------------------------------------------
/** Windowed-sinc fractional resampler with an exact rational clock.
    Output sample k is taken at input time k * stepNum / stepDen. */
class FractionalResampler
{
public:
	/** Allocates. Never call from the audio callback. */
	void prepare (int64_t stepNum, int64_t stepDen, int halfTaps, double cutoffCyclesPerSample,
	              double kaiserBeta, int maxInputChunk);
	void reset ();
	int maxOutputFor (int numIn) const;
	/** Real-time safe. Returns the number of output samples written. */
	int process (const float* in, int numIn, float* out);
	int halfTaps () const { return half_; }

private:
	static constexpr int kPhases = 256;
	std::vector<float> table_;
	std::vector<float> buf_;
	int taps_ = 0, half_ = 0, maxIn_ = 0;
	int64_t posInt_ = 0, posNum_ = 0, stepInt_ = 0, stepRem_ = 0, den_ = 1;
};

//------------------------------------------------------------------------
enum class EngineMode : int { Native = 0, Reference = 1 };

struct ResamplerQuality
{
	int baseHalfTaps = 64;	  ///< half length of the kernel at the lower rate
	double kaiserBeta = 8.0;  ///< ~80 dB stop-band
	double cutoffRel = 1.0;	  ///< -6 dB point relative to the lower Nyquist
};

class Engine
{
public:
	Engine ();

	void setModel (const ModelConfig& m);
	void setResamplerQuality (const ResamplerQuality& q) { quality_ = q; }

	/** Allocates all buffers. Call when the host sample rate is known,
	    outside the audio callback. */
	void prepare (double hostSampleRate);
	void reset ();

	/** Real-time safe. Clears the state of the newly selected mode. */
	void setMode (EngineMode mode);
	EngineMode mode () const { return mode_; }

	/** Latency in host samples (0 in Native mode). */
	int latency (EngineMode mode) const { return mode == EngineMode::Reference ? refLatency_ : 0; }
	int latency () const { return latency (mode_); }

	void setParams (double speedHz, double depth, double manual, double resonance);

	/** Mono in, stereo out. Real-time safe for any block length. */
	void process (const float* in, float* outL, float* outR, int numSamples);

	StereoPhaser& nativePhaser () { return native_; }
	StereoPhaser& referencePhaser () { return reference_; }
	double hostSampleRate () const { return hostRate_; }
	long underruns () const { return underruns_; }

private:
	static constexpr int kChunk = 256;
	void processReferenceChunk (const float* in, float* outL, float* outR, int n);

	StereoPhaser native_;
	StereoPhaser reference_;
	ResamplerQuality quality_;
	EngineMode mode_ = EngineMode::Native;
	double hostRate_ = 44100.;
	int refLatency_ = 0;
	long underruns_ = 0;

	FractionalResampler down_, upL_, upR_;
	std::vector<float> tmpIn_, tmpL_, tmpR_, hostL_, hostR_;
	std::vector<float> fifoL_, fifoR_;
	int fifoMask_ = 0, fifoRead_ = 0, fifoWrite_ = 0, fifoCount_ = 0;
};

} // namespace sphs
