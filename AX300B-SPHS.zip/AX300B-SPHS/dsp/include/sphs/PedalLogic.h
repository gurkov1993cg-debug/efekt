// Pressure / expression pedal logic and user-parameter scaling.
//
// Owner's-manual behaviour that this follows: PARAM selects which effect
// parameter the pedal controls, MIN is the value with the pedal released,
// MAX is the value with the pedal fully pressed. While a parameter is
// assigned, the pedal (not the stored value) defines that parameter.
#pragma once
#include "sphs/ModelConfig.h"
#include <algorithm>
#include <cmath>

namespace sphs {

enum class PedalTarget : int { Off = 0, Speed = 1, Depth = 2, Manual = 3, Resonance = 4 };
constexpr int kNumPedalTargets = 5;

struct UserParams
{
	double speedHz = 0.5;	 ///< 0.02 .. 9.5
	double depth = 25.;		 ///< 0 .. 50
	double manual = 25.;	 ///< 0 .. 50
	double resonance = 0.;	 ///< -50 .. +50
};

inline double clamp01 (double v) { return v < 0. ? 0. : (v > 1. ? 1. : v); }

/** Speed uses a logarithmic control scale between the documented limits. */
inline double speedFromNorm (double n)
{
	return kSpeedMinHz * std::pow (kSpeedMaxHz / kSpeedMinHz, clamp01 (n));
}
inline double speedToNorm (double hz)
{
	const double h = std::min (kSpeedMaxHz, std::max (kSpeedMinHz, hz));
	return clamp01 (std::log (h / kSpeedMinHz) / std::log (kSpeedMaxHz / kSpeedMinHz));
}
inline double depthFromNorm (double n) { return kDepthMin + clamp01 (n) * (kDepthMax - kDepthMin); }
inline double manualFromNorm (double n) { return kManualMin + clamp01 (n) * (kManualMax - kManualMin); }
inline double resonanceFromNorm (double n)
{
	return kResonanceMin + clamp01 (n) * (kResonanceMax - kResonanceMin);
}

/** Plain value of `target` for a normalized (0..1) position on its scale. */
inline double targetPlainFromNorm (PedalTarget target, double n)
{
	switch (target)
	{
		case PedalTarget::Speed: return speedFromNorm (n);
		case PedalTarget::Depth: return depthFromNorm (n);
		case PedalTarget::Manual: return manualFromNorm (n);
		case PedalTarget::Resonance: return resonanceFromNorm (n);
		default: return 0.;
	}
}

/** Position between MIN (released) and MAX (fully pressed), normalized. */
inline double pedalNorm (double minNorm, double maxNorm, double position)
{
	return clamp01 (minNorm) + clamp01 (position) * (clamp01 (maxNorm) - clamp01 (minNorm));
}

/** The parameters the DSP really receives. MIN may be above MAX (reverse). */
inline UserParams applyPedal (UserParams base, PedalTarget target, double minNorm, double maxNorm,
                              double position)
{
	const double n = pedalNorm (minNorm, maxNorm, position);
	switch (target)
	{
		case PedalTarget::Speed: base.speedHz = speedFromNorm (n); break;
		case PedalTarget::Depth: base.depth = depthFromNorm (n); break;
		case PedalTarget::Manual: base.manual = manualFromNorm (n); break;
		case PedalTarget::Resonance: base.resonance = resonanceFromNorm (n); break;
		default: break;
	}
	return base;
}

} // namespace sphs
