#include "sphs/Phaser.h"
#include "sphs/FittedModel.h"
#include <algorithm>
#include <cmath>
#include <cstring>

namespace sphs {

namespace {
constexpr double kPi = 3.14159265358979323846;
constexpr double kAntiDenormal = 1e-18;

inline double clampd (double v, double lo, double hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline double wrap01 (double p) { return p - std::floor (p); }
} // namespace

//------------------------------------------------------------------------
void sanitize (ModelConfig& m)
{
	m.numStages = std::max (1, std::min (kMaxStages, m.numStages));
	for (double& r : m.stageRatio)
		r = clampd (r, 0.05, 20.);
	m.stageQ = clampd (m.stageQ, 0.1, 20.);
	m.dryGain = clampd (m.dryGain, -2., 2.);
	m.wetGainL = clampd (m.wetGainL, -2., 2.);
	m.wetGainR = clampd (m.wetGainR, -2., 2.);
	m.outputGain = clampd (m.outputGain, 0., 4.);
	m.fbMax = clampd (m.fbMax, 0., 0.98);
	m.fbCurve = clampd (m.fbCurve, 0.1, 8.);
	m.fbTapStage = std::max (0, std::min (m.numStages, m.fbTapStage));
	m.fbNormalize = clampd (m.fbNormalize, 0., 1.);
	m.lfoSkew = clampd (m.lfoSkew, 0.02, 0.98);
	m.lfoWarp = clampd (m.lfoWarp, -1., 1.);
	m.speedScale = clampd (m.speedScale, 0.01, 100.);
	m.speedExp = clampd (m.speedExp, 0.1, 4.);
	m.sweepPower = clampd (m.sweepPower, 0.1, 8.);
	m.fCenterMin = clampd (m.fCenterMin, 5., 20000.);
	m.fCenterMax = clampd (m.fCenterMax, m.fCenterMin, 20000.);
	m.manualCurve = clampd (m.manualCurve, 0.1, 8.);
	m.depthMaxOct = clampd (m.depthMaxOct, 0., 8.);
	m.depthCurve = clampd (m.depthCurve, 0.1, 8.);
	m.fClampLo = clampd (m.fClampLo, 1., 1000.);
	m.fClampHiFrac = clampd (m.fClampHiFrac, 0.05, 0.49);
	m.ampModDepth = clampd (m.ampModDepth, 0., 1.);
	m.paramSmoothMs = clampd (m.paramSmoothMs, 0., 1000.);
	m.speedSmoothMs = clampd (m.speedSmoothMs, 0., 1000.);
	m.name[sizeof (m.name) - 1] = 0;
}

const ModelConfig& defaultModel ()
{
	static const ModelConfig model = [] {
		ModelConfig m;
		applyFittedModel (m);
		sanitize (m);
		return m;
	}();
	return model;
}

//------------------------------------------------------------------------
namespace laws {

double lfoValue (const ModelConfig& m, double phase01)
{
	const double p = wrap01 (phase01);
	switch (m.lfoShape)
	{
		case LfoShape::Triangle:
		{
			const double q = wrap01 (p + 0.25);
			return 1. - 4. * std::fabs (q - 0.5);
		}
		case LfoShape::AsymTriangle:
		{
			const double s = clampd (m.lfoSkew, 0.02, 0.98);
			return p < s ? -1. + 2. * p / s : 1. - 2. * (p - s) / (1. - s);
		}
		case LfoShape::WarpedSine:
		{
			const double u = std::sin (2. * kPi * p);
			const double w = clampd (m.lfoWarp, -1., 1.);
			const double g = w >= 0. ? std::tanh (3. * u) / std::tanh (3.) : u * u * u;
			const double a = std::fabs (w);
			return (1. - a) * u + a * g;
		}
		case LfoShape::Sine:
		default: return std::sin (2. * kPi * p);
	}
}

double speedHz (const ModelConfig& m, double shownHz)
{
	const double s = clampd (shownHz, kSpeedMinHz, kSpeedMaxHz);
	return clampd (m.speedScale * std::pow (s, m.speedExp), 0.001, 40.);
}

double centerHz (const ModelConfig& m, double manual)
{
	const double x = std::pow (clampd (manual / kManualMax, 0., 1.), m.manualCurve);
	return m.fCenterMin * std::pow (m.fCenterMax / m.fCenterMin, x);
}

double widthOct (const ModelConfig& m, double depth)
{
	const double x = std::pow (clampd (depth / kDepthMax, 0., 1.), m.depthCurve);
	return x * m.depthMaxOct;
}

double sweepHz (const ModelConfig& m, double center, double width, double lfo)
{
	const double u = clampd (lfo, -1., 1.);
	switch (m.sweepLaw)
	{
		case SweepLaw::Linear:
		{
			const double lo = center * std::exp2 (-width);
			const double hi = center * std::exp2 (width);
			return lo + 0.5 * (u + 1.) * (hi - lo);
		}
		case SweepLaw::PowerLog:
		{
			const double t = std::pow (0.5 * (u + 1.), m.sweepPower);
			return center * std::exp2 (width * (2. * t - 1.));
		}
		case SweepLaw::Logarithmic:
		default: return center * std::exp2 (width * u);
	}
}

double feedback (const ModelConfig& m, double resonance)
{
	const double r = clampd (resonance / kResonanceMax, -1., 1.);
	const double g = std::min (0.98, m.fbMax) * std::pow (std::fabs (r), m.fbCurve);
	if (m.negMode == NegResonanceMode::InvertWet)
		return g;
	return r < 0. ? -g : g;
}

double wetSign (const ModelConfig& m, double resonance)
{
	if (m.negMode == NegResonanceMode::InvertFeedback)
		return 1.;
	return resonance < 0. ? -1. : 1.;
}

double stageHz (const ModelConfig& m, int stage, double sweep, double fs)
{
	const double f = sweep * m.stageRatio[stage];
	return clampd (f, m.fClampLo, m.fClampHiFrac * fs);
}

double firstOrderCoeff (double freqHz, double fs)
{
	const double t = std::tan (kPi * freqHz / fs);
	return (t - 1.) / (t + 1.);
}

void secondOrderCoeff (double freqHz, double q, double fs, double& c, double& e)
{
	const double bw = clampd (freqHz / q, 1., 0.49 * fs);
	const double t = std::tan (kPi * bw / fs);
	c = (t - 1.) / (t + 1.);
	const double d = -std::cos (2. * kPi * freqHz / fs);
	e = d * (1. - c);
}

std::complex<double> channelResponse (const ModelConfig& m, double fs, double sweep,
                                      double resonance, double wetGain, double freqHz)
{
	using cd = std::complex<double>;
	const cd z1 = std::exp (cd (0., -2. * kPi * freqHz / fs)); // z^-1
	const int tap = m.fbTapStage == 0 ? m.numStages : m.fbTapStage;
	cd full (1., 0.), tapped (1., 0.);
	for (int k = 0; k < m.numStages; ++k)
	{
		const double f = stageHz (m, k, sweep, fs);
		cd h;
		if (m.stageKind == StageKind::SecondOrder)
		{
			double c, e;
			secondOrderCoeff (f, m.stageQ, fs, c, e);
			h = (-c + e * z1 + z1 * z1) / (1. + e * z1 - c * z1 * z1);
		}
		else
		{
			const double a = firstOrderCoeff (f, fs);
			h = (a + z1) / (1. + a * z1);
		}
		full *= h;
		if (k + 1 == tap)
			tapped = full;
	}
	const double fb = feedback (m, resonance);
	const double inScale = std::pow (1. - std::fabs (fb), m.fbNormalize);
	const cd wet = full * inScale / (1. - fb * z1 * tapped);
	return m.outputGain * (m.dryGain + wetGain * wetSign (m, resonance) * wet);
}

} // namespace laws

//------------------------------------------------------------------------
StereoPhaser::StereoPhaser ()
{
	m_ = defaultModel ();
	prepare (44100.);
}

void StereoPhaser::setModel (const ModelConfig& m)
{
	m_ = m;
	sanitize (m_);
	prepare (fs_);
}

void StereoPhaser::prepare (double sampleRate)
{
	fs_ = sampleRate > 1000. ? sampleRate : 44100.;
	const double dt = static_cast<double> (kControlInterval) / fs_;
	kParam_ = m_.paramSmoothMs > 0. ? 1. - std::exp (-dt / (m_.paramSmoothMs * 0.001)) : 1.;
	kSpeed_ = m_.speedSmoothMs > 0. ? 1. - std::exp (-dt / (m_.speedSmoothMs * 0.001)) : 1.;
	reset ();
}

void StereoPhaser::reset ()
{
	counter_ = 0;
	phase_ = 0.;
	smSpeed_ = tgtSpeed_;
	smDepth_ = tgtDepth_;
	smManual_ = tgtManual_;
	smRes_ = tgtRes_;
	for (Channel& c : ch_)
	{
		std::memset (c.s1, 0, sizeof (c.s1));
		std::memset (c.s2, 0, sizeof (c.s2));
		c.fbState = 0.;
	}
	computeTargets (phase_, true);
}

void StereoPhaser::setSpeed (double v) { tgtSpeed_ = clampd (v, kSpeedMinHz, kSpeedMaxHz); }
void StereoPhaser::setDepth (double v) { tgtDepth_ = clampd (v, kDepthMin, kDepthMax); }
void StereoPhaser::setManual (double v) { tgtManual_ = clampd (v, kManualMin, kManualMax); }
void StereoPhaser::setResonance (double v) { tgtRes_ = clampd (v, kResonanceMin, kResonanceMax); }

//------------------------------------------------------------------------
void StereoPhaser::computeTargets (double phase, bool snap)
{
	const double invLen = 1. / kControlInterval;
	const double center = laws::centerHz (m_, smManual_);
	const double width = laws::widthOct (m_, smDepth_);
	const double fb = laws::feedback (m_, smRes_);
	const double sign = laws::wetSign (m_, smRes_);
	const double scale = std::pow (1. - std::fabs (fb), m_.fbNormalize);

	if (snap)
	{
		fb_.set (fb);
		inScale_.set (scale);
	}
	else
	{
		fb_.target (fb, invLen);
		inScale_.target (scale, invLen);
	}

	for (int c = 0; c < 2; ++c)
	{
		Channel& ch = ch_[c];
		const double ph = c == 0 ? phase : phase + m_.stereoPhaseDeg / 360.;
		const double lfo = laws::lfoValue (m_, ph);
		const double sweep = laws::sweepHz (m_, center, width, lfo);
		curSweep_[c] = sweep;

		for (int k = 0; k < m_.numStages; ++k)
		{
			const double f = laws::stageHz (m_, k, sweep, fs_);
			double v[4] = {0., 0., 0., 0.};
			if (m_.stageKind == StageKind::SecondOrder)
			{
				// normalized lattice: k1 = e / (1 - c), k2 = -c
				double cc, e;
				laws::secondOrderCoeff (f, m_.stageQ, fs_, cc, e);
				v[0] = clampd (e / (1. - cc), -0.999999, 0.999999);
				v[1] = std::sqrt (1. - v[0] * v[0]);
				v[2] = -cc;
				v[3] = std::sqrt (std::max (0., 1. - cc * cc));
			}
			else
			{
				v[0] = laws::firstOrderCoeff (f, fs_);
				v[1] = std::sqrt (std::max (0., 1. - v[0] * v[0]));
			}
			for (int j = 0; j < 4; ++j)
			{
				if (snap)
					ch.c[j][k].set (v[j]);
				else
					ch.c[j][k].target (v[j], invLen);
			}
		}

		const double wet = (c == 0 ? m_.wetGainL : m_.wetGainR) * sign;
		double amp = m_.outputGain;
		if (m_.ampModDepth > 0.)
		{
			const double a = laws::lfoValue (m_, ph + m_.ampModPhaseDeg / 360.);
			amp *= 1. - m_.ampModDepth * 0.5 * (1. + a);
		}
		if (snap)
		{
			ch.wet.set (wet);
			ch.amp.set (amp);
		}
		else
		{
			ch.wet.target (wet, invLen);
			ch.amp.target (amp, invLen);
		}
	}
}

//------------------------------------------------------------------------
void StereoPhaser::controlTick (bool snap)
{
	// one-pole smoothing of the user parameters (control rate)
	smSpeed_ += (tgtSpeed_ - smSpeed_) * kSpeed_;
	smDepth_ += (tgtDepth_ - smDepth_) * kParam_;
	smManual_ += (tgtManual_ - smManual_) * kParam_;
	smRes_ += (tgtRes_ - smRes_) * kParam_;

	// advance the LFO to the END of the coming interval; the per-sample
	// ramps then land exactly on these targets at the next tick.
	const double hz = laws::speedHz (m_, smSpeed_);
	phase_ = wrap01 (phase_ + hz * static_cast<double> (kControlInterval) / fs_);
	computeTargets (phase_, snap);
}

//------------------------------------------------------------------------
void StereoPhaser::processChannel (Channel& ch, const float* in, float* out, int n,
                                   double& fbRef, double fbInc, double& scRef, double scInc)
{
	double fb = fbRef;
	double sc = scRef;
	const int stages = m_.numStages;
	const int tap = m_.fbTapStage == 0 ? stages : m_.fbTapStage;
	const double dry = m_.dryGain;
	const bool second = m_.stageKind == StageKind::SecondOrder;
	double fbState = ch.fbState;

	for (int i = 0; i < n; ++i)
	{
		const double x = static_cast<double> (in[i]);
		double v = x * sc + fb * fbState + kAntiDenormal;
		double tapped = 0.;
		// Every stage is realised as an orthogonal rotation of (input, state).
		// With fixed coefficients this is exactly the all-pass
		//   H(z) = (a + z^-1) / (1 + a z^-1)      (first order)
		// and, because a rotation cannot add energy, the network stays
		// passive for ANY modulation speed. With |feedback| < 1 the loop is
		// therefore stable however fast the LFO or the pedal moves.
		if (second)
		{
			for (int k = 0; k < stages; ++k)
			{
				const double k1 = ch.c[0][k].cur, g1 = ch.c[1][k].cur;
				const double k2 = ch.c[2][k].cur, g2 = ch.c[3][k].cur;
				const double z0 = ch.s1[k], z1 = ch.s2[k];
				const double f1 = g2 * v - k2 * z1;
				const double y = k2 * v + g2 * z1;
				ch.s1[k] = g1 * f1 - k1 * z0;
				ch.s2[k] = k1 * f1 + g1 * z0;
				v = y;
				ch.c[0][k].cur += ch.c[0][k].inc;
				ch.c[1][k].cur += ch.c[1][k].inc;
				ch.c[2][k].cur += ch.c[2][k].inc;
				ch.c[3][k].cur += ch.c[3][k].inc;
				if (k + 1 == tap)
					tapped = v;
			}
		}
		else
		{
			for (int k = 0; k < stages; ++k)
			{
				const double a = ch.c[0][k].cur, g = ch.c[1][k].cur;
				const double st = ch.s1[k];
				const double y = a * v + g * st;
				ch.s1[k] = g * v - a * st;
				v = y;
				ch.c[0][k].cur += ch.c[0][k].inc;
				ch.c[1][k].cur += ch.c[1][k].inc;
				if (k + 1 == tap)
					tapped = v;
			}
		}
		fbState = tapped;
		out[i] = static_cast<float> ((dry * x + ch.wet.cur * v) * ch.amp.cur);
		ch.wet.cur += ch.wet.inc;
		ch.amp.cur += ch.amp.inc;
		fb += fbInc;
		sc += scInc;
	}
	ch.fbState = fbState;
	fbRef = fb;
	scRef = sc;
}

void StereoPhaser::processSegment (const float* in, float* outL, float* outR, int n)
{
	// both channels share the same feedback / input-scale ramps
	double fbL = fb_.cur, scL = inScale_.cur;
	double fbR = fb_.cur, scR = inScale_.cur;
	processChannel (ch_[0], in, outL, n, fbL, fb_.inc, scL, inScale_.inc);
	processChannel (ch_[1], in, outR, n, fbR, fb_.inc, scR, inScale_.inc);
	fb_.cur = fbR;
	inScale_.cur = scR;
}

void StereoPhaser::process (const float* in, float* outL, float* outR, int numSamples)
{
	while (numSamples > 0)
	{
		if (counter_ == 0)
			controlTick (false);
		const int seg = std::min (numSamples, kControlInterval - counter_);
		processSegment (in, outL, outR, seg);
		counter_ += seg;
		if (counter_ >= kControlInterval)
			counter_ = 0;
		in += seg;
		outL += seg;
		outR += seg;
		numSamples -= seg;
	}
}

} // namespace sphs
