#include "sphs/ModelIO.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <sstream>
#include <vector>

namespace sphs {

namespace {

// Finds  "key" :  and returns the position just after the colon.
size_t findValue (const std::string& s, const char* key)
{
	const std::string needle = std::string ("\"") + key + "\"";
	size_t p = s.find (needle);
	if (p == std::string::npos)
		return p;
	p = s.find (':', p + needle.size ());
	return p == std::string::npos ? p : p + 1;
}

bool getNumber (const std::string& s, const char* key, double& out)
{
	const size_t p = findValue (s, key);
	if (p == std::string::npos)
		return false;
	const char* start = s.c_str () + p;
	char* end = nullptr;
	const double v = std::strtod (start, &end);
	if (end == start)
		return false;
	out = v;
	return true;
}

template <typename T>
void getInt (const std::string& s, const char* key, T& out)
{
	double v;
	if (getNumber (s, key, v))
		out = static_cast<T> (static_cast<int> (v));
}

void getArray (const std::string& s, const char* key, double* out, int maxCount)
{
	size_t p = findValue (s, key);
	if (p == std::string::npos)
		return;
	p = s.find ('[', p);
	const size_t q = s.find (']', p);
	if (p == std::string::npos || q == std::string::npos)
		return;
	const char* cur = s.c_str () + p + 1;
	const char* stop = s.c_str () + q;
	for (int i = 0; i < maxCount && cur < stop; ++i)
	{
		char* end = nullptr;
		const double v = std::strtod (cur, &end);
		if (end == cur)
			break;
		out[i] = v;
		cur = end;
		while (cur < stop && (*cur == ',' || *cur == ' ' || *cur == '\n' || *cur == '\t' || *cur == '\r'))
			++cur;
	}
}

void getString (const std::string& s, const char* key, char* out, size_t size)
{
	size_t p = findValue (s, key);
	if (p == std::string::npos)
		return;
	p = s.find ('"', p);
	if (p == std::string::npos)
		return;
	const size_t q = s.find ('"', p + 1);
	if (q == std::string::npos)
		return;
	const std::string v = s.substr (p + 1, q - p - 1);
	std::snprintf (out, size, "%s", v.c_str ());
}

} // namespace

std::string modelToJson (const ModelConfig& m)
{
	std::ostringstream o;
	o.precision (12);
	o << "{\n";
	o << "  \"name\": \"" << m.name << "\",\n";
	o << "  \"fittedToHardware\": " << m.fittedToHardware << ",\n";
	o << "  \"stageKind\": " << static_cast<int> (m.stageKind) << ",\n";
	o << "  \"numStages\": " << m.numStages << ",\n";
	o << "  \"stageRatio\": [";
	for (int i = 0; i < kMaxStages; ++i)
		o << m.stageRatio[i] << (i + 1 < kMaxStages ? ", " : "");
	o << "],\n";
	o << "  \"stageQ\": " << m.stageQ << ",\n";
	o << "  \"dryGain\": " << m.dryGain << ",\n";
	o << "  \"wetGainL\": " << m.wetGainL << ",\n";
	o << "  \"wetGainR\": " << m.wetGainR << ",\n";
	o << "  \"outputGain\": " << m.outputGain << ",\n";
	o << "  \"fbMax\": " << m.fbMax << ",\n";
	o << "  \"fbCurve\": " << m.fbCurve << ",\n";
	o << "  \"negMode\": " << static_cast<int> (m.negMode) << ",\n";
	o << "  \"fbTapStage\": " << m.fbTapStage << ",\n";
	o << "  \"fbNormalize\": " << m.fbNormalize << ",\n";
	o << "  \"lfoShape\": " << static_cast<int> (m.lfoShape) << ",\n";
	o << "  \"lfoSkew\": " << m.lfoSkew << ",\n";
	o << "  \"lfoWarp\": " << m.lfoWarp << ",\n";
	o << "  \"stereoPhaseDeg\": " << m.stereoPhaseDeg << ",\n";
	o << "  \"speedScale\": " << m.speedScale << ",\n";
	o << "  \"speedExp\": " << m.speedExp << ",\n";
	o << "  \"sweepLaw\": " << static_cast<int> (m.sweepLaw) << ",\n";
	o << "  \"sweepPower\": " << m.sweepPower << ",\n";
	o << "  \"fCenterMin\": " << m.fCenterMin << ",\n";
	o << "  \"fCenterMax\": " << m.fCenterMax << ",\n";
	o << "  \"manualCurve\": " << m.manualCurve << ",\n";
	o << "  \"depthMaxOct\": " << m.depthMaxOct << ",\n";
	o << "  \"depthCurve\": " << m.depthCurve << ",\n";
	o << "  \"fClampLo\": " << m.fClampLo << ",\n";
	o << "  \"fClampHiFrac\": " << m.fClampHiFrac << ",\n";
	o << "  \"ampModDepth\": " << m.ampModDepth << ",\n";
	o << "  \"ampModPhaseDeg\": " << m.ampModPhaseDeg << ",\n";
	o << "  \"paramSmoothMs\": " << m.paramSmoothMs << ",\n";
	o << "  \"speedSmoothMs\": " << m.speedSmoothMs << "\n";
	o << "}\n";
	return o.str ();
}

bool modelFromJson (const std::string& s, ModelConfig& m)
{
	if (s.find ('{') == std::string::npos)
		return false;
	getString (s, "name", m.name, sizeof (m.name));
	getInt (s, "fittedToHardware", m.fittedToHardware);
	getInt (s, "stageKind", m.stageKind);
	getInt (s, "numStages", m.numStages);
	getArray (s, "stageRatio", m.stageRatio, kMaxStages);
	getNumber (s, "stageQ", m.stageQ);
	getNumber (s, "dryGain", m.dryGain);
	getNumber (s, "wetGainL", m.wetGainL);
	getNumber (s, "wetGainR", m.wetGainR);
	getNumber (s, "outputGain", m.outputGain);
	getNumber (s, "fbMax", m.fbMax);
	getNumber (s, "fbCurve", m.fbCurve);
	getInt (s, "negMode", m.negMode);
	getInt (s, "fbTapStage", m.fbTapStage);
	getNumber (s, "fbNormalize", m.fbNormalize);
	getInt (s, "lfoShape", m.lfoShape);
	getNumber (s, "lfoSkew", m.lfoSkew);
	getNumber (s, "lfoWarp", m.lfoWarp);
	getNumber (s, "stereoPhaseDeg", m.stereoPhaseDeg);
	getNumber (s, "speedScale", m.speedScale);
	getNumber (s, "speedExp", m.speedExp);
	getInt (s, "sweepLaw", m.sweepLaw);
	getNumber (s, "sweepPower", m.sweepPower);
	getNumber (s, "fCenterMin", m.fCenterMin);
	getNumber (s, "fCenterMax", m.fCenterMax);
	getNumber (s, "manualCurve", m.manualCurve);
	getNumber (s, "depthMaxOct", m.depthMaxOct);
	getNumber (s, "depthCurve", m.depthCurve);
	getNumber (s, "fClampLo", m.fClampLo);
	getNumber (s, "fClampHiFrac", m.fClampHiFrac);
	getNumber (s, "ampModDepth", m.ampModDepth);
	getNumber (s, "ampModPhaseDeg", m.ampModPhaseDeg);
	getNumber (s, "paramSmoothMs", m.paramSmoothMs);
	getNumber (s, "speedSmoothMs", m.speedSmoothMs);
	sanitize (m);
	return true;
}

bool loadModelFile (const std::string& path, ModelConfig& m)
{
	std::ifstream f (path);
	if (!f)
		return false;
	std::stringstream ss;
	ss << f.rdbuf ();
	return modelFromJson (ss.str (), m);
}

bool saveModelFile (const std::string& path, const ModelConfig& m)
{
	std::ofstream f (path);
	if (!f)
		return false;
	f << modelToJson (m);
	return static_cast<bool> (f);
}

} // namespace sphs
