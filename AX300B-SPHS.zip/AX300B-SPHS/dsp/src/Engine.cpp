#include "sphs/Engine.h"
#include <algorithm>
#include <cmath>
#include <cstring>
#if defined(__SSE__) || defined(_M_X64)
#include <xmmintrin.h>
#define SPHS_SSE 1
#endif

namespace sphs {

namespace {
constexpr double kPi = 3.14159265358979323846;

double besselI0 (double x)
{
	double sum = 1., term = 1.;
	const double q = x * x * 0.25;
	for (int k = 1; k < 60; ++k)
	{
		term *= q / (static_cast<double> (k) * k);
		sum += term;
		if (term < 1e-17 * sum)
			break;
	}
	return sum;
}
} // namespace

//------------------------------------------------------------------------
void FractionalResampler::prepare (int64_t stepNum, int64_t stepDen, int halfTaps, double cutoff,
                                   double kaiserBeta, int maxInputChunk)
{
	half_ = std::max (4, halfTaps);
	taps_ = 2 * half_;
	maxIn_ = std::max (1, maxInputChunk);
	den_ = std::max<int64_t> (1, stepDen);
	stepInt_ = stepNum / den_;
	stepRem_ = stepNum % den_;

	table_.assign (static_cast<size_t> (kPhases + 1) * taps_, 0.f);
	const double i0b = besselI0 (kaiserBeta);
	const double fc2 = 2. * std::min (0.5, std::max (0.001, cutoff));
	std::vector<double> row (static_cast<size_t> (taps_));
	for (int p = 0; p <= kPhases; ++p)
	{
		const double frac = static_cast<double> (p) / kPhases;
		double sum = 0.;
		for (int i = 0; i < taps_; ++i)
		{
			const double tau = static_cast<double> (i - half_ + 1) - frac;
			const double xw = tau / half_;
			double w = 0.;
			if (std::fabs (xw) < 1.)
				w = besselI0 (kaiserBeta * std::sqrt (1. - xw * xw)) / i0b;
			const double arg = kPi * fc2 * tau;
			const double s = std::fabs (arg) < 1e-12 ? 1. : std::sin (arg) / arg;
			row[static_cast<size_t> (i)] = fc2 * s * w;
			sum += row[static_cast<size_t> (i)];
		}
		for (int i = 0; i < taps_; ++i)
			table_[static_cast<size_t> (p) * taps_ + i] = static_cast<float> (row[static_cast<size_t> (i)] / sum);
	}
	buf_.assign (static_cast<size_t> (taps_ + maxIn_), 0.f);
	reset ();
}

void FractionalResampler::reset ()
{
	std::fill (buf_.begin (), buf_.end (), 0.f);
	posInt_ = taps_;
	posNum_ = 0;
}

int FractionalResampler::maxOutputFor (int numIn) const
{
	const int64_t stepNum = stepInt_ * den_ + stepRem_;
	return static_cast<int> ((static_cast<int64_t> (numIn) * den_) / std::max<int64_t> (1, stepNum)) + 2;
}

int FractionalResampler::process (const float* in, int numIn, float* out)
{
	numIn = std::min (numIn, maxIn_);
	std::memcpy (buf_.data () + taps_, in, static_cast<size_t> (numIn) * sizeof (float));
	const int64_t last = static_cast<int64_t> (taps_) + numIn - 1;
	const double invDen = static_cast<double> (kPhases) / static_cast<double> (den_);
	int numOut = 0;
	while (posInt_ + half_ <= last)
	{
		const double pf = static_cast<double> (posNum_) * invDen;
		int p0 = static_cast<int> (pf);
		if (p0 >= kPhases)
			p0 = kPhases - 1;
		const float a = static_cast<float> (pf - p0);
		const float* x = buf_.data () + (posInt_ - half_ + 1);
		const float* r0 = table_.data () + static_cast<size_t> (p0) * taps_;
		const float* r1 = r0 + taps_;
		float acc0 = 0.f, acc1 = 0.f;
		int i = 0;
#ifdef SPHS_SSE
		__m128 s0 = _mm_setzero_ps (), s1 = _mm_setzero_ps ();
		for (; i + 4 <= taps_; i += 4)
		{
			const __m128 v = _mm_loadu_ps (x + i);
			s0 = _mm_add_ps (s0, _mm_mul_ps (v, _mm_loadu_ps (r0 + i)));
			s1 = _mm_add_ps (s1, _mm_mul_ps (v, _mm_loadu_ps (r1 + i)));
		}
		float t0[4], t1[4];
		_mm_storeu_ps (t0, s0);
		_mm_storeu_ps (t1, s1);
		acc0 = (t0[0] + t0[1]) + (t0[2] + t0[3]);
		acc1 = (t1[0] + t1[1]) + (t1[2] + t1[3]);
#endif
		for (; i < taps_; ++i)
		{
			acc0 += x[i] * r0[i];
			acc1 += x[i] * r1[i];
		}
		out[numOut++] = acc0 + a * (acc1 - acc0);

		posInt_ += stepInt_;
		posNum_ += stepRem_;
		if (posNum_ >= den_)
		{
			posNum_ -= den_;
			++posInt_;
		}
	}
	std::memmove (buf_.data (), buf_.data () + numIn, static_cast<size_t> (taps_) * sizeof (float));
	posInt_ -= numIn;
	return numOut;
}

//------------------------------------------------------------------------
Engine::Engine ()
{
	prepare (44100.);
}

void Engine::setModel (const ModelConfig& m)
{
	native_.setModel (m);
	reference_.setModel (m);
}

void Engine::prepare (double hostSampleRate)
{
	hostRate_ = hostSampleRate > 1000. ? hostSampleRate : 44100.;
	native_.prepare (hostRate_);
	reference_.prepare (kReferenceSampleRate);

	// exact rational ratio: internal / host = Q / P
	const int64_t P = 2 * static_cast<int64_t> (std::llround (hostRate_));
	const int64_t Q = 78125; // 2 * 39062.5
	const double r = static_cast<double> (Q) / static_cast<double> (P);
	const double lowDown = std::min (1., r);		// relative to host Nyquist
	const double lowUp = std::min (1., 1. / r);		// relative to internal Nyquist
	const int halfA = static_cast<int> (std::ceil (quality_.baseHalfTaps / lowDown));
	const int halfB = static_cast<int> (std::ceil (quality_.baseHalfTaps / lowUp));

	down_.prepare (P, Q, halfA, 0.5 * lowDown * quality_.cutoffRel, quality_.kaiserBeta, kChunk);
	const int maxInternal = down_.maxOutputFor (kChunk);
	upL_.prepare (Q, P, halfB, 0.5 * lowUp * quality_.cutoffRel, quality_.kaiserBeta, maxInternal);
	upR_.prepare (Q, P, halfB, 0.5 * lowUp * quality_.cutoffRel, quality_.kaiserBeta, maxInternal);
	const int maxHost = upL_.maxOutputFor (maxInternal);

	tmpIn_.assign (static_cast<size_t> (maxInternal), 0.f);
	tmpL_.assign (static_cast<size_t> (maxInternal), 0.f);
	tmpR_.assign (static_cast<size_t> (maxInternal), 0.f);
	hostL_.assign (static_cast<size_t> (maxHost), 0.f);
	hostR_.assign (static_cast<size_t> (maxHost), 0.f);

	// Output j becomes available once host input j + halfB/r + halfA (+ rounding)
	// has arrived, so this pre-fill can never under-run.
	refLatency_ = static_cast<int> (std::ceil (halfB / r + halfA)) + 2;

	int cap = 1;
	while (cap < refLatency_ + 2 * maxHost + kChunk + 64)
		cap <<= 1;
	fifoL_.assign (static_cast<size_t> (cap), 0.f);
	fifoR_.assign (static_cast<size_t> (cap), 0.f);
	fifoMask_ = cap - 1;
	reset ();
}

void Engine::reset ()
{
	native_.reset ();
	reference_.reset ();
	down_.reset ();
	upL_.reset ();
	upR_.reset ();
	std::fill (fifoL_.begin (), fifoL_.end (), 0.f);
	std::fill (fifoR_.begin (), fifoR_.end (), 0.f);
	fifoRead_ = 0;
	fifoWrite_ = refLatency_ & fifoMask_;
	fifoCount_ = refLatency_;
}

void Engine::setMode (EngineMode mode)
{
	if (mode == mode_)
		return;
	mode_ = mode;
	reset ();
}

void Engine::setParams (double speedHz, double depth, double manual, double resonance)
{
	native_.setSpeed (speedHz);
	native_.setDepth (depth);
	native_.setManual (manual);
	native_.setResonance (resonance);
	reference_.setSpeed (speedHz);
	reference_.setDepth (depth);
	reference_.setManual (manual);
	reference_.setResonance (resonance);
}

void Engine::processReferenceChunk (const float* in, float* outL, float* outR, int n)
{
	const int m = down_.process (in, n, tmpIn_.data ());
	reference_.process (tmpIn_.data (), tmpL_.data (), tmpR_.data (), m);
	const int k = upL_.process (tmpL_.data (), m, hostL_.data ());
	upR_.process (tmpR_.data (), m, hostR_.data ());

	for (int i = 0; i < k; ++i)
	{
		fifoL_[static_cast<size_t> (fifoWrite_)] = hostL_[static_cast<size_t> (i)];
		fifoR_[static_cast<size_t> (fifoWrite_)] = hostR_[static_cast<size_t> (i)];
		fifoWrite_ = (fifoWrite_ + 1) & fifoMask_;
	}
	fifoCount_ += k;

	for (int i = 0; i < n; ++i)
	{
		if (fifoCount_ > 0)
		{
			outL[i] = fifoL_[static_cast<size_t> (fifoRead_)];
			outR[i] = fifoR_[static_cast<size_t> (fifoRead_)];
			fifoRead_ = (fifoRead_ + 1) & fifoMask_;
			--fifoCount_;
		}
		else
		{
			outL[i] = outR[i] = 0.f; // cannot happen with the latency above
			++underruns_;
		}
	}
}

void Engine::process (const float* in, float* outL, float* outR, int numSamples)
{
	if (mode_ == EngineMode::Native)
	{
		native_.process (in, outL, outR, numSamples);
		return;
	}
	while (numSamples > 0)
	{
		const int n = std::min (numSamples, kChunk);
		processReferenceChunk (in, outL, outR, n);
		in += n;
		outL += n;
		outR += n;
		numSamples -= n;
	}
}

} // namespace sphs
