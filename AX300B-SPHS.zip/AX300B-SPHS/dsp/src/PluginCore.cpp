#include "sphs/PluginCore.h"
#include <algorithm>
#include <cmath>
#include <cstring>

namespace sphs {

double coreParamDefault (int param)
{
	switch (param)
	{
		case kCoreSpeed: return speedToNorm (0.5);
		case kCoreDepth: return 0.5;	  // 25
		case kCoreManual: return 0.5;	  // 25
		case kCoreResonance: return 0.5;  // 0
		case kCorePedalMax: return 1.;
		default: return 0.;
	}
}

UserParams baseParamsFromNorm (const double* norm)
{
	UserParams u;
	u.speedHz = speedFromNorm (norm[kCoreSpeed]);
	u.depth = depthFromNorm (norm[kCoreDepth]);
	u.manual = manualFromNorm (norm[kCoreManual]);
	u.resonance = resonanceFromNorm (norm[kCoreResonance]);
	return u;
}

UserParams effectiveParamsFromNorm (const double* norm)
{
	return applyPedal (baseParamsFromNorm (norm), pedalTargetFromNorm (norm[kCorePedalTarget]),
	                   norm[kCorePedalMin], norm[kCorePedalMax], norm[kCorePedalPos]);
}

PluginCore::PluginCore ()
{
	for (int i = 0; i < kCoreNumParams; ++i)
		norm_[i] = coreParamDefault (i);
	prepare (44100.);
}

void PluginCore::setModel (const ModelConfig& m)
{
	engine_.setModel (m);
	applyParams ();
	reset ();
}

void PluginCore::prepare (double sampleRate)
{
	fs_ = sampleRate > 1000. ? sampleRate : 44100.;
	engine_.prepare (fs_);
	fadeStep_ = 1. / (0.010 * fs_); // 10 ms bypass / mode cross-fade
	int size = 1;
	while (size < engine_.latency (EngineMode::Reference) + 2)
		size <<= 1;
	dryDelay_.assign (static_cast<size_t> (size), 0.f);
	dryMask_ = size - 1;
	applyParams ();
	reset ();
}

void PluginCore::reset ()
{
	engine_.reset ();
	std::fill (dryDelay_.begin (), dryDelay_.end (), 0.f);
	dryWrite_ = 0;
	activeGain_ = bypass_ ? 0. : 1.;
	engineIdle_ = bypass_;
	fadeHold_ = 0;
}

void PluginCore::setParam (int param, double normalized)
{
	if (param < 0 || param >= kCoreNumParams)
		return;
	norm_[param] = clamp01 (normalized);
	applyParams ();
}

void PluginCore::applyParams ()
{
	bypass_ = norm_[kCoreBypass] > 0.5;
	const EngineMode mode = norm_[kCoreEngineMode] > 0.5 ? EngineMode::Reference : EngineMode::Native;
	if (mode != engine_.mode ())
	{
		engine_.setMode (mode); // clears the engine state
		activeGain_ = 0.;		// and fades the effect back in ...
		fadeHold_ = engine_.latency (); // ... once its delay line has filled
	}
	const UserParams u = effectiveParamsFromNorm (norm_);
	engine_.setParams (u.speedHz, u.depth, u.manual, u.resonance);
}

void PluginCore::render (const float* inL, const float* inR, float* outL, float* outR, int n)
{
	// 1. copy the input first: the host may hand us the same buffers for in and out
	if (!inL)
		std::memset (mono_, 0, static_cast<size_t> (n) * sizeof (float));
	else if (inR)
		for (int i = 0; i < n; ++i)
			mono_[i] = 0.5f * (inL[i] + inR[i]);
	else
		std::memcpy (mono_, inL, static_cast<size_t> (n) * sizeof (float));

	// 2. dry path, delayed by the engine latency so bypass stays time-aligned
	const int latency = engine_.latency ();
	for (int i = 0; i < n; ++i)
	{
		dryDelay_[static_cast<size_t> (dryWrite_)] = mono_[i];
		dry_[i] = dryDelay_[static_cast<size_t> ((dryWrite_ - latency) & dryMask_)];
		dryWrite_ = (dryWrite_ + 1) & dryMask_;
	}

	const double target = bypass_ ? 0. : 1.;
	if (bypass_ && activeGain_ <= 0.)
	{
		// fully bypassed: the effect is not computed at all
		engineIdle_ = true;
		for (int i = 0; i < n; ++i)
			outL[i] = outR[i] = dry_[i];
		return;
	}
	if (engineIdle_)
	{
		engine_.reset (); // clean start when the effect is switched back in
		engineIdle_ = false;
		fadeHold_ = engine_.latency ();
	}

	engine_.process (mono_, wetL_, wetR_, n);

	if (activeGain_ == target && target == 1.)
	{
		std::memcpy (outL, wetL_, static_cast<size_t> (n) * sizeof (float));
		std::memcpy (outR, wetR_, static_cast<size_t> (n) * sizeof (float));
		return;
	}
	double g = activeGain_;
	for (int i = 0; i < n; ++i)
	{
		if (g < target)
		{
			if (fadeHold_ > 0 && g <= 0.)
				--fadeHold_; // Reference mode: wait until the effect output has arrived
			else
				g = std::min (target, g + fadeStep_);
		}
		else if (g > target)
			g = std::max (target, g - fadeStep_);
		if (g >= 1.)
		{
			outL[i] = wetL_[i];
			outR[i] = wetR_[i];
		}
		else if (g <= 0.)
		{
			outL[i] = outR[i] = dry_[i];
		}
		else
		{
			const float a = static_cast<float> (g);
			outL[i] = dry_[i] + a * (wetL_[i] - dry_[i]);
			outR[i] = dry_[i] + a * (wetR_[i] - dry_[i]);
		}
	}
	activeGain_ = g;
}

void PluginCore::process (const float* inL, const float* inR, float* outL, float* outR, int numSamples,
                          const CoreEvent* events, int numEvents)
{
	int pos = 0, ei = 0;
	while (pos < numSamples)
	{
		bool dirty = false;
		while (ei < numEvents && events[ei].offset <= pos)
		{
			const CoreEvent& e = events[ei++];
			if (e.param >= 0 && e.param < kCoreNumParams)
			{
				norm_[e.param] = clamp01 (e.value);
				dirty = true;
			}
		}
		if (dirty)
			applyParams ();

		int end = numSamples;
		if (ei < numEvents)
			end = std::min (numSamples, std::max (pos + 1, static_cast<int> (events[ei].offset)));
		end = std::min (end, pos + kChunk);
		const int n = end - pos;
		render (inL ? inL + pos : nullptr, inR ? inR + pos : nullptr, outL + pos, outR + pos, n);
		pos = end;
	}
	// events past the end of the block (or a block of zero length)
	bool dirty = false;
	while (ei < numEvents)
	{
		const CoreEvent& e = events[ei++];
		if (e.param >= 0 && e.param < kCoreNumParams)
		{
			norm_[e.param] = clamp01 (e.value);
			dirty = true;
		}
	}
	if (dirty)
		applyParams ();
}

} // namespace sphs
