// sphs_render - runs the exact plug-in DSP on a WAV file.
// Used for A/B comparison against hardware recordings and by the Python
// research suite (so that the fitted model and the plug-in are the same code).
#include "WavIO.h"
#include "sphs/Engine.h"
#include "sphs/ModelIO.h"
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>

static void usage ()
{
	std::printf (
	    "sphs_render --in in.wav --out out.wav [options]\n"
	    "  --model file.json     model (default: the model compiled into the plug-in)\n"
	    "  --mode native|reference   (default native)\n"
	    "  --speed Hz  --depth 0..50  --manual 0..50  --res -50..50\n"
	    "  --block N             processing block size (default 512)\n"
	    "  --keep-latency        do not remove the Reference-mode latency\n"
	    "  --dump-model out.json write the active model and exit\n");
}

int main (int argc, char** argv)
{
	std::string inPath, outPath, modelPath, dumpPath, mode = "native";
	double speed = 0.5, depth = 25., manual = 25., res = 0.;
	int block = 512;
	bool keepLatency = false;
	for (int i = 1; i < argc; ++i)
	{
		const std::string a = argv[i];
		auto next = [&] () -> const char* { return i + 1 < argc ? argv[++i] : ""; };
		if (a == "--in") inPath = next ();
		else if (a == "--out") outPath = next ();
		else if (a == "--model") modelPath = next ();
		else if (a == "--mode") mode = next ();
		else if (a == "--speed") speed = std::atof (next ());
		else if (a == "--depth") depth = std::atof (next ());
		else if (a == "--manual") manual = std::atof (next ());
		else if (a == "--res") res = std::atof (next ());
		else if (a == "--block") block = std::max (1, std::atoi (next ()));
		else if (a == "--keep-latency") keepLatency = true;
		else if (a == "--dump-model") dumpPath = next ();
		else { usage (); return 2; }
	}

	sphs::ModelConfig model = sphs::defaultModel ();
	if (!modelPath.empty () && !sphs::loadModelFile (modelPath, model))
	{
		std::fprintf (stderr, "cannot read model %s\n", modelPath.c_str ());
		return 1;
	}
	if (!dumpPath.empty ())
		return sphs::saveModelFile (dumpPath, model) ? 0 : 1;
	if (inPath.empty () || outPath.empty ())
	{
		usage ();
		return 2;
	}

	wavio::Audio in;
	if (!wavio::read (inPath, in))
	{
		std::fprintf (stderr, "cannot read %s\n", inPath.c_str ());
		return 1;
	}
	const size_t frames = in.frames ();
	std::vector<float> mono (frames);
	for (size_t i = 0; i < frames; ++i)
		mono[i] = in.data[i * static_cast<size_t> (in.channels)]; // first channel = instrument input

	sphs::Engine engine;
	engine.setModel (model);
	engine.prepare (in.sampleRate);
	engine.setMode (mode == "reference" ? sphs::EngineMode::Reference : sphs::EngineMode::Native);
	engine.setParams (speed, depth, manual, res);
	engine.reset ();

	const int latency = keepLatency ? 0 : engine.latency ();
	const size_t total = frames + static_cast<size_t> (latency);
	mono.resize (total, 0.f);
	std::vector<float> l (total), r (total);
	for (size_t pos = 0; pos < total; pos += static_cast<size_t> (block))
	{
		const int n = static_cast<int> (std::min<size_t> (static_cast<size_t> (block), total - pos));
		engine.process (mono.data () + pos, l.data () + pos, r.data () + pos, n);
	}

	wavio::Audio out;
	out.sampleRate = in.sampleRate;
	out.channels = 2;
	out.data.resize (frames * 2);
	for (size_t i = 0; i < frames; ++i)
	{
		out.data[2 * i] = l[i + static_cast<size_t> (latency)];
		out.data[2 * i + 1] = r[i + static_cast<size_t> (latency)];
	}
	if (!wavio::writeFloat (outPath, out))
	{
		std::fprintf (stderr, "cannot write %s\n", outPath.c_str ());
		return 1;
	}
	std::printf ("model=%s fitted=%d mode=%s fs=%d latency=%d frames=%zu\n", model.name,
	             model.fittedToHardware, mode.c_str (), in.sampleRate, engine.latency (), frames);
	return 0;
}
