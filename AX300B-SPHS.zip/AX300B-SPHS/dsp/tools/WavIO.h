// Minimal WAV reader/writer for the command-line tools (not used by the plug-in).
#pragma once
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

namespace wavio {

struct Audio
{
	int sampleRate = 44100;
	int channels = 1;
	std::vector<float> data; // interleaved
	size_t frames () const { return channels > 0 ? data.size () / static_cast<size_t> (channels) : 0; }
};

inline uint32_t rd32 (const uint8_t* p) { return p[0] | (p[1] << 8) | (p[2] << 16) | (static_cast<uint32_t> (p[3]) << 24); }
inline uint16_t rd16 (const uint8_t* p) { return static_cast<uint16_t> (p[0] | (p[1] << 8)); }

inline bool read (const std::string& path, Audio& out)
{
	FILE* f = std::fopen (path.c_str (), "rb");
	if (!f)
		return false;
	std::vector<uint8_t> buf;
	std::fseek (f, 0, SEEK_END);
	const long size = std::ftell (f);
	std::fseek (f, 0, SEEK_SET);
	if (size < 44)
	{
		std::fclose (f);
		return false;
	}
	buf.resize (static_cast<size_t> (size));
	const size_t got = std::fread (buf.data (), 1, buf.size (), f);
	std::fclose (f);
	if (got != buf.size () || std::memcmp (buf.data (), "RIFF", 4) != 0 || std::memcmp (buf.data () + 8, "WAVE", 4) != 0)
		return false;

	int format = 0, bits = 0, channels = 0, rate = 0;
	size_t pos = 12;
	const uint8_t* dataPtr = nullptr;
	size_t dataLen = 0;
	while (pos + 8 <= buf.size ())
	{
		const uint32_t len = rd32 (buf.data () + pos + 4);
		const uint8_t* body = buf.data () + pos + 8;
		if (std::memcmp (buf.data () + pos, "fmt ", 4) == 0 && len >= 16)
		{
			format = rd16 (body);
			channels = rd16 (body + 2);
			rate = static_cast<int> (rd32 (body + 4));
			bits = rd16 (body + 14);
			if (format == 0xFFFE && len >= 26)
				format = rd16 (body + 24); // WAVE_FORMAT_EXTENSIBLE sub-format
		}
		else if (std::memcmp (buf.data () + pos, "data", 4) == 0)
		{
			dataPtr = body;
			dataLen = std::min<size_t> (len, buf.size () - (pos + 8));
			break;
		}
		pos += 8 + len + (len & 1);
	}
	if (!dataPtr || channels < 1 || rate < 1)
		return false;
	const int bytes = bits / 8;
	if (bytes < 1)
		return false;
	const size_t count = dataLen / static_cast<size_t> (bytes);
	out.sampleRate = rate;
	out.channels = channels;
	out.data.resize (count);
	for (size_t i = 0; i < count; ++i)
	{
		const uint8_t* p = dataPtr + i * static_cast<size_t> (bytes);
		float v = 0.f;
		if (format == 3 && bits == 32)
			std::memcpy (&v, p, 4);
		else if (format == 3 && bits == 64)
		{
			double d;
			std::memcpy (&d, p, 8);
			v = static_cast<float> (d);
		}
		else if (bits == 16)
			v = static_cast<int16_t> (rd16 (p)) / 32768.f;
		else if (bits == 24)
		{
			int32_t x = p[0] | (p[1] << 8) | (p[2] << 16);
			if (x & 0x800000)
				x |= ~0xFFFFFF;
			v = static_cast<float> (x) / 8388608.f;
		}
		else if (bits == 32)
			v = static_cast<float> (static_cast<int32_t> (rd32 (p)) / 2147483648.0);
		else if (bits == 8)
			v = (static_cast<int> (p[0]) - 128) / 128.f;
		out.data[i] = v;
	}
	return true;
}

inline bool writeFloat (const std::string& path, const Audio& a)
{
	FILE* f = std::fopen (path.c_str (), "wb");
	if (!f)
		return false;
	const uint32_t dataBytes = static_cast<uint32_t> (a.data.size () * 4);
	uint8_t h[44];
	auto w32 = [&] (int o, uint32_t v) { h[o] = v & 255; h[o + 1] = (v >> 8) & 255; h[o + 2] = (v >> 16) & 255; h[o + 3] = (v >> 24) & 255; };
	auto w16 = [&] (int o, uint16_t v) { h[o] = v & 255; h[o + 1] = (v >> 8) & 255; };
	std::memcpy (h, "RIFF", 4);
	w32 (4, 36 + dataBytes);
	std::memcpy (h + 8, "WAVEfmt ", 8);
	w32 (16, 16);
	w16 (20, 3); // IEEE float
	w16 (22, static_cast<uint16_t> (a.channels));
	w32 (24, static_cast<uint32_t> (a.sampleRate));
	w32 (28, static_cast<uint32_t> (a.sampleRate * a.channels * 4));
	w16 (32, static_cast<uint16_t> (a.channels * 4));
	w16 (34, 32);
	std::memcpy (h + 36, "data", 4);
	w32 (40, dataBytes);
	bool ok = std::fwrite (h, 1, 44, f) == 44;
	ok = ok && std::fwrite (a.data.data (), 4, a.data.size (), f) == a.data.size ();
	std::fclose (f);
	return ok;
}

} // namespace wavio
