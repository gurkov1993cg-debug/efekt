# AX300B-SPHS — стерео фейзър (VST3) за iMac 2011

Плъгин, който моделира ефекта **SPHS – Stereo Phaser** от KORG ToneWorks AX300B.
Това е независим проект. Не съдържа код, графики или лога на KORG.

> **Важно:** звукът още **НЕ е напаснат към истински AX300B**. В плъгина пише
> „MODEL: H0-unfitted (NOT fitted to hardware)“. Докато няма записи от истински
> уред, никой не може честно да каже, че звучи 1:1. Виж `docs/REPORT_BG.md`.

## Какво има в архива

| Папка | Какво е |
|---|---|
| `dsp/` | Звуковата част — самостоятелна C++ библиотека (без VST3, без графика) |
| `plugin/` | VST3 плъгинът: процесор, контролер, графичен интерфейс |
| `tests/` | Автоматични тестове на звуковата част |
| `research/` | Python инструменти за измерване на истински AX300B и напасване на модела |
| `docs/` | Отчет, упътване за измерване, снимка на интерфейса |
| `.github/workflows/efekt.yml` | Автоматичен билд в GitHub за Intel Mac (macOS 10.13) |

## Как да получиш плъгина (през GitHub, от телефона)

1. В репото `efekt` качи файла **`efekt.yml`** в папка `.github/workflows/` (замества празния).
2. Качи **`AX300B-SPHS.zip`** в главната папка на репото.
3. Отвори таб **Actions** → изчакай зелената отметка → отвори билда → най-долу **Artifacts** → свали `SPHS-Phaser-macOS-x86_64`.
4. На iMac-а: разархивирай и сложи `SPHS-Phaser.vst3` в `/Library/Audio/Plug-Ins/VST3/`.
5. Пусни Cubase. Плъгинът е в **Modulation → SPHS Stereo Phaser**. Сложи го на **стерео** писта.

## Копчетата

- **SPEED** 0.02–9.5 Hz, **DEPTH** 0–50, **MANUAL** 0–50, **RESONANCE** −50…+50 — както в оригиналното ръководство.
- **PARAM / MIN / MAX** — кое копче управлява педалът и между кои стойности (MIN = отпуснат, MAX = натиснат докрай).
- **PRESSURE** педалът — натискаш и движиш с мишката. **HOLD** го оставя на място (като външен експрешън педал).
  Работи и с MIDI контролер (CC 11 или CC 4) и с автоматизация в Cubase.
- **1–4, BANK UP/DOWN, WRITE** — 32 програми (8 банки × 4). WRITE запомня текущите настройки.
- **NATIVE / REF 39 kHz** — NATIVE смята на честотата на проекта; REF смята на 39.0625 kHz, както оригиналният уред.
- **BYPASS** — изключва ефекта.

## За програмисти

```
cmake -S . -B build -DSPHS_BUILD_PLUGIN=OFF && cmake --build build && ./build/tests/sphs_dsp_tests
cmake -S . -B build -G Xcode -DVST3_SDK_ROOT=<vst3sdk 3.7.8> -DCMAKE_POLICY_VERSION_MINIMUM=3.5
```

SDK: Steinberg VST3 SDK 3.7.8, commit `0041ef2c879c3c54c03d33cdc11a97eaebfb5752` (с VSTGUI).
